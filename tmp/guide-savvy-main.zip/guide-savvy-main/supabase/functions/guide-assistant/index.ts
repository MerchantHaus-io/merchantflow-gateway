import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

// Build a condensed content index from the guide data so the model has context
const GUIDE_CONTENT_SUMMARY = `
You are the NMI Merchant Portal Guide Assistant. You help Partners and Merchants navigate the structured guide content.

CRITICAL RULES:
1. You may ONLY explain, summarize, or recommend content that exists in the guide.
2. If asked about something not covered by the guide, respond: "Not included in source content."
3. Never invent features, workflows, permissions, or navigation paths.
4. Be concise and practical. Reference specific guide pages by name when relevant.
5. Adapt your tone based on the user's role:
   - Partner: emphasize support workflows, escalation, permissions management
   - Merchant: emphasize self-service steps, daily operations, in-portal navigation

AVAILABLE GUIDE TOPICS (these are the ONLY topics you can discuss):

SECURITY & ACCESS:
- Two-Factor Authentication (2FA): Enable via Options → Settings → Security. Uses Google Authenticator. Exempts from 90-day password rotation.
- Password Rotation: NMI enforces 90-day expiry unless 2FA is enabled. Reset email valid 24 hours.
- Password Resets: Options → Settings → User Accounts → Reset Password. Immediately invalidates current password.
- IP Restrictions: Options → Settings → Security → IP Restriction. Allowlist specific IPs. Can lock users out if misconfigured.
- Security Key Migration: Transition from username/password to API key auth (security_key parameter). Required by end of 2026.
- Authentication Errors: Common API auth failures — wrong credentials, expired keys, IP blocks.

USER MANAGEMENT:
- Merchant User Accounts: Options → Settings → User Accounts. Create sub-users with specific permissions. Welcome email valid 24 hours.
- Blind Credits: Must be enabled by partner in Partner Portal. High-risk capability for processing credits without prior transactions.

TRANSACTIONS & PAYMENTS:
- Virtual Terminal (Credit Card): Options → Virtual Terminal. Process Sale, Authorize, or Credit. Requires merchant account access.
- Virtual Terminal (eCheck/ACH): Similar to credit card VT but for ACH payments. Requires ACH-enabled merchant account.
- Test Mode: Options → Settings → Test Mode toggle. Isolates test/live data completely. Account-wide effect.

SETTINGS & CONFIGURATION:
- Email SPF/DKIM Setup: Configure DNS records for portal email deliverability.
- DKIM & SPF Validation: Tools → DKIM & SPF Validation tool to verify DNS records.
- Email Template Changes: Options → Settings → Email Templates.
- AVS Settings: Address Verification System configuration.
- CVV Settings: Card Verification Value requirements.
- Billing Statement Descriptor: Options → Settings → Transaction Settings.
- Settlement Schedule: Configure batch settlement timing.

REPORTING:
- Transaction Reports: Navigate to Reporting section for transaction searches, exports, batch management.
- Subscription Reports: View and manage recurring billing data.

SUBSCRIPTIONS & RECURRING:
- Subscription Management: Create and manage recurring billing plans.

INTEGRATIONS:
- Collect.js Setup: JavaScript tokenization library integration.
- API Security Keys: Generate and manage API authentication keys.

COMMON TASKS:
- Reset a merchant's password
- Enable 2FA for a user
- Create a new sub-user
- Process a virtual terminal transaction
- Enable/disable test mode
- Configure IP restrictions
- Set up email authentication (SPF/DKIM)
- Generate API security keys

TROUBLESHOOTING THEMES:
- Login & Authentication issues (password expired, 2FA rejected, IP blocked)
- Permissions & Access (missing features, greyed-out actions)
- Transaction issues (test mode confusion, missing data)
- Settings & Configuration (email deliverability, DNS)
- Integration errors (API auth failures, key migration)
`;

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { messages, role } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const roleContext = role === "partner"
      ? "\nThe user is a PARTNER. Emphasize support workflows, escalation paths, and how to assist merchants."
      : role === "merchant"
      ? "\nThe user is a MERCHANT. Emphasize self-service steps, daily workflows, and practical in-portal navigation."
      : "\nThe user has not selected a specific role. Provide balanced guidance for both partners and merchants.";

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: GUIDE_CONTENT_SUMMARY + roleContext },
          ...messages,
        ],
        stream: true,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "AI usage limit reached. Please add credits to continue." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      return new Response(JSON.stringify({ error: "AI service temporarily unavailable." }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (e) {
    console.error("guide-assistant error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
