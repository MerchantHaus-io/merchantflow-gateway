import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { RoleProvider } from "@/contexts/RoleContext";
import { AppLayout } from "@/components/guide/AppLayout";
import { lazy, Suspense } from "react";

const Index = lazy(() => import("./pages/Index"));
const CategoryPage = lazy(() => import("./pages/CategoryPage"));
const GuidePage = lazy(() => import("./pages/GuidePage"));
const SearchPage = lazy(() => import("./pages/SearchPage"));
const GlossaryPage = lazy(() => import("./pages/GlossaryPage"));
const TroubleshootingPage = lazy(() => import("./pages/TroubleshootingPage"));
const TasksPage = lazy(() => import("./pages/TasksPage"));
const NotFound = lazy(() => import("./pages/NotFound"));

const queryClient = new QueryClient();

function PageLoader() {
  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 space-y-4 animate-pulse">
      <div className="h-4 w-32 bg-muted rounded" />
      <div className="h-8 w-64 bg-muted rounded" />
      <div className="h-4 w-full max-w-lg bg-muted rounded" />
      <div className="h-4 w-full max-w-md bg-muted rounded" />
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-8">
        {[1, 2, 3].map(i => (
          <div key={i} className="h-32 rounded-xl border bg-card" />
        ))}
      </div>
    </div>
  );
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <RoleProvider>
        <BrowserRouter>
          <AppLayout>
            <Suspense fallback={<PageLoader />}>
              <Routes>
                <Route path="/" element={<Index />} />
                <Route path="/category/:slug" element={<CategoryPage />} />
                <Route path="/guide/:slug" element={<GuidePage />} />
                <Route path="/search" element={<SearchPage />} />
                <Route path="/glossary" element={<GlossaryPage />} />
                <Route path="/troubleshooting" element={<TroubleshootingPage />} />
                <Route path="/tasks" element={<TasksPage />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </Suspense>
          </AppLayout>
        </BrowserRouter>
      </RoleProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
