import { Category, Guide, GlossaryTerm, CommonTask, TroubleshootingItem } from "./types";

// ─────────────────────────────────────────────────────
// CATEGORIES — 10 intentional buckets
// ─────────────────────────────────────────────────────

export const categories: Category[] = [
  {
    slug: "getting-started",
    title: "Getting Started",
    description: "Official login entry points, sandbox references, and first-time onboarding steps for the NMI Merchant Portal.",
    icon: "Rocket",
    audience: "both",
    featuredTaskSlugs: ["two-factor-authentication", "test-mode"],
    troubleshootingSlugs: ["authentication-errors"],
    subcategories: ["Access & Logins", "Onboarding"],
  },
  {
    slug: "security-access",
    title: "Security & Access",
    description: "Two-factor authentication, password policies, IP restrictions, and account security best practices.",
    icon: "Shield",
    audience: "both",
    featuredTaskSlugs: ["two-factor-authentication", "password-resets", "ip-restrictions"],
    troubleshootingSlugs: ["authentication-errors", "two-factor-authentication", "password-rotation"],
    subcategories: ["Authentication", "Password Management", "Access Control"],
  },
  {
    slug: "user-management",
    title: "User Management",
    description: "Create, edit, and manage merchant sub-users, permissions, notifications, and welcome emails.",
    icon: "Users",
    audience: "both",
    featuredTaskSlugs: ["merchant-user-accounts", "password-resets"],
    troubleshootingSlugs: ["password-resets"],
    subcategories: ["User Accounts", "Permissions"],
  },
  {
    slug: "settings-configuration",
    title: "Settings & Configuration",
    description: "Account information, email deliverability, merchant defined fields, invoice branding, country/currency defaults, and more.",
    icon: "Settings",
    audience: "both",
    featuredTaskSlugs: ["account-information", "email-spf-dkim", "merchant-defined-fields"],
    troubleshootingSlugs: ["email-spf-dkim"],
    subcategories: ["Account Settings", "Email & Communications", "Invoicing", "Custom Fields"],
  },
  {
    slug: "transactions-payments",
    title: "Transactions & Payments",
    description: "Virtual Terminal credit card and eCheck processing, test mode, settlement schedules, transaction routing, fees, and fraud controls.",
    icon: "CreditCard",
    audience: "merchant",
    featuredTaskSlugs: ["vt-credit-card", "vt-echeck", "test-mode"],
    troubleshootingSlugs: ["test-mode", "settlement-schedule"],
    subcategories: ["Virtual Terminal", "Fraud Controls", "Settlement", "Fees & Routing"],
  },
  {
    slug: "reporting",
    title: "Reporting",
    description: "Transaction reports, settlement batch reporting, search transactions, and report configuration templates.",
    icon: "BarChart3",
    audience: "merchant",
    featuredTaskSlugs: ["transaction-reports", "report-configuration"],
    troubleshootingSlugs: ["transaction-reports"],
    subcategories: ["Transaction Reports", "Report Templates"],
  },
  {
    slug: "subscriptions-recurring",
    title: "Subscriptions & Recurring",
    description: "Subscription reports, pause/resume, automatic card updater, and recurring billing management.",
    icon: "RefreshCw",
    audience: "merchant",
    featuredTaskSlugs: ["subscription-reports", "auto-card-updater"],
    troubleshootingSlugs: [],
    subcategories: ["Subscription Management", "Card Updater"],
  },
  {
    slug: "integrations-api",
    title: "Integrations & Security Keys",
    description: "Security key management, API key migration, Collect.js, Collect Checkout, QuickClick, Product Manager, device registration, and ACH/eCheck concepts.",
    icon: "Puzzle",
    audience: "both",
    featuredTaskSlugs: ["security-key-migration", "collectjs-setup", "collect-checkout"],
    troubleshootingSlugs: ["authentication-errors", "what-is-ach"],
    subcategories: ["API Keys", "Hosted Checkout", "Product Management", "Device Registration", "ACH Reference", "Direct Connect"],
  },
  {
    slug: "troubleshooting",
    title: "Troubleshooting",
    description: "Common issues, likely causes, verification steps, and resolution paths across all portal features.",
    icon: "HelpCircle",
    audience: "both",
    featuredTaskSlugs: [],
    troubleshootingSlugs: [],
    subcategories: [],
  },
  {
    slug: "glossary",
    title: "Glossary",
    description: "Key terms and concepts used throughout the NMI Merchant Portal.",
    icon: "BookOpen",
    audience: "both",
    featuredTaskSlugs: [],
    troubleshootingSlugs: [],
    subcategories: [],
  },
];

// ─────────────────────────────────────────────────────
// GUIDES — full structured content from report
// ─────────────────────────────────────────────────────

export const guides: Guide[] = [
  // ── Getting Started ──
  {
    id: "gs-001",
    slug: "portal-access-logins",
    title: "Portal Access & Logins",
    audience: "both",
    category: "Getting Started",
    categorySlug: "getting-started",
    subcategory: "Access & Logins",
    summary: "Official entry points for Merchant Portal, Partner Portal, and Sandbox logins. Start here if you're new to NMI.",
    whenToUse: "When you need to locate the correct login URL for your portal, or when onboarding a new team member.",
    prerequisites: ["Valid NMI merchant or partner account credentials"],
    requiredPermissions: [],
    navigationPath: "https://www.nmi.com/logins/ → Select Merchant Portal",
    steps: [
      { stepNumber: 1, instruction: "Go to https://www.nmi.com/logins/ — the official NMI logins page." },
      { stepNumber: 2, instruction: "Select 'Merchant Portal' to access secure.nmi.com, or 'Partner Portal' for partner access." },
      { stepNumber: 3, instruction: "For testing, select 'Sandbox' to access the sandbox environment." },
    ],
    screenshots: [],
    warnings: [],
    notes: [
      "The official login page lists Merchant Portal, Partner Portal, Sandbox, and other consoles.",
      "Bookmark your portal URL to avoid phishing attempts.",
    ],
    faqs: [
      { question: "Where do I log in?", answer: "Go to https://www.nmi.com/logins/ and select the appropriate portal." },
    ],
    troubleshooting: [],
    relatedTopics: [
      { slug: "two-factor-authentication", title: "Two-Factor Authentication", relationship: "related" },
      { slug: "password-rotation", title: "90-Day Password Policy", relationship: "related" },
      { slug: "test-mode", title: "Test Mode", relationship: "related" },
    ],
    glossaryTerms: ["merchant-portal", "partner-portal"],
    lastUpdated: "Unspecified",
    sourceReference: "https://www.nmi.com/logins/",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: ["Exact sandbox URL not provided in source report."],
    complexity: "beginner",
  },

  // ── Security & Access ──
  {
    id: "sa-001",
    slug: "two-factor-authentication",
    title: "Two-Factor Authentication for Merchants",
    audience: "merchant",
    category: "Security & Access",
    categorySlug: "security-access",
    subcategory: "Authentication",
    summary: "Enable 2FA using Google Authenticator to secure your Merchant Portal login and exempt yourself from 90-day password resets.",
    whenToUse: "When setting up a new merchant account, or when you want to avoid 90-day password rotation requirements.",
    prerequisites: ["Active Merchant Portal account", "Google Authenticator app installed (iOS App Store or Android Play Store)"],
    requiredPermissions: ["Merchant user login access"],
    navigationPath: "Merchant Portal → My Settings (top-right) → Two-Factor Auth",
    steps: [
      { stepNumber: 1, instruction: "Install Google Authenticator from the iOS App Store or Android Play Store." },
      { stepNumber: 2, instruction: "In Merchant Portal, navigate to 2FA setup via one of two paths:\n• Option A: My Settings (top-right) → Two-Factor Auth\n• Option B: Options (left nav) → Two-Factor Auth" },
      { stepNumber: 3, instruction: "Scan the QR code displayed in Merchant Portal using Google Authenticator." },
      { stepNumber: 4, instruction: "Enter the current 6-digit code from Google Authenticator into the 'Six-Digit Auth Code' field in Merchant Portal." },
      { stepNumber: 5, instruction: "Click Authenticate to complete setup." },
    ],
    screenshots: [],
    warnings: ["If you lose your device, you will need to contact your service provider to reset 2FA."],
    notes: [
      "After setup, every login requires username + password + current 6-digit code.",
      "Codes rotate every ~30 seconds; expired codes will fail.",
      "Enabling 2FA exempts you from the 90-day password rotation requirement.",
      "Partners cannot enable 2FA on behalf of merchants—merchants must do it themselves.",
    ],
    faqs: [
      { question: "Can my partner enable 2FA for me?", answer: "No. Merchants must enable 2FA by logging into their own Merchant Portal account." },
      { question: "What happens if my 2FA code doesn't work?", answer: "Ensure your device clock is synced. Codes rotate every ~30 seconds, so enter them promptly." },
      { question: "Does 2FA eliminate password expiry?", answer: "Yes. Enabling 2FA exempts you from the 90-day password rotation requirement." },
    ],
    troubleshooting: [
      { issue: "2FA code rejected at login", cause: "Device clock out of sync or code expired", verify: "Check that your phone's time is set to automatic", fix: "Sync your device clock and try the newest code", escalation: "Contact your service provider to reset 2FA if issue persists" },
    ],
    relatedTopics: [
      { slug: "password-rotation", title: "90-Day Password Policy", relationship: "related" },
      { slug: "password-resets", title: "Password Resets", relationship: "related" },
      { slug: "merchant-user-accounts", title: "Merchant User Accounts", relationship: "related" },
      { slug: "portal-access-logins", title: "Portal Access & Logins", relationship: "parent" },
    ],
    glossaryTerms: ["2fa", "google-authenticator"],
    lastUpdated: "30 Jul 2025",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/13269954223121",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: [],
    complexity: "beginner",
  },
  {
    id: "sa-002",
    slug: "password-rotation",
    title: "90-Day Password Policy",
    audience: "both",
    category: "Security & Access",
    categorySlug: "security-access",
    subcategory: "Password Management",
    summary: "NMI enforces a 90-day password expiry for Merchant Portal accounts unless 2FA is enabled. Understand the in-portal prompts, expiry lockout, and how to reset.",
    whenToUse: "When you see an in-portal password expiry warning, or when planning your account security strategy.",
    prerequisites: ["Active Merchant Portal account"],
    requiredPermissions: ["Any authenticated user"],
    navigationPath: "Merchant Portal → Options → Password Reset",
    steps: [
      { stepNumber: 1, instruction: "In Merchant Portal, open Options from the left navigation." },
      { stepNumber: 2, instruction: "Select Password Reset." },
      { stepNumber: 3, instruction: "Follow the on-screen workflow to set a new password.", note: "Password must be at least 12 characters." },
    ],
    screenshots: [
      "/merchant-portal/security/90-day-password-01.png",
      "/merchant-portal/security/90-day-password-02.png",
      "/merchant-portal/security/90-day-password-03.png",
    ],
    warnings: [
      "If your password expires, you will be locked out until you complete the reset process via email.",
      "The notification is in-portal only—NMI does not send email warnings before expiry.",
    ],
    notes: [
      "Users are prompted to change their password starting around day ~80 and may skip until day 90.",
      "After expiry (day 90), login is blocked and a password reset email is sent when login is attempted.",
      "Enabling 2FA exempts users from the 90-day rotation requirement.",
      "By the end of 2026, merchants will be required to move from username/password to API key authentication.",
    ],
    faqs: [
      { question: "Will I get an email before my password expires?", answer: "No. Notifications appear in-portal only, starting approximately 10 days before expiry." },
      { question: "How do I avoid the 90-day rotation?", answer: "Enable Two-Factor Authentication (2FA). This exempts you from the rotation requirement." },
    ],
    troubleshooting: [
      { issue: "Cannot login—password expired", cause: "90-day password rotation window exceeded", verify: "Check for 'Password Expired' message on login screen", fix: "Attempt login to trigger a password reset email, then follow the reset link (valid 24 hours)", escalation: "Contact your service provider if the reset email does not arrive" },
    ],
    relatedTopics: [
      { slug: "two-factor-authentication", title: "Two-Factor Authentication", relationship: "related" },
      { slug: "password-resets", title: "Password Resets", relationship: "child" },
      { slug: "security-key-migration", title: "API Key Migration", relationship: "related" },
    ],
    glossaryTerms: ["2fa", "api-key"],
    lastUpdated: "31 Oct 2025",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/36048865203089",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: [
      "Exact password complexity rules beyond '12 characters minimum' are not specified in the source report.",
      "Source report notes a discrepancy: one article says no email notification; another says users 'will be notified automatically'—the guide uses the more specific article's assertion (in-portal only).",
    ],
    complexity: "beginner",
  },
  {
    id: "sa-003",
    slug: "password-resets",
    title: "Password Resets for Partner & Merchant Portal",
    audience: "both",
    category: "Security & Access",
    categorySlug: "security-access",
    subcategory: "Password Management",
    summary: "Canonical SOPs for resetting passwords for partner primary/sub users and merchant primary/sub users, including warnings about immediate invalidation.",
    whenToUse: "When a user has forgotten their password, when assisting a merchant with account access, or after a password expiry lockout.",
    prerequisites: ["For partner-assisted resets: Partner Portal access with administrative permissions"],
    requiredPermissions: ["Partner: Administrative permissions", "Merchant: Primary user or self-service reset"],
    navigationPath: "Partner Portal → List Accounts → [Merchant] → Merchant Users → Reset Password",
    steps: [
      { stepNumber: 1, instruction: "Log into Partner Portal with a user who has administrative permissions." },
      { stepNumber: 2, instruction: "Go to List Accounts and open the merchant account." },
      { stepNumber: 3, instruction: "In Merchant Users, locate the Primary User." },
      { stepNumber: 4, instruction: "Click Reset Password and confirm.", warning: "The existing password is invalidated immediately upon clicking reset." },
    ],
    screenshots: [],
    warnings: [
      "Resetting a password immediately invalidates the current password. Avoid doing this if the merchant uses that password for API transactions or cannot access email right away.",
    ],
    notes: [
      "A reset email is sent to the primary user with a link valid for 24 hours.",
      "The existing password is invalidated immediately—do not reset if the merchant is actively using password-based API transactions.",
      "For merchant sub-users, the primary user can reset passwords from Merchant Portal → Settings → User Accounts.",
    ],
    faqs: [
      { question: "How long is the reset link valid?", answer: "The password reset link is valid for 24 hours." },
      { question: "Can a merchant sub-user reset their own password?", answer: "Sub-users can use the 'Forgot Password' link on the login page, or the primary user can reset it from User Accounts." },
    ],
    troubleshooting: [
      { issue: "Reset email not received", cause: "Email filtered to spam or incorrect email on file", verify: "Check spam/junk folders; verify the email address in account settings", fix: "Re-trigger the reset; if email is wrong, update it in Partner Portal first", escalation: "Contact NMI support if the email address cannot be updated" },
    ],
    relatedTopics: [
      { slug: "password-rotation", title: "90-Day Password Policy", relationship: "parent" },
      { slug: "merchant-user-accounts", title: "Merchant User Accounts", relationship: "related" },
      { slug: "two-factor-authentication", title: "Two-Factor Authentication", relationship: "related" },
    ],
    glossaryTerms: [],
    lastUpdated: "17 Feb 2026",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/34031835872529",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: [],
    complexity: "beginner",
  },
  {
    id: "sa-004",
    slug: "ip-restrictions",
    title: "Merchant IP Restrictions",
    audience: "both",
    category: "Security & Access",
    categorySlug: "security-access",
    subcategory: "Access Control",
    summary: "Restrict Merchant Portal and API access to allowlisted IP addresses and hostnames to enhance security.",
    whenToUse: "When you want to lock down portal and API access to specific office or network locations.",
    prerequisites: ["Merchant Portal access with administrative permissions"],
    requiredPermissions: ["Access Administrative Options", "Access Security Options"],
    navigationPath: "Merchant Portal → Options → Settings → Security Options → IP Restrictions",
    steps: [
      { stepNumber: 1, instruction: "Navigate to Merchant Portal → Options → Settings → Security Options → IP Restrictions." },
      { stepNumber: 2, instruction: "Add allowed IP addresses or hostnames in the 'IP or Host to Allow' list.", note: "The UI shows your current public IP and offers 'Add to allowlist'." },
      { stepNumber: 3, instruction: "Choose whether each entry applies to Control Panel, API, or both." },
      { stepNumber: 4, instruction: "Save changes." },
    ],
    screenshots: [],
    warnings: [
      "If you allowlist the wrong IP and lock yourself out, follow your internal support escalation path. Do not attempt further changes from an unallowlisted location.",
    ],
    notes: [
      "The UI displays your current public IP address for easy adding.",
      "You can restrict portal access, API access, or both independently per IP entry.",
    ],
    faqs: [
      { question: "What happens if I lock myself out?", answer: "Contact your service provider or partner to update the IP allowlist from their Partner Portal access." },
    ],
    troubleshooting: [
      { issue: "Locked out after IP restriction change", cause: "Current IP not on the allowlist", verify: "Confirm your current public IP using a service like whatismyip.com", fix: "Contact your partner or NMI support to update the allowlist", permissions: "Partner administrative access required to fix" },
    ],
    relatedTopics: [
      { slug: "merchant-user-accounts", title: "Merchant User Accounts", relationship: "related" },
      { slug: "authentication-errors", title: "Authentication Errors", relationship: "troubleshooting" },
    ],
    glossaryTerms: ["ip-restrictions"],
    lastUpdated: "07 Oct 2022",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/9613241989393",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: [],
    complexity: "intermediate",
  },

  // ── User Management ──
  {
    id: "um-001",
    slug: "merchant-user-accounts",
    title: "Merchant User Accounts",
    audience: "both",
    category: "User Management",
    categorySlug: "user-management",
    subcategory: "User Accounts",
    summary: "Add, edit, and delete merchant sub-users. Manage permissions, notifications, and resend welcome emails.",
    whenToUse: "When onboarding new team members, adjusting user permissions, or troubleshooting user access issues.",
    prerequisites: ["Merchant Portal access with administrative permissions"],
    requiredPermissions: ["Access Administrative Options"],
    navigationPath: "Merchant Portal → Options → Settings → General Options → User Accounts",
    steps: [
      { stepNumber: 1, instruction: "Navigate to Merchant Portal → Options → Settings → General Options → User Accounts." },
      { stepNumber: 2, instruction: "Click Add A New User." },
      { stepNumber: 3, instruction: "Enter: First Name, Last Name, Email, (optional) Title, Username." },
      { stepNumber: 4, instruction: "Select user Permissions and Notifications." },
      { stepNumber: 5, instruction: "Click Create User." },
    ],
    screenshots: [
      "/merchant-portal/user-management/merchant-user-accounts-01.png",
    ],
    warnings: [],
    notes: [
      "The 'Set a Password' link in the welcome email is valid for 24 hours.",
      "If the link expires, open the user record and click Re-send User Welcome Email.",
      "Permissions control what the user can see and do: transaction reports, settings, recurring, etc.",
    ],
    faqs: [
      { question: "What if the welcome email link expires?", answer: "Open the user record in User Accounts and use the 'Re-send User Welcome Email' option." },
      { question: "Can I edit permissions after creating a user?", answer: "Yes. Open the user record from User Accounts and update their permissions and notifications." },
    ],
    troubleshooting: [],
    relatedTopics: [
      { slug: "password-resets", title: "Password Resets", relationship: "related" },
      { slug: "ip-restrictions", title: "IP Restrictions", relationship: "related" },
    ],
    glossaryTerms: [],
    lastUpdated: "23 Sep 2025",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/13002653837713",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: [
      "A complete list of all available permissions is not enumerated in the source report; permissions are referenced across individual feature articles.",
    ],
    complexity: "beginner",
  },

  // ── Settings & Configuration ──
  {
    id: "sc-001",
    slug: "account-information",
    title: "Account Information",
    audience: "both",
    category: "Settings & Configuration",
    categorySlug: "settings-configuration",
    subcategory: "Account Settings",
    summary: "View and update merchant account contact details, receipt 'From' address, reply-to email, and time zone settings.",
    whenToUse: "When setting up a new merchant account or updating contact details, email settings, or time zone.",
    prerequisites: ["Merchant Portal access with admin permissions"],
    requiredPermissions: ["Access Administrative Options"],
    navigationPath: "Merchant Portal → Options → Settings → Account Information",
    steps: [
      { stepNumber: 1, instruction: "Navigate to Merchant Portal → Options → Settings → Account Information." },
      { stepNumber: 2, instruction: "Update editable fields: contact details, receipt 'From' address, reply-to email, time zone." },
      { stepNumber: 3, instruction: "Save changes." },
    ],
    screenshots: [],
    warnings: [],
    notes: [
      "Merchants cannot self-update business name or billing information—contact your Merchant Service Provider (MSP) for those changes.",
    ],
    faqs: [
      { question: "Can I change my business name here?", answer: "No. Business name and billing details must be updated by your Merchant Service Provider." },
    ],
    troubleshooting: [],
    relatedTopics: [
      { slug: "msp-contact-details", title: "MSP Contact Details", relationship: "related" },
      { slug: "billing-statement", title: "Billing Statement", relationship: "related" },
    ],
    glossaryTerms: ["msp"],
    lastUpdated: "17 Feb 2026",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/13001776309521",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: [],
    complexity: "beginner",
  },
  {
    id: "sc-002",
    slug: "billing-statement",
    title: "Billing Statement",
    audience: "both",
    category: "Settings & Configuration",
    categorySlug: "settings-configuration",
    subcategory: "Account Settings",
    summary: "How partners enable billing statement visibility for merchants and how merchants access their billing statements.",
    whenToUse: "When a merchant needs to view billing details, or when a partner needs to enable billing statement access.",
    prerequisites: ["Partner Portal access (for enabling)", "Merchant Portal access (for viewing)"],
    requiredPermissions: ["Partner: Account configuration access", "Merchant: Receive Accounting Notifications permission (for email alerts)"],
    navigationPath: "Merchant Portal → Options → Settings → Billing Statement",
    steps: [
      { stepNumber: 1, instruction: "Partner: In Partner Portal, enable 'Display Billing Statement in the merchant control panel' for the merchant account." },
      { stepNumber: 2, instruction: "Merchant: Navigate to Merchant Portal → Options → Settings → Billing Statement to view." },
      { stepNumber: 3, instruction: "Optionally, enable billing email notifications by granting the 'Receive Accounting Notifications' permission to the desired user.", note: "This is configured in User Accounts permissions." },
    ],
    screenshots: [
      "/merchant-portal/invoicing/billing-statement-01.png",
      "/merchant-portal/invoicing/billing-statement-02.png",
    ],
    warnings: [],
    notes: [
      "Billing statements must be enabled by the partner before merchants can see them.",
      "Email notifications are optional and require specific user permissions.",
    ],
    faqs: [],
    troubleshooting: [
      { issue: "Merchant cannot see billing statement", cause: "Partner has not enabled billing statement display", verify: "Check Partner Portal settings for the merchant account", fix: "Enable 'Display Billing Statement in the merchant control panel' in Partner Portal" },
    ],
    relatedTopics: [
      { slug: "account-information", title: "Account Information", relationship: "related" },
      { slug: "merchant-user-accounts", title: "Merchant User Accounts", relationship: "related" },
    ],
    glossaryTerms: [],
    lastUpdated: "09 Sep 2024",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/13209137769617",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: [],
    complexity: "beginner",
  },
  {
    id: "sc-003",
    slug: "email-spf-dkim",
    title: "Adding SPF & DKIM Records",
    audience: "merchant",
    category: "Settings & Configuration",
    categorySlug: "settings-configuration",
    subcategory: "Email & Communications",
    summary: "Configure DNS SPF/DKIM records so Merchant Portal emails (sent via safewebservices.com) aren't rejected as spam.",
    whenToUse: "When merchant emails from the portal are being flagged as spam or not delivered.",
    prerequisites: ["Access to your domain's DNS settings"],
    requiredPermissions: ["DNS administration for your domain"],
    navigationPath: "N/A — DNS configuration done outside Merchant Portal",
    steps: [
      { stepNumber: 1, instruction: "Obtain the required SPF record value from the NMI support article." },
      { stepNumber: 2, instruction: "Add or update your domain's SPF TXT record to include the safewebservices.com sender." },
      { stepNumber: 3, instruction: "Add the required DKIM CNAME records as specified in the article." },
      { stepNumber: 4, instruction: "Verify records have propagated using the DKIM & SPF Validation tool in Merchant Portal." },
    ],
    screenshots: [
      "/merchant-portal/email/dkim-spf-validation-01.png",
      "/merchant-portal/email/dkim-spf-validation-02.png",
      "/merchant-portal/email/dkim-spf-validation-03.png",
      "/merchant-portal/email/dkim-spf-validation-04.png",
    ],
    warnings: [],
    notes: [
      "Emails from Merchant Portal are sent via safewebservices.com.",
      "Without proper SPF/DKIM, emails may be rejected or land in spam.",
    ],
    faqs: [],
    troubleshooting: [
      { issue: "Portal emails going to spam", cause: "Missing or incorrect SPF/DKIM DNS records", verify: "Use Merchant Portal → DKIM & SPF Validation tool to check status", fix: "Add/correct SPF and DKIM DNS records as specified" },
    ],
    relatedTopics: [
      { slug: "dkim-spf-validation", title: "DKIM & SPF Validation", relationship: "child" },
      { slug: "email-template-changes", title: "Email Template Changes", relationship: "related" },
    ],
    glossaryTerms: [],
    lastUpdated: "06 Feb 2026",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/19169413609105",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: ["Exact SPF record and DKIM CNAME values are referenced but full DNS records not reproduced in the research report."],
    complexity: "intermediate",
  },
  {
    id: "sc-004",
    slug: "dkim-spf-validation",
    title: "DKIM & SPF Validation for Merchant Emails",
    audience: "merchant",
    category: "Settings & Configuration",
    categorySlug: "settings-configuration",
    subcategory: "Email & Communications",
    summary: "Use the Merchant Portal validation tool to check SPF/DKIM status and understand fallback behaviour.",
    whenToUse: "After configuring SPF/DKIM records, or when troubleshooting email delivery issues.",
    prerequisites: ["SPF/DKIM records configured in DNS"],
    requiredPermissions: ["Merchant Portal access"],
    navigationPath: "Merchant Portal → Options → Settings → DKIM & SPF Validation",
    steps: [
      { stepNumber: 1, instruction: "Navigate to Merchant Portal → Options → Settings → DKIM & SPF Validation." },
      { stepNumber: 2, instruction: "Review the validation status for your domain's SPF and DKIM records." },
      { stepNumber: 3, instruction: "If records are misconfigured, the system falls back to outgoing@safewebservices.com as the sender." },
    ],
    screenshots: [
      "/merchant-portal/email/dkim-spf-validation-01.png",
      "/merchant-portal/email/dkim-spf-validation-02.png",
      "/merchant-portal/email/dkim-spf-validation-03.png",
      "/merchant-portal/email/dkim-spf-validation-04.png",
    ],
    warnings: [],
    notes: [
      "If SPF/DKIM validation fails, emails will be sent from outgoing@safewebservices.com instead of your custom domain.",
    ],
    faqs: [],
    troubleshooting: [],
    relatedTopics: [
      { slug: "email-spf-dkim", title: "Adding SPF & DKIM Records", relationship: "parent" },
    ],
    glossaryTerms: [],
    lastUpdated: "25 Jun 2025",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/24487866264593",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: [],
    complexity: "intermediate",
  },
  {
    id: "sc-005",
    slug: "email-template-changes",
    title: "Email Template Changes",
    audience: "merchant",
    category: "Settings & Configuration",
    categorySlug: "settings-configuration",
    subcategory: "Email & Communications",
    summary: "Receipt and notification email template changes are done by NMI Support via email request.",
    whenToUse: "When you need to customize the content or appearance of receipt emails.",
    prerequisites: ["Merchant account with NMI"],
    requiredPermissions: [],
    navigationPath: "N/A — contact NMI Support via email",
    steps: [
      { stepNumber: 1, instruction: "Compose an email to NMI Support describing the template changes you need." },
      { stepNumber: 2, instruction: "Include specific details: which template, what changes, any branding requirements." },
      { stepNumber: 3, instruction: "NMI Support will implement the changes and confirm when complete." },
    ],
    screenshots: [],
    warnings: [],
    notes: [
      "Common change types include: logo updates, footer text, receipt field additions/removals.",
      "Template changes cannot be self-served in Merchant Portal—they require NMI Support action.",
    ],
    faqs: [],
    troubleshooting: [],
    relatedTopics: [
      { slug: "email-spf-dkim", title: "Adding SPF & DKIM Records", relationship: "related" },
      { slug: "invoice-look-and-feel", title: "Invoice Look and Feel", relationship: "related" },
    ],
    glossaryTerms: [],
    lastUpdated: "15 May 2023",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/360032391892",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: ["NMI Support contact email address not specified in source report."],
    complexity: "beginner",
  },
  {
    id: "sc-006",
    slug: "msp-contact-details",
    title: "Merchant Service Provider Contact Details",
    audience: "both",
    category: "Settings & Configuration",
    categorySlug: "settings-configuration",
    subcategory: "Account Settings",
    summary: "Where merchants find support contact details and how partners update what merchants see.",
    whenToUse: "When a merchant needs to find support contact information, or when a partner wants to update the displayed support details.",
    prerequisites: ["Merchant Portal access (merchants)", "Partner Portal access (partners)"],
    requiredPermissions: ["Partner: Administrative permissions to update contact details"],
    navigationPath: "Merchant Portal → Help → Support",
    steps: [
      { stepNumber: 1, instruction: "Merchants: Navigate to Help → Support to find your service provider's contact details." },
      { stepNumber: 2, instruction: "Partners: In Partner Portal, navigate to settings and update the additional contact details that merchants will see." },
    ],
    screenshots: [
      "/merchant-portal/settings/how-to-manage-msp-contact-01.png",
      "/merchant-portal/settings/how-to-manage-msp-contact-02.png",
    ],
    warnings: [],
    notes: [
      "The contact details merchants see are configured by their partner in Partner Portal.",
    ],
    faqs: [],
    troubleshooting: [],
    relatedTopics: [
      { slug: "account-information", title: "Account Information", relationship: "related" },
    ],
    glossaryTerms: ["msp"],
    lastUpdated: "09 Apr 2025",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/34244306912017",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: ["Exact Partner Portal navigation path for updating MSP contacts not specified in source report."],
    complexity: "beginner",
  },
  {
    id: "sc-007",
    slug: "merchant-defined-fields",
    title: "Merchant Defined Fields",
    audience: "merchant",
    category: "Settings & Configuration",
    categorySlug: "settings-configuration",
    subcategory: "Custom Fields",
    summary: "Create up to 20 custom fields (plain text, checkbox, radio, select) usable across Virtual Terminal, API, QuickClick, Collect Checkout, recurring, and more.",
    whenToUse: "When you need to capture additional custom data with transactions beyond the standard fields.",
    prerequisites: ["Merchant Portal access with admin permissions"],
    requiredPermissions: ["Access Administrative Options"],
    navigationPath: "Merchant Portal → Options → Settings → Merchant Defined Fields",
    steps: [
      { stepNumber: 1, instruction: "Navigate to Merchant Portal → Options → Settings → Merchant Defined Fields." },
      { stepNumber: 2, instruction: "Click to add a new field." },
      { stepNumber: 3, instruction: "Choose the field type: plain text, checkbox, radio button, or select/dropdown." },
      { stepNumber: 4, instruction: "Name the field and configure any options (for radio/select types)." },
      { stepNumber: 5, instruction: "Save. The field will now appear across VT, API, QuickClick, Collect Checkout, and recurring interfaces." },
    ],
    screenshots: [
      "/merchant-portal/settings/merchant-defined-fields-01.png",
      "/merchant-portal/settings/merchant-defined-fields-02.png",
      "/merchant-portal/settings/merchant-defined-fields-03.png",
      "/merchant-portal/settings/merchant-defined-fields-04.png",
      "/merchant-portal/settings/merchant-defined-fields-05.png",
      "/merchant-portal/settings/merchant-defined-fields-06.png",
      "/merchant-portal/settings/merchant-defined-fields-07.png",
      "/merchant-portal/settings/merchant-defined-fields-08.png",
      "/merchant-portal/settings/merchant-defined-fields-09.png",
      "/merchant-portal/settings/merchant-defined-fields-10.png",
      "/merchant-portal/settings/merchant-defined-fields-11.png",
      "/merchant-portal/settings/merchant-defined-fields-12.png",
      "/merchant-portal/settings/merchant-defined-fields-13.png",
      "/merchant-portal/settings/merchant-defined-fields-14.png",
    ],
    warnings: [],
    notes: [
      "You can create up to 20 custom fields.",
      "Fields appear in transaction search results and can be used for reporting.",
    ],
    faqs: [],
    troubleshooting: [],
    relatedTopics: [
      { slug: "vt-form-customization", title: "Virtual Terminal Form Customization", relationship: "related" },
      { slug: "report-configuration", title: "Report Configuration", relationship: "related" },
    ],
    glossaryTerms: ["merchant-defined-fields"],
    lastUpdated: "04 Jun 2024",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/360002718417",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: [],
    complexity: "intermediate",
  },
  {
    id: "sc-008",
    slug: "country-currency",
    title: "Country/Currency Configuration",
    audience: "merchant",
    category: "Settings & Configuration",
    categorySlug: "settings-configuration",
    subcategory: "Account Settings",
    summary: "Set default country and currency values for Virtual Terminal fields. Does not affect API processing.",
    whenToUse: "When you want to pre-fill country and currency dropdowns in the Virtual Terminal to match your primary market.",
    prerequisites: ["Merchant Portal access"],
    requiredPermissions: ["Access Administrative Options"],
    navigationPath: "Merchant Portal → Options → Settings → Country/Currency Configuration",
    steps: [
      { stepNumber: 1, instruction: "Navigate to Merchant Portal → Options → Settings → Country/Currency Configuration." },
      { stepNumber: 2, instruction: "Select your default country and currency." },
      { stepNumber: 3, instruction: "Save changes." },
    ],
    screenshots: [
      "/merchant-portal/settings/country-currency-configuration-01.png",
      "/merchant-portal/settings/country-currency-configuration-02.png",
    ],
    warnings: [],
    notes: ["This only affects Virtual Terminal field defaults—it does not change how API transactions are processed."],
    faqs: [],
    troubleshooting: [],
    relatedTopics: [
      { slug: "vt-credit-card", title: "Credit Card Processing (Virtual Terminal)", relationship: "related" },
    ],
    glossaryTerms: [],
    lastUpdated: "23 May 2023",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/14911153558929",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: [],
    complexity: "beginner",
  },
  {
    id: "sc-009",
    slug: "invoice-look-and-feel",
    title: "Invoice Look and Feel",
    audience: "merchant",
    category: "Settings & Configuration",
    categorySlug: "settings-configuration",
    subcategory: "Invoicing",
    summary: "Upload a logo for Electronic Invoicing that appears on the invoice body and attached PDF.",
    whenToUse: "When you want to brand your invoices with your company logo.",
    prerequisites: ["Electronic Invoicing enabled"],
    requiredPermissions: ["Access Administrative Options"],
    navigationPath: "Merchant Portal → Options → Settings → Invoice Look and Feel",
    steps: [
      { stepNumber: 1, instruction: "Navigate to Merchant Portal → Options → Settings → Invoice Look and Feel." },
      { stepNumber: 2, instruction: "Upload your merchant logo image." },
      { stepNumber: 3, instruction: "Preview how it will appear on invoice emails and PDF attachments." },
      { stepNumber: 4, instruction: "Save changes." },
    ],
    screenshots: [
      "/merchant-portal/invoicing/invoice-look-and-feel-01.png",
      "/merchant-portal/invoicing/invoice-look-and-feel-02.png",
    ],
    warnings: [],
    notes: ["The logo appears on both the invoice email body and the attached PDF."],
    faqs: [],
    troubleshooting: [],
    relatedTopics: [
      { slug: "email-template-changes", title: "Email Template Changes", relationship: "related" },
    ],
    glossaryTerms: [],
    lastUpdated: "21 Feb 2023",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/13177112580497",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: ["Supported logo file formats and size limits not specified in source report."],
    complexity: "beginner",
  },
  {
    id: "sc-010",
    slug: "sec-code-configuration",
    title: "SEC Code Configuration",
    audience: "merchant",
    category: "Settings & Configuration",
    categorySlug: "settings-configuration",
    subcategory: "Account Settings",
    summary: "Set the default ACH SEC code for Virtual Terminal eCheck processing to comply with NACHA requirements.",
    whenToUse: "When configuring default SEC codes for eCheck/ACH processing in the Virtual Terminal.",
    prerequisites: ["ACH/eCheck processing enabled"],
    requiredPermissions: ["Access Administrative Options"],
    navigationPath: "Merchant Portal → Options → Settings → SEC Code Configuration",
    steps: [
      { stepNumber: 1, instruction: "Navigate to Merchant Portal → Options → Settings → SEC Code Configuration." },
      { stepNumber: 2, instruction: "Select the appropriate default SEC code for your eCheck transactions." },
      { stepNumber: 3, instruction: "Save changes." },
    ],
    screenshots: [
      "/merchant-portal/settings/sec-code-configuration-01.png",
      "/merchant-portal/settings/sec-code-configuration-02.png",
      "/merchant-portal/settings/sec-code-configuration-03.png",
    ],
    warnings: [],
    notes: [
      "SEC codes are required by NACHA for all ACH transactions.",
      "Common codes: WEB (internet), TEL (telephone), PPD (prearranged).",
      "The correct SEC code is the merchant's responsibility per transaction.",
    ],
    faqs: [],
    troubleshooting: [],
    relatedTopics: [
      { slug: "vt-echeck", title: "eCheck Processing (Virtual Terminal)", relationship: "related" },
      { slug: "what-is-ach", title: "What is ACH?", relationship: "related" },
    ],
    glossaryTerms: ["sec-code", "nacha"],
    lastUpdated: "15 Jun 2023",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/16168315774481",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: ["Whether 'default SEC code is WEB' applies to all processors or only specific platforms is flagged as unclear in the source report."],
    complexity: "intermediate",
  },
  {
    id: "sc-011",
    slug: "level-iii-template",
    title: "Automatic Level III Merchant Template",
    audience: "merchant",
    category: "Settings & Configuration",
    categorySlug: "settings-configuration",
    subcategory: "Account Settings",
    summary: "For Level III Advantage merchants: a default Level III template automatically applied to card transactions without software support.",
    whenToUse: "When you're a Level III Advantage merchant and want to automatically apply Level III data to transactions.",
    prerequisites: ["Level III Advantage enabled on account"],
    requiredPermissions: ["Access Administrative Options"],
    navigationPath: "Merchant Portal → Options → Settings → Level III Template",
    steps: [
      { stepNumber: 1, instruction: "Navigate to Merchant Portal → Options → Settings → Level III Template." },
      { stepNumber: 2, instruction: "Configure the default Level III data fields." },
      { stepNumber: 3, instruction: "Save. The template will be automatically applied to qualifying card transactions." },
    ],
    screenshots: [
      "/merchant-portal/settings/automatic-level-iii-01.png",
      "/merchant-portal/settings/automatic-level-iii-02.png",
      "/merchant-portal/settings/automatic-level-iii-03.png",
    ],
    warnings: [],
    notes: [
      "Level III data helps reduce interchange rates for B2B/B2G transactions.",
      "The template is applied automatically—no software changes needed.",
    ],
    faqs: [],
    troubleshooting: [],
    relatedTopics: [
      { slug: "vt-credit-card", title: "Credit Card Processing (Virtual Terminal)", relationship: "related" },
    ],
    glossaryTerms: ["level-iii-data"],
    lastUpdated: "12 Jan 2026",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/18179214157969",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: [],
    complexity: "advanced",
  },

  // ── Transactions & Payments ──
  {
    id: "tp-001",
    slug: "vt-credit-card",
    title: "Credit Card Processing (Virtual Terminal)",
    audience: "merchant",
    category: "Transactions & Payments",
    categorySlug: "transactions-payments",
    subcategory: "Virtual Terminal",
    summary: "How to run credit card Sale, Authorize, Capture, Void, Refund, and Credit transactions in the Virtual Terminal.",
    whenToUse: "When processing card-present or card-not-present credit card transactions manually through the Merchant Portal.",
    prerequisites: ["Merchant Portal access", "Active processor connection"],
    requiredPermissions: ["Virtual Terminal access", "For Credits: Blind Credits must be enabled"],
    navigationPath: "Merchant Portal → Credit Cards → Sale (or Home shortcut 'Card Sale')",
    steps: [
      { stepNumber: 1, instruction: "Navigate to Merchant Portal → Credit Cards → Sale (or use the Home shortcut 'Card Sale')." },
      { stepNumber: 2, instruction: "Complete all required fields (marked with asterisk)." },
      { stepNumber: 3, instruction: "Click Submit/Charge to process the transaction." },
    ],
    screenshots: [],
    warnings: [
      "Blind Credits cannot be reversed once processed. Ensure Blind Credits is enabled in your account before attempting.",
    ],
    notes: [
      "Sale: Authorized and flagged for settlement immediately.",
      "Authorize: Places a hold but does not settle until captured.",
      "Capture: Settles a previously authorized transaction.",
      "Void: Cancels a transaction before settlement.",
      "Refund: Reverses a settled transaction, up to the original amount.",
      "Credit (Blind Credit): Issues a credit not tied to a previous transaction—requires Blind Credits to be enabled.",
    ],
    faqs: [
      { question: "What's the difference between Void and Refund?", answer: "Void cancels a transaction before settlement. Refund reverses a transaction after it has already settled." },
    ],
    troubleshooting: [],
    relatedTopics: [
      { slug: "vt-echeck", title: "eCheck Processing (Virtual Terminal)", relationship: "related" },
      { slug: "blind-credits", title: "Blind Credits", relationship: "child" },
      { slug: "test-mode", title: "Test Mode", relationship: "related" },
      { slug: "avs-settings", title: "AVS Settings", relationship: "related" },
      { slug: "cvv-settings", title: "CVV Settings", relationship: "related" },
      { slug: "vt-form-customization", title: "VT Form Customization", relationship: "child" },
    ],
    glossaryTerms: ["virtual-terminal", "void", "refund", "capture", "blind-credit", "settlement"],
    lastUpdated: "10 Apr 2025",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/15547776185233",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: [],
    complexity: "beginner",
  },
  {
    id: "tp-002",
    slug: "vt-echeck",
    title: "eCheck/ACH Processing (Virtual Terminal)",
    audience: "merchant",
    category: "Transactions & Payments",
    categorySlug: "transactions-payments",
    subcategory: "Virtual Terminal",
    summary: "How to run eCheck Sale, Void, Refund, and Credit transactions in the Virtual Terminal. ACH operations are batched daily with 3–5 day funding.",
    whenToUse: "When processing ACH/eCheck transactions manually through the Merchant Portal.",
    prerequisites: ["Merchant Portal access", "ACH/eCheck processor enabled"],
    requiredPermissions: ["Virtual Terminal access", "eCheck processing enabled"],
    navigationPath: "Merchant Portal → eCheck → Sale",
    steps: [
      { stepNumber: 1, instruction: "Navigate to Merchant Portal → eCheck → Sale." },
      { stepNumber: 2, instruction: "Complete required fields including routing number, account number, and amount." },
      { stepNumber: 3, instruction: "Submit to process. The transaction will be included in the next daily batch." },
    ],
    screenshots: [],
    warnings: [],
    notes: [
      "ACH operations are batched daily.",
      "Typical funding time is 3–5 business days (varies by processor/bank).",
      "Void/refund steps mirror credit card VT flows.",
    ],
    faqs: [],
    troubleshooting: [],
    relatedTopics: [
      { slug: "vt-credit-card", title: "Credit Card Processing (Virtual Terminal)", relationship: "related" },
      { slug: "what-is-ach", title: "What is ACH?", relationship: "parent" },
      { slug: "sec-code-configuration", title: "SEC Code Configuration", relationship: "prerequisite" },
    ],
    glossaryTerms: ["ach", "sec-code", "virtual-terminal"],
    lastUpdated: "17 Feb 2026",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/16172046403345",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: [],
    complexity: "beginner",
  },
  {
    id: "tp-003",
    slug: "test-mode",
    title: "Test Mode",
    audience: "both",
    category: "Transactions & Payments",
    categorySlug: "transactions-payments",
    subcategory: "Virtual Terminal",
    summary: "Toggle the entire merchant account into test mode. Test and live data are completely isolated.",
    whenToUse: "When testing transactions, integrations, or new configurations without affecting live data or actual payments.",
    prerequisites: ["Merchant Portal access with admin permissions"],
    requiredPermissions: ["Access Administrative Options"],
    navigationPath: "Merchant Portal → Options → Settings → Test Mode",
    steps: [
      { stepNumber: 1, instruction: "Navigate to Merchant Portal → Options → Settings → Test Mode." },
      { stepNumber: 2, instruction: "Click Enable to activate test mode.", warning: "Test mode is account-wide—all users and integrations will be in test mode." },
      { stepNumber: 3, instruction: "Perform your testing (transactions, vault entries, subscriptions, invoices)." },
      { stepNumber: 4, instruction: "When done, return to the same page and click Disable to return to live mode." },
    ],
    screenshots: [
      "/merchant-portal/settings/test-mode-01.png",
      "/merchant-portal/settings/test-mode-02.png",
    ],
    warnings: [
      "Ensure test mode is disabled before processing real transactions. Merchants will not be funded for transactions processed in test mode.",
    ],
    notes: [
      "Test mode is account-wide, not user-specific.",
      "Test and live data do NOT cross-populate: transactions, subscriptions, vault IDs, and invoices created in test mode do not appear in live mode, and vice versa.",
      "Merchants will not receive funding for test mode transactions.",
    ],
    faqs: [
      { question: "Can I see test transactions in live mode?", answer: "No. Test and live data are completely isolated. Switch to test mode to view test data." },
    ],
    troubleshooting: [
      { issue: "Transactions not appearing in reports", cause: "Account may be in test mode while looking at live reports (or vice versa)", verify: "Check the test mode toggle in Settings", fix: "Switch to the correct mode to view corresponding data" },
    ],
    relatedTopics: [
      { slug: "vt-credit-card", title: "Credit Card Processing (Virtual Terminal)", relationship: "related" },
      { slug: "transaction-reports", title: "Transaction Reports", relationship: "related" },
      { slug: "portal-access-logins", title: "Portal Access & Logins", relationship: "related" },
    ],
    glossaryTerms: ["test-mode"],
    lastUpdated: "02 Feb 2024",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/14376995063825",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: [],
    complexity: "beginner",
  },
  {
    id: "tp-004",
    slug: "settlement-schedule",
    title: "Settlement Schedule",
    audience: "merchant",
    category: "Transactions & Payments",
    categorySlug: "transactions-payments",
    subcategory: "Settlement",
    summary: "Adjust settlement cut-off time for terminal-capture processors. Understand terminal vs host capture and batch timing.",
    whenToUse: "When you need to change when your daily settlement batch closes, or when troubleshooting settlement timing.",
    prerequisites: ["Terminal-capture processor (host-capture processors manage settlement timing)"],
    requiredPermissions: ["Access Administrative Options"],
    navigationPath: "Merchant Portal → Options → Settings → Settlement Schedule",
    steps: [
      { stepNumber: 1, instruction: "Navigate to Merchant Portal → Options → Settings → Settlement Schedule." },
      { stepNumber: 2, instruction: "Set the desired cut-off time for daily batch settlement." },
      { stepNumber: 3, instruction: "Save changes. Use 'Show History' to review past settlements." },
    ],
    screenshots: [
      "/merchant-portal/settings/settlement-schedule-01.png",
      "/merchant-portal/settings/settlement-schedule-02.png",
    ],
    warnings: [],
    notes: [
      "Only terminal-capture processors allow cut-off time adjustment in the gateway.",
      "Host-capture processors manage settlement timing on their side.",
      "The cut-off is when the batch closes—actual settlement timing varies due to batch queues and processor timing.",
    ],
    faqs: [
      { question: "What's the difference between terminal and host capture?", answer: "Terminal capture: the gateway controls when the batch settles (you set the cut-off). Host capture: the processor controls settlement timing." },
    ],
    troubleshooting: [
      { issue: "Failed settlement batch", cause: "Processor connection issue or batch error", verify: "Check Transaction Reports for the failed batch", fix: "Select the failed batch and click 'Resettle Batches' to retry" },
    ],
    relatedTopics: [
      { slug: "transaction-reports", title: "Transaction Reports", relationship: "related" },
      { slug: "transaction-routing", title: "Transaction Routing", relationship: "related" },
    ],
    glossaryTerms: ["settlement", "terminal-capture", "host-capture", "resettle"],
    lastUpdated: "14 Feb 2025",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/13521687760785",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: [],
    complexity: "intermediate",
  },
  {
    id: "tp-005",
    slug: "transaction-routing",
    title: "Transaction Routing",
    audience: "merchant",
    category: "Transactions & Payments",
    categorySlug: "transactions-payments",
    subcategory: "Fees & Routing",
    summary: "Distribute transaction volume across multiple processors using amount thresholds as proxies for percentage distribution.",
    whenToUse: "When you have multiple processors and want to balance volume between them.",
    prerequisites: ["Multiple active processor connections"],
    requiredPermissions: ["Access Administrative Options"],
    navigationPath: "Merchant Portal → Options → Settings → Transaction Routing",
    steps: [
      { stepNumber: 1, instruction: "Navigate to Merchant Portal → Options → Settings → Transaction Routing." },
      { stepNumber: 2, instruction: "Configure amount thresholds representing the percentage distribution across processors." },
      { stepNumber: 3, instruction: "Set a default processor for overflow volume." },
      { stepNumber: 4, instruction: "Save changes." },
    ],
    screenshots: [
      "/merchant-portal/settings/transaction-routing-01.png",
    ],
    warnings: [],
    notes: [
      "Routing uses amount thresholds as proxies for percent distribution, balancing by volume rather than transaction count.",
      "A default processor handles overflow beyond configured thresholds.",
    ],
    faqs: [],
    troubleshooting: [],
    relatedTopics: [
      { slug: "settlement-schedule", title: "Settlement Schedule", relationship: "related" },
    ],
    glossaryTerms: ["transaction-routing"],
    lastUpdated: "04 Aug 2023",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/13617262567185",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: [],
    complexity: "advanced",
  },
  {
    id: "tp-006",
    slug: "customer-fees",
    title: "Customer Fee Configuration",
    audience: "merchant",
    category: "Transactions & Payments",
    categorySlug: "transactions-payments",
    subcategory: "Fees & Routing",
    summary: "Configure surcharges, convenience fees, and miscellaneous fees in the Virtual Terminal.",
    whenToUse: "When you need to add surcharges or convenience fees to VT transactions.",
    prerequisites: ["Merchant Portal access with admin permissions"],
    requiredPermissions: ["Access Administrative Options"],
    navigationPath: "Merchant Portal → Options → Settings → Customer Fee Configuration",
    steps: [
      { stepNumber: 1, instruction: "Navigate to Merchant Portal → Options → Settings → Customer Fee Configuration." },
      { stepNumber: 2, instruction: "Configure the desired fee type: surcharge, convenience fee, or miscellaneous fee." },
      { stepNumber: 3, instruction: "Set the fee amount or percentage." },
      { stepNumber: 4, instruction: "Save changes." },
    ],
    screenshots: [
      "/merchant-portal/settings/customer-fee-configuration-05.png",
      "/merchant-portal/settings/customer-fee-configuration-06.png",
      "/merchant-portal/settings/customer-fee-configuration-07.png",
    ],
    warnings: [
      "Ensure compliance with card brand surcharging rules and applicable local/state laws before enabling surcharges.",
    ],
    notes: [
      "Fee changes affect Virtual Terminal transactions only.",
      "Merchants must adhere to card brand rules and local laws regarding surcharging.",
    ],
    faqs: [],
    troubleshooting: [],
    relatedTopics: [
      { slug: "vt-credit-card", title: "Credit Card Processing (Virtual Terminal)", relationship: "parent" },
    ],
    glossaryTerms: [],
    lastUpdated: "29 Jul 2025",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/24535240227985",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: [],
    complexity: "intermediate",
  },
  {
    id: "tp-007",
    slug: "avs-settings",
    title: "Address Verification Settings (AVS)",
    audience: "merchant",
    category: "Transactions & Payments",
    categorySlug: "transactions-payments",
    subcategory: "Fraud Controls",
    summary: "Configure AVS rejection rules to reduce fraud by comparing billing address with issuer records.",
    whenToUse: "When setting up fraud controls or fine-tuning which AVS responses should result in transaction rejection.",
    prerequisites: ["Merchant Portal access with admin permissions"],
    requiredPermissions: ["Access Administrative Options", "Access Security Options"],
    navigationPath: "Merchant Portal → Options → Settings → AVS Settings",
    steps: [
      { stepNumber: 1, instruction: "Navigate to Merchant Portal → Options → Settings → AVS Settings." },
      { stepNumber: 2, instruction: "Review the available AVS response codes." },
      { stepNumber: 3, instruction: "Select which response codes should result in transaction rejection." },
      { stepNumber: 4, instruction: "Save changes." },
    ],
    screenshots: [
      "/merchant-portal/settings/address-verification-avs-01.png",
      "/merchant-portal/settings/address-verification-avs-02.png",
      "/merchant-portal/settings/address-verification-avs-03.png",
      "/merchant-portal/settings/address-verification-avs-04.png",
    ],
    warnings: [],
    notes: [
      "AVS compares the billing street address and ZIP code provided with the card issuer's records.",
      "Stricter AVS rules reduce fraud but may increase false declines.",
    ],
    faqs: [],
    troubleshooting: [],
    relatedTopics: [
      { slug: "cvv-settings", title: "CVV Settings", relationship: "related" },
      { slug: "vt-credit-card", title: "Credit Card Processing (Virtual Terminal)", relationship: "parent" },
    ],
    glossaryTerms: ["avs"],
    lastUpdated: "06 Jun 2025",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/35311037069969",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: [],
    complexity: "intermediate",
  },
  {
    id: "tp-008",
    slug: "cvv-settings",
    title: "Card ID Verification Settings (CVV)",
    audience: "merchant",
    category: "Transactions & Payments",
    categorySlug: "transactions-payments",
    subcategory: "Fraud Controls",
    summary: "Configure CVV rejection rules by issuer response codes, including per-processor and domestic vs international toggles.",
    whenToUse: "When setting up fraud controls or adjusting CVV verification rules.",
    prerequisites: ["Merchant Portal access with admin permissions"],
    requiredPermissions: ["Access Administrative Options", "Access Security Options"],
    navigationPath: "Merchant Portal → Options → Settings → CVV Settings",
    steps: [
      { stepNumber: 1, instruction: "Navigate to Merchant Portal → Options → Settings → CVV Settings." },
      { stepNumber: 2, instruction: "Configure rejection rules by CVV response codes." },
      { stepNumber: 3, instruction: "Optionally configure per-processor rules and domestic vs non-US toggles." },
      { stepNumber: 4, instruction: "Save changes. Use 'Show History' for audit trail." },
    ],
    screenshots: [
      "/merchant-portal/settings/card-id-verification-cvv-01.png",
    ],
    warnings: [],
    notes: [
      "CVV rules can be configured per-processor.",
      "Separate rules available for domestic (US) vs international cards.",
      "'Show History' provides an audit trail of changes.",
    ],
    faqs: [],
    troubleshooting: [],
    relatedTopics: [
      { slug: "avs-settings", title: "AVS Settings", relationship: "related" },
      { slug: "vt-credit-card", title: "Credit Card Processing (Virtual Terminal)", relationship: "parent" },
    ],
    glossaryTerms: ["cvv"],
    lastUpdated: "06 Jun 2025",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/35316724140945",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: [],
    complexity: "intermediate",
  },
  {
    id: "tp-009",
    slug: "blind-credits",
    title: "Blind Credits",
    audience: "both",
    category: "Transactions & Payments",
    categorySlug: "transactions-payments",
    subcategory: "Virtual Terminal",
    summary: "Blind credits are credits not tied to a previous transaction. High-risk capability that must be enabled by partners.",
    whenToUse: "When you need to issue a credit that is not associated with a previous transaction on the account.",
    prerequisites: ["Blind Credits enabled by partner in Partner Portal"],
    requiredPermissions: ["Partner must enable via Partner Portal", "Merchant Virtual Terminal access"],
    navigationPath: "Partner Portal → Merchant Account → Enable Blind Credits",
    steps: [
      { stepNumber: 1, instruction: "Partner: In Partner Portal, navigate to the merchant account settings." },
      { stepNumber: 2, instruction: "Enable the Blind Credits capability." },
      { stepNumber: 3, instruction: "Merchant: In Virtual Terminal, the Credit transaction type becomes available." },
    ],
    screenshots: [],
    warnings: [
      "Blind credits carry significant risk. They cannot be reversed once processed. NMI is not responsible for misuse.",
    ],
    notes: [
      "Blind credits are not tied to a previous transaction and 'cannot be taken back' once processed.",
      "NMI notes risk review requirements and that the gateway is not responsible for misuse.",
    ],
    faqs: [],
    troubleshooting: [],
    relatedTopics: [
      { slug: "vt-credit-card", title: "Credit Card Processing (Virtual Terminal)", relationship: "parent" },
    ],
    glossaryTerms: ["blind-credit"],
    lastUpdated: "06 Dec 2024",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/30728947529489",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: [],
    complexity: "advanced",
  },
  {
    id: "tp-010",
    slug: "vt-form-customization",
    title: "Virtual Terminal Form Customization",
    audience: "merchant",
    category: "Transactions & Payments",
    categorySlug: "transactions-payments",
    subcategory: "Virtual Terminal",
    summary: "Customize which fields are shown/hidden in the Virtual Terminal on a per-user, per-transaction-type basis.",
    whenToUse: "When you want to simplify the VT interface by hiding fields not relevant to your business.",
    prerequisites: ["Merchant Portal access"],
    requiredPermissions: ["Access Administrative Options"],
    navigationPath: "Merchant Portal → Options → Settings → Virtual Terminal Form Customization",
    steps: [
      { stepNumber: 1, instruction: "Navigate to Merchant Portal → Options → Settings → Virtual Terminal Form Customization." },
      { stepNumber: 2, instruction: "Select the user and transaction type to customize." },
      { stepNumber: 3, instruction: "Toggle fields on/off to match your business needs." },
      { stepNumber: 4, instruction: "Save changes." },
    ],
    screenshots: [],
    warnings: [],
    notes: [
      "Customization is per-user and per-transaction type.",
      "Void and Refund forms have no customization options.",
    ],
    faqs: [],
    troubleshooting: [],
    relatedTopics: [
      { slug: "vt-credit-card", title: "Credit Card Processing (Virtual Terminal)", relationship: "parent" },
      { slug: "merchant-defined-fields", title: "Merchant Defined Fields", relationship: "related" },
    ],
    glossaryTerms: ["virtual-terminal"],
    lastUpdated: "19 Sep 2023",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/15544482373009",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: [],
    complexity: "beginner",
  },
  {
    id: "tp-011",
    slug: "txt2pay",
    title: "Authvia TXT2PAY (Virtual Terminal)",
    audience: "merchant",
    category: "Transactions & Payments",
    categorySlug: "transactions-payments",
    subcategory: "Virtual Terminal",
    summary: "Start, manage, and close SMS payment conversations via TXT2PAY. Includes expiration behaviour and refund/void via reporting.",
    whenToUse: "When processing payments via SMS text messaging.",
    prerequisites: ["TXT2PAY/Authvia enabled on account"],
    requiredPermissions: ["Virtual Terminal access", "TXT2PAY access"],
    navigationPath: "Merchant Portal → Virtual Terminal → TXT2PAY",
    steps: [
      { stepNumber: 1, instruction: "Navigate to Merchant Portal → Virtual Terminal → TXT2PAY." },
      { stepNumber: 2, instruction: "Start a new SMS payment conversation by entering the customer's phone number and amount." },
      { stepNumber: 3, instruction: "The customer receives an SMS with a payment link." },
      { stepNumber: 4, instruction: "Monitor conversation status. Conversations expire after a set period." },
      { stepNumber: 5, instruction: "For refunds/voids, use the Reporting section to find the transaction." },
    ],
    screenshots: [],
    warnings: [],
    notes: [
      "Payment conversations expire automatically if not completed.",
      "Refunds and voids for TXT2PAY transactions are managed through Reporting, not the TXT2PAY interface.",
    ],
    faqs: [],
    troubleshooting: [],
    relatedTopics: [
      { slug: "vt-credit-card", title: "Credit Card Processing (Virtual Terminal)", relationship: "parent" },
      { slug: "transaction-reports", title: "Transaction Reports", relationship: "related" },
    ],
    glossaryTerms: ["txt2pay"],
    lastUpdated: "12 Mar 2025",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/16400582360081",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: ["TXT2PAY conversation expiration duration not specified in source report."],
    complexity: "intermediate",
  },

  // ── Reporting ──
  {
    id: "rp-001",
    slug: "transaction-reports",
    title: "Transaction Reports",
    audience: "merchant",
    category: "Reporting",
    categorySlug: "reporting",
    subcategory: "Transaction Reports",
    summary: "Transaction Snapshot vs Search Transactions, settlement batch reporting, resettle flows, and drill-downs by source/user/processor.",
    whenToUse: "When looking up transactions, reconciling settlements, or investigating transaction details.",
    prerequisites: ["Merchant Portal access"],
    requiredPermissions: ["Access Transaction Reports"],
    navigationPath: "Merchant Portal → Reporting → Transactions",
    steps: [
      { stepNumber: 1, instruction: "Navigate to Merchant Portal → Reporting → Transactions." },
      { stepNumber: 2, instruction: "Choose Transaction Snapshot for grouped overview (by settlement batch, payment type, processor, user, source, time period)." },
      { stepNumber: 3, instruction: "Or use Search Transactions for specific criteria including merchant defined fields." },
      { stepNumber: 4, instruction: "Drill down into individual transactions for full details." },
    ],
    screenshots: [
      "/merchant-portal/reporting/transaction-reports-01.png",
      "/merchant-portal/reporting/transaction-reports-02.png",
      "/merchant-portal/reporting/transaction-reports-03.png",
      "/merchant-portal/reporting/transaction-reports-04.png",
      "/merchant-portal/reporting/transaction-reports-05.png",
      "/merchant-portal/reporting/transaction-reports-06.png",
    ],
    warnings: [],
    notes: [
      "Transaction Snapshot provides grouped overviews: settlement batches, payment type, processor, user, source, day/week/month.",
      "Search Transactions offers more specific criteria and includes merchant defined fields.",
      "You can resettle failed batches: select the failed batch and click 'Resettle Batches'.",
    ],
    faqs: [
      { question: "How do I resettle a failed batch?", answer: "In Transaction Reports, find the failed settlement batch, select it, and click 'Resettle Batches'." },
    ],
    troubleshooting: [
      { issue: "Cannot find a transaction", cause: "May be looking in wrong mode (test vs live) or wrong date range", verify: "Check test mode toggle and expand date range", fix: "Switch between test/live mode and adjust search criteria" },
    ],
    relatedTopics: [
      { slug: "settlement-schedule", title: "Settlement Schedule", relationship: "related" },
      { slug: "report-configuration", title: "Report Configuration", relationship: "child" },
      { slug: "subscription-reports", title: "Subscription Reports", relationship: "related" },
      { slug: "test-mode", title: "Test Mode", relationship: "troubleshooting" },
    ],
    glossaryTerms: ["transaction-snapshot", "resettle"],
    lastUpdated: "17 Feb 2026",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/15274363136785",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: [],
    complexity: "beginner",
  },
  {
    id: "rp-002",
    slug: "report-configuration",
    title: "Report Configuration",
    audience: "merchant",
    category: "Reporting",
    categorySlug: "reporting",
    subcategory: "Report Templates",
    summary: "Build custom CSV/XLS download templates for reports and set defaults to streamline recurring exports.",
    whenToUse: "When you frequently export reports and want to pre-configure which fields are included.",
    prerequisites: ["Merchant Portal access"],
    requiredPermissions: ["Access Administrative Options"],
    navigationPath: "Merchant Portal → Options → Settings → Report Configuration",
    steps: [
      { stepNumber: 1, instruction: "Navigate to Merchant Portal → Options → Settings → Report Configuration." },
      { stepNumber: 2, instruction: "Create a new report template." },
      { stepNumber: 3, instruction: "Select which fields to include in your CSV/XLS export." },
      { stepNumber: 4, instruction: "Set as default to avoid selecting fields each time you export." },
    ],
    screenshots: [
      "/merchant-portal/reporting/report-configuration-01.png",
      "/merchant-portal/reporting/report-configuration-02.png",
      "/merchant-portal/reporting/report-configuration-03.png",
      "/merchant-portal/reporting/report-configuration-04.png",
      "/merchant-portal/reporting/report-configuration-05.png",
    ],
    warnings: [],
    notes: [
      "Templates streamline recurring report exports by pre-selecting fields.",
      "Can be set as the default template for all report downloads.",
    ],
    faqs: [],
    troubleshooting: [],
    relatedTopics: [
      { slug: "transaction-reports", title: "Transaction Reports", relationship: "parent" },
      { slug: "subscription-reports", title: "Subscription Reports", relationship: "related" },
    ],
    glossaryTerms: [],
    lastUpdated: "02 Mar 2023",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/13263155847697",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: [],
    complexity: "beginner",
  },

  // ── Subscriptions & Recurring ──
  {
    id: "sr-001",
    slug: "subscription-reports",
    title: "Subscription Reports",
    audience: "merchant",
    category: "Subscriptions & Recurring",
    categorySlug: "subscriptions-recurring",
    subcategory: "Subscription Management",
    summary: "Search, pause/resume, download, and manage recurring subscriptions with comprehensive filtering.",
    whenToUse: "When managing recurring billing subscriptions, investigating subscription status, or generating subscription reports.",
    prerequisites: ["Merchant Portal access", "Recurring/subscription functionality enabled"],
    requiredPermissions: ["Access Recurring/Installment Reports"],
    navigationPath: "Merchant Portal → Reporting → Subscriptions",
    steps: [
      { stepNumber: 1, instruction: "Navigate to Merchant Portal → Reporting → Subscriptions." },
      { stepNumber: 2, instruction: "Search by criteria: subscription IDs, customer names, account number (last-4 or full), plans, amount range, date ranges, or merchant defined fields." },
      { stepNumber: 3, instruction: "From results, you can pause/resume individual or all subscriptions." },
      { stepNumber: 4, instruction: "Download subscription lists in XLS or CSV format." },
    ],
    screenshots: [
      "/merchant-portal/reporting/subscription-reports-01.png",
      "/merchant-portal/reporting/subscription-reports-02.png",
      "/merchant-portal/reporting/subscription-reports-03.png",
      "/merchant-portal/reporting/subscription-reports-04.png",
      "/merchant-portal/reporting/subscription-reports-05.png",
      "/merchant-portal/reporting/subscription-reports-06.png",
    ],
    warnings: [],
    notes: [
      "Supports comprehensive search criteria including merchant defined fields.",
      "Pause/resume can be applied to individual subscriptions or in bulk.",
    ],
    faqs: [],
    troubleshooting: [],
    relatedTopics: [
      { slug: "transaction-reports", title: "Transaction Reports", relationship: "related" },
      { slug: "report-configuration", title: "Report Configuration", relationship: "related" },
      { slug: "auto-card-updater", title: "Automatic Card Updater", relationship: "related" },
    ],
    glossaryTerms: [],
    lastUpdated: "16 May 2025",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/16096543375505",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: [],
    complexity: "beginner",
  },
  {
    id: "sr-002",
    slug: "auto-card-updater",
    title: "Automatic Card Updater Settings",
    audience: "merchant",
    category: "Subscriptions & Recurring",
    categorySlug: "subscriptions-recurring",
    subcategory: "Card Updater",
    summary: "Configure Automatic Card Updater (ACU) cadence and eligibility for vault and recurring card payments.",
    whenToUse: "When you want to automatically update stored card information to reduce declines from expired or reissued cards.",
    prerequisites: ["ACU service enabled on account"],
    requiredPermissions: ["Access Administrative Options"],
    navigationPath: "Merchant Portal → Options → Settings → Automatic Card Updater",
    steps: [
      { stepNumber: 1, instruction: "Navigate to Merchant Portal → Options → Settings → Automatic Card Updater." },
      { stepNumber: 2, instruction: "Configure the update cadence (how often cards are checked)." },
      { stepNumber: 3, instruction: "Set eligibility criteria for which vault/recurring cards should be included." },
      { stepNumber: 4, instruction: "Save changes." },
    ],
    screenshots: [
      "/merchant-portal/settings/automatic-card-updater-01.png",
      "/merchant-portal/settings/automatic-card-updater-02.png",
      "/merchant-portal/settings/automatic-card-updater-03.png",
      "/merchant-portal/settings/automatic-card-updater-05.png",
      "/merchant-portal/settings/automatic-card-updater-06.png",
      "/merchant-portal/settings/automatic-card-updater-07.png",
      "/merchant-portal/settings/automatic-card-updater-08.png",
      "/merchant-portal/settings/automatic-card-updater-09.png",
      "/merchant-portal/settings/automatic-card-updater-10.png",
      "/merchant-portal/settings/automatic-card-updater-11.png",
    ],
    warnings: [],
    notes: [
      "ACU checks stored cards against card network databases and updates expired/reissued cards automatically.",
      "Requires admin permission and the ACU service to be enabled on the account.",
    ],
    faqs: [],
    troubleshooting: [],
    relatedTopics: [
      { slug: "subscription-reports", title: "Subscription Reports", relationship: "related" },
    ],
    glossaryTerms: ["acu"],
    lastUpdated: "19 May 2025",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/13585909512721",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: [],
    complexity: "intermediate",
  },

  // ── Integrations & Security Keys ──
  {
    id: "ia-001",
    slug: "security-key-migration",
    title: "Migrating to Security Key Authentication",
    audience: "both",
    category: "Integrations & Security Keys",
    categorySlug: "integrations-api",
    subcategory: "API Keys",
    summary: "NMI's security programme requires migration from username/password to API key (security_key) authentication by end of 2026.",
    whenToUse: "When planning your integration migration strategy or when transitioning from username/password API authentication.",
    prerequisites: ["Active Merchant Portal account", "Existing API integration using username/password"],
    requiredPermissions: ["Access Administrative Options", "Security Key management access"],
    navigationPath: "Merchant Portal → Options → Settings → Security Keys",
    steps: [
      { stepNumber: 1, instruction: "In Merchant Portal, navigate to Settings → Security Keys." },
      { stepNumber: 2, instruction: "Click to create a new API key. Provide a key name and associate it with a username." },
      { stepNumber: 3, instruction: "Select the appropriate permission type for the key." },
      { stepNumber: 4, instruction: "In your integration code, remove the 'username' and 'password' fields from API requests." },
      { stepNumber: 5, instruction: "Add 'security_key=<YOUR_KEY>' parameter instead. Keep the rest of the request unchanged." },
    ],
    screenshots: [],
    warnings: [
      "Do not share private API keys publicly. Use tokenization keys for client-side implementations.",
    ],
    notes: [
      "The security programme also requires: 2FA or 90-day password resets, 12-character minimum passwords, and separate management for API/SFTP credentials.",
      "By end of 2026, API key authentication will be mandatory.",
      "Key types include: API keys (private, for server-side), Cart/QuickClick keys, and Tokenization keys (public, for Collect.js).",
    ],
    faqs: [
      { question: "When is API key authentication mandatory?", answer: "NMI states that by end of 2026, merchants will be required to use API key authentication instead of username/password." },
      { question: "What key types are available?", answer: "API keys (private, server-side), Cart/QuickClick keys, and Tokenization keys (public, for Collect.js client-side use)." },
    ],
    troubleshooting: [
      { issue: "API authentication fails after migration", cause: "Invalid security key, wrong key type, or IP restrictions blocking the request", verify: "Confirm the key value is exact, the key type matches your use case, and your IP is allowlisted", fix: "Regenerate the key if needed; check IP restrictions; verify endpoint URL", escalation: "Review the Authentication Errors troubleshooting guide" },
    ],
    relatedTopics: [
      { slug: "authentication-errors", title: "Authentication Errors", relationship: "troubleshooting" },
      { slug: "ip-restrictions", title: "IP Restrictions", relationship: "related" },
      { slug: "two-factor-authentication", title: "Two-Factor Authentication", relationship: "related" },
      { slug: "collectjs-setup", title: "Collect.js Integration", relationship: "child" },
    ],
    glossaryTerms: ["api-key", "tokenization"],
    lastUpdated: "10 Sep 2025",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/37611045020049",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: [
      "Security Keys guidance is split between an older 2019 support article and newer docs pages. Source report recommends confirming which model is canonical for 2026 merchants.",
    ],
    complexity: "advanced",
  },
  {
    id: "ia-002",
    slug: "authentication-errors",
    title: "Authentication Errors Troubleshooting",
    audience: "both",
    category: "Integrations & Security Keys",
    categorySlug: "integrations-api",
    subcategory: "API Keys",
    summary: "Troubleshooting for API authentication failures including security key validation, IP restrictions, and endpoint verification.",
    whenToUse: "When your API integration returns authentication errors.",
    prerequisites: ["Active API integration", "Security keys configured"],
    requiredPermissions: ["API access"],
    navigationPath: "N/A — API-level troubleshooting",
    steps: [
      { stepNumber: 1, instruction: "Verify the security key value is exactly correct (no extra spaces or characters)." },
      { stepNumber: 2, instruction: "Confirm the key is associated with the correct merchant account." },
      { stepNumber: 3, instruction: "Check that the key type matches your use case (API vs tokenization vs cart)." },
      { stepNumber: 4, instruction: "Verify your request is using the correct endpoint URL." },
      { stepNumber: 5, instruction: "Check IP restrictions—ensure the requesting server's IP is allowlisted." },
    ],
    screenshots: [],
    warnings: [],
    notes: [
      "Common causes: invalid key, wrong account, wrong key type, incorrect endpoint, IP not allowlisted.",
    ],
    faqs: [],
    troubleshooting: [
      { issue: "API returns authentication failure", cause: "Invalid security key, wrong key type, or IP restriction", verify: "Check key value, key type, endpoint URL, and IP allowlist", fix: "Correct the key, endpoint, or add IP to allowlist", escalation: "Contact NMI support if all values are verified correct" },
    ],
    relatedTopics: [
      { slug: "security-key-migration", title: "Security Key Migration", relationship: "parent" },
      { slug: "ip-restrictions", title: "IP Restrictions", relationship: "related" },
    ],
    glossaryTerms: ["api-key"],
    lastUpdated: "09 Feb 2026",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/15366717872785",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: [],
    complexity: "intermediate",
  },
  {
    id: "ia-003",
    slug: "collectjs-setup",
    title: "Collect.js Integration",
    audience: "merchant",
    category: "Integrations & Security Keys",
    categorySlug: "integrations-api",
    subcategory: "Hosted Checkout",
    summary: "Set up Collect.js for client-side tokenization. Create a public tokenization key in Merchant Portal, add the script tag, and submit tokens via Payment API.",
    whenToUse: "When implementing a custom payment form that needs client-side card tokenization.",
    prerequisites: ["Merchant Portal access", "Web development knowledge"],
    requiredPermissions: ["Security Key management access"],
    navigationPath: "Merchant Portal → Options → Settings → Security Keys",
    steps: [
      { stepNumber: 1, instruction: "In Merchant Portal, navigate to Settings → Security Keys." },
      { stepNumber: 2, instruction: "Create a new public Tokenization key." },
      { stepNumber: 3, instruction: "Add the Collect.js script tag to your web page with the data-tokenization-key attribute." },
      { stepNumber: 4, instruction: "Embed the Collect.js fields in your payment form." },
      { stepNumber: 5, instruction: "On form submission, capture the token and submit it server-side via the Payment API." },
    ],
    screenshots: [],
    warnings: [
      "Never expose private API keys in client-side code. Use only the public Tokenization key with Collect.js.",
    ],
    notes: [
      "Tokens are single-use and expire after 24 hours.",
      "Apple Pay can be enabled in Merchant Portal Settings for use with Collect.js.",
      "Use a public Tokenization key (not a private API key) for client-side implementation.",
    ],
    faqs: [
      { question: "How long do tokens last?", answer: "Tokens are single-use and expire after 24 hours." },
    ],
    troubleshooting: [],
    relatedTopics: [
      { slug: "security-key-migration", title: "Security Key Migration", relationship: "parent" },
      { slug: "collect-checkout", title: "Collect Checkout", relationship: "related" },
    ],
    glossaryTerms: ["collectjs", "tokenization", "api-key"],
    lastUpdated: "2025",
    sourceReference: "https://docs.nmi.com/docs/collectjs",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: ["Exact Collect.js script tag URL not reproduced in source report."],
    complexity: "advanced",
  },
  {
    id: "ia-004",
    slug: "collect-checkout",
    title: "Collect Checkout",
    audience: "merchant",
    category: "Integrations & Security Keys",
    categorySlug: "integrations-api",
    subcategory: "Hosted Checkout",
    summary: "Hosted checkout/cart with button generator for sale, donation, and vault. Customize look & feel, manage URL allowlists, and embed on your website.",
    whenToUse: "When you want to create hosted payment pages or embedded checkout buttons without custom coding.",
    prerequisites: ["Merchant Portal access", "Products created in Product Manager (optional)"],
    requiredPermissions: ["Collect Checkout access"],
    navigationPath: "Merchant Portal → Collect Checkout",
    steps: [
      { stepNumber: 1, instruction: "Navigate to Merchant Portal → Collect Checkout." },
      { stepNumber: 2, instruction: "Use the button generator to create a checkout button (types: sale, donation, vault)." },
      { stepNumber: 3, instruction: "Customize the look & feel of the checkout page." },
      { stepNumber: 4, instruction: "Configure the URL allowlist for where the checkout can be embedded." },
      { stepNumber: 5, instruction: "Copy the generated HTML/URL and embed on your website." },
    ],
    screenshots: [],
    warnings: [],
    notes: [
      "Checkout types include: Sale, Donation, and Vault (for storing payment info without charging).",
      "The URL allowlist controls which domains can embed your checkout.",
      "View checkout history from the Collect Checkout section.",
    ],
    faqs: [],
    troubleshooting: [],
    relatedTopics: [
      { slug: "product-manager", title: "Product Manager", relationship: "related" },
      { slug: "quickclick", title: "QuickClick", relationship: "related" },
      { slug: "collectjs-setup", title: "Collect.js Integration", relationship: "related" },
    ],
    glossaryTerms: ["collect-checkout"],
    lastUpdated: "27 Feb 2025",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/31821389741201",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: [],
    complexity: "intermediate",
  },
  {
    id: "ia-005",
    slug: "quickclick",
    title: "QuickClick",
    audience: "merchant",
    category: "Integrations & Security Keys",
    categorySlug: "integrations-api",
    subcategory: "Hosted Checkout",
    summary: "Hosted cart/button solution for payments. Create buttons, customize, view history, and configure fees.",
    whenToUse: "When you need a simple hosted payment button solution for your website.",
    prerequisites: ["Merchant Portal access", "QuickClick enabled on account"],
    requiredPermissions: ["QuickClick access"],
    navigationPath: "Merchant Portal → QuickClick",
    steps: [
      { stepNumber: 1, instruction: "Navigate to Merchant Portal → QuickClick." },
      { stepNumber: 2, instruction: "Create a new payment button with the desired amount and configuration." },
      { stepNumber: 3, instruction: "Customize the button appearance." },
      { stepNumber: 4, instruction: "Configure fee settings if applicable." },
      { stepNumber: 5, instruction: "Copy the generated code and embed on your website." },
    ],
    screenshots: [],
    warnings: [],
    notes: [
      "Cash discounting is not supported with QuickClick.",
      "QuickClick uses Cart security keys.",
    ],
    faqs: [],
    troubleshooting: [],
    relatedTopics: [
      { slug: "collect-checkout", title: "Collect Checkout", relationship: "related" },
      { slug: "product-manager", title: "Product Manager", relationship: "related" },
    ],
    glossaryTerms: ["quickclick"],
    lastUpdated: "15 Jan 2025",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/16162258857617",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: [],
    complexity: "intermediate",
  },
  {
    id: "ia-006",
    slug: "product-manager",
    title: "Product Manager",
    audience: "merchant",
    category: "Integrations & Security Keys",
    categorySlug: "integrations-api",
    subcategory: "Product Management",
    summary: "Create and manage products, packages, and categories. Products appear in Virtual Terminal, Collect Checkout, iProcess, invoicing, and batch upload.",
    whenToUse: "When you need to set up a product catalog for use across NMI payment interfaces.",
    prerequisites: ["Merchant Portal access"],
    requiredPermissions: ["Product Manager access"],
    navigationPath: "Merchant Portal → Product Manager",
    steps: [
      { stepNumber: 1, instruction: "Navigate to Merchant Portal → Product Manager." },
      { stepNumber: 2, instruction: "Create categories to organize your products." },
      { stepNumber: 3, instruction: "Add products with name, description, price, and other details." },
      { stepNumber: 4, instruction: "Optionally create packages (bundles of products)." },
    ],
    screenshots: [],
    warnings: [],
    notes: [
      "Products created here appear across: Virtual Terminal, Collect Checkout, iProcess, invoicing, and batch upload.",
    ],
    faqs: [],
    troubleshooting: [],
    relatedTopics: [
      { slug: "collect-checkout", title: "Collect Checkout", relationship: "related" },
      { slug: "quickclick", title: "QuickClick", relationship: "related" },
    ],
    glossaryTerms: ["product-manager"],
    lastUpdated: "07 Apr 2025",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/33587452054161",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: [],
    complexity: "beginner",
  },
  {
    id: "ia-007",
    slug: "device-registration",
    title: "Device Registration",
    audience: "merchant",
    category: "Integrations & Security Keys",
    categorySlug: "integrations-api",
    subcategory: "Device Registration",
    summary: "Register payment devices (terminals) in Merchant Portal manually or via API for Customer Present Cloud processing.",
    whenToUse: "When setting up physical payment terminals for card-present transactions.",
    prerequisites: ["Merchant Portal access", "Compatible payment device"],
    requiredPermissions: ["Device management access"],
    navigationPath: "Merchant Portal → Registered Devices (licence manager)",
    steps: [
      { stepNumber: 1, instruction: "Navigate to Merchant Portal → Registered Devices in the licence manager." },
      { stepNumber: 2, instruction: "Click to register a new device." },
      { stepNumber: 3, instruction: "Enter the device details as required." },
      { stepNumber: 4, instruction: "Alternatively, use the API registration endpoint with a bearer token." },
    ],
    screenshots: [],
    warnings: [],
    notes: ["Manual registration is done in Merchant Portal; API registration uses a bearer token."],
    faqs: [],
    troubleshooting: [],
    relatedTopics: [
      { slug: "security-key-migration", title: "Security Key Migration", relationship: "related" },
    ],
    glossaryTerms: [],
    lastUpdated: "2025",
    sourceReference: "https://docs.nmi.com/docs/registering-your-device",
    sourceConfidence: "medium",
    unsupportedOrMissingNotes: ["API registration endpoint URL not reproduced in the source report."],
    complexity: "advanced",
  },
  {
    id: "ia-008",
    slug: "what-is-ach",
    title: "What is ACH?",
    audience: "both",
    category: "Integrations & Security Keys",
    categorySlug: "integrations-api",
    subcategory: "ACH Reference",
    summary: "ACH concepts and operational guidance: setup, returns/errors, NACHA compliance, SEC codes, and where ACH can be used in Merchant Portal.",
    whenToUse: "When learning about ACH payment processing or troubleshooting ACH-related issues.",
    prerequisites: ["Basic understanding of payment processing"],
    requiredPermissions: [],
    navigationPath: "N/A — reference article",
    steps: [],
    screenshots: [
      "/merchant-portal/transactions/what-is-ach-01.png",
    ],
    warnings: [
      "ACH returns can occur well after the transaction appears settled. Monitor return reports regularly.",
    ],
    notes: [
      "ACH (Automated Clearing House) is a US-based electronic payment system.",
      "ACH transactions require SEC (Standard Entry Class) codes for NACHA compliance.",
      "Common SEC codes: WEB (internet-initiated), TEL (telephone-initiated), PPD (prearranged payment).",
      "ACH returns can occur up to 60 days after processing for certain return codes.",
      "The default SEC code for Virtual Terminal eCheck is typically WEB.",
    ],
    faqs: [
      { question: "What SEC code should I use?", answer: "WEB for internet-initiated, TEL for telephone-initiated, PPD for prearranged payments. The default in VT is typically WEB." },
    ],
    troubleshooting: [
      { issue: "ACH transaction returned", cause: "Various: insufficient funds, closed account, invalid account number", verify: "Check Transaction Details for Gateway Response Text/Code", fix: "Contact the customer for updated payment information and retry", escalation: "For persistent issues, review NACHA return code documentation" },
    ],
    relatedTopics: [
      { slug: "vt-echeck", title: "eCheck Processing (Virtual Terminal)", relationship: "child" },
      { slug: "sec-code-configuration", title: "SEC Code Configuration", relationship: "child" },
    ],
    glossaryTerms: ["ach", "sec-code", "nacha"],
    lastUpdated: "03 Mar 2025",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/33001771533073",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: ["ACH return code reference table not included in source report."],
    complexity: "intermediate",
  },
  // ── Direct Connect ──
  {
    id: "ia-009",
    slug: "direct-connect-error-codes",
    title: "Approvals, Declines & Errors (Direct Connect)",
    audience: "both",
    category: "Integrations & Security Keys",
    categorySlug: "integrations-api",
    subcategory: "Direct Connect",
    summary: "Complete reference of Direct Connect result codes and error codes returned when processing API requests. Use this to diagnose declined transactions and integration errors.",
    whenToUse: "When your integration receives an error or decline from the Direct Connect API and you need to understand the cause and resolution.",
    prerequisites: ["Active Direct Connect integration", "Basic understanding of API request/response flow"],
    requiredPermissions: [],
    navigationPath: "N/A — reference article",
    steps: [],
    screenshots: [],
    warnings: [
      "If an error code is returned, the result code will always be 01 (declined) and the request will not be sent to the acquirer/processor.",
      "If a Confirm request fails, the transaction will not be sent for settlement and you will not receive the funds until the Confirm is successful.",
    ],
    notes: [
      "Result code 01 (declined) with no error code typically means a bank decline for Authorization/PreAuth requests.",
      "If either a result code of 01 or an error is returned, goods should not be provided to the customer for Authorization requests.",
      "For Confirm/Void requests that fail, retry after the error has been rectified within your integration.",
      "Error codes in the 1xxx range relate to card or input validation issues.",
      "Error codes in the 2xxx range relate to terminal, transaction, or reference issues.",
      "Error codes in the 3xxx range relate to NMI platform issues (API keys, configuration, access).",
      "Error codes in the 7xxx range indicate temporary platform unavailability.",
      "Error codes in the 8xxx range relate to XML request formatting issues.",
    ],
    faqs: [
      { question: "What does result code 01 with no error code mean?", answer: "For Authorization/PreAuth requests, this normally indicates a decline from the issuing bank. The request was sent to the acquirer/processor but was not approved." },
      { question: "Should I retry after an error?", answer: "For Confirm/Void requests, yes — retry after rectifying the error. For Authorization requests, do not provide goods until a successful response is received." },
      { question: "What does error 3002 (Invalid API Key) mean?", answer: "The API key wasn't valid. It must be exactly 32 characters with valid characters. Check your security key configuration in Merchant Portal." },
    ],
    troubleshooting: [
      { issue: "Error 3001/3002 — API Key Missing or Invalid", cause: "API key not included in the request or malformed (not 32 characters)", verify: "Check your request headers/parameters for the API key field", fix: "Generate a new API key in Merchant Portal under Settings → Security Keys and update your integration", escalation: "Contact your partner if you cannot generate new keys" },
      { issue: "Error 3025 — Merchant Configuration Error", cause: "Merchant account is misconfigured on the platform", verify: "Confirm your account is active and properly set up", fix: "Contact your partner or NMI support to review account configuration", escalation: "Partner to review merchant setup in Partner Portal" },
      { issue: "Error 2200-2204 — Transaction state issues", cause: "Transaction not found, already settled, voided, refunded, or originally declined", verify: "Look up the transaction in Transaction Reports to check its current status", fix: "Ensure you are referencing the correct transaction ID and that the requested action is valid for its current state" },
    ],
    relatedTopics: [
      { slug: "security-key-migration", title: "Security Key Migration", relationship: "related" },
      { slug: "authentication-errors", title: "Authentication Errors", relationship: "troubleshooting" },
      { slug: "vt-credit-card", title: "Virtual Terminal — Credit Card", relationship: "related" },
    ],
    glossaryTerms: ["api-key", "capture"],
    lastUpdated: "10 Mar 2025",
    sourceReference: "https://support.nmi.com/hc/en-gb/articles/13362752267153-Approvals-Declines-Errors",
    sourceConfidence: "high",
    unsupportedOrMissingNotes: [],
    complexity: "advanced",
  },
];

// ─────────────────────────────────────────────────────
// GLOSSARY — with multi-guide references
// ─────────────────────────────────────────────────────

export const glossaryTerms: GlossaryTerm[] = [
  { id: "2fa", term: "2FA (Two-Factor Authentication)", definition: "A security method requiring two forms of identification to access the Merchant Portal: your password plus a time-based code from Google Authenticator.", relatedGuides: ["two-factor-authentication", "password-rotation"] },
  { id: "google-authenticator", term: "Google Authenticator", definition: "A mobile app by Google that generates time-based one-time passwords (TOTP) for 2FA. Required by NMI for merchant 2FA.", relatedGuides: ["two-factor-authentication"] },
  { id: "ach", term: "ACH (Automated Clearing House)", definition: "A US-based electronic payment network used for bank-to-bank transfers. ACH transactions in NMI are batched daily with typical 3–5 day funding.", relatedGuides: ["what-is-ach", "vt-echeck"] },
  { id: "acu", term: "ACU (Automatic Card Updater)", definition: "A service that automatically checks stored card information against card network databases and updates expired or reissued cards to reduce payment declines.", relatedGuides: ["auto-card-updater"] },
  { id: "api-key", term: "API Key / Security Key", definition: "A credential used to authenticate API requests. NMI offers three types: private API keys (server-side), Cart/QuickClick keys, and public Tokenization keys (client-side).", relatedGuides: ["security-key-migration", "authentication-errors", "collectjs-setup"] },
  { id: "avs", term: "AVS (Address Verification System)", definition: "A fraud prevention system that compares the billing address provided in a transaction with the address on file at the card issuer.", relatedGuides: ["avs-settings"] },
  { id: "blind-credit", term: "Blind Credit", definition: "A credit transaction not tied to any previous sale. High risk because it cannot be reversed and is enabled by partners only.", relatedGuides: ["blind-credits", "vt-credit-card"] },
  { id: "capture", term: "Capture", definition: "The process of settling a previously authorized transaction. Moves the transaction from 'authorized' to 'pending settlement'.", relatedGuides: ["vt-credit-card"] },
  { id: "collect-checkout", term: "Collect Checkout", definition: "NMI's hosted checkout/cart solution with a button generator for sale, donation, and vault-only transactions.", relatedGuides: ["collect-checkout"] },
  { id: "collectjs", term: "Collect.js", definition: "NMI's client-side JavaScript library for secure tokenization of payment data. Tokens are single-use and expire after 24 hours.", relatedGuides: ["collectjs-setup"] },
  { id: "cvv", term: "CVV (Card Verification Value)", definition: "The 3 or 4 digit security code on a payment card used for card-not-present transaction verification.", relatedGuides: ["cvv-settings"] },
  { id: "host-capture", term: "Host Capture", definition: "A settlement model where the processor controls when the batch settles, as opposed to terminal capture where the gateway controls timing.", relatedGuides: ["settlement-schedule"] },
  { id: "ip-restrictions", term: "IP Restrictions", definition: "A security feature that limits Merchant Portal and/or API access to specific allowlisted IP addresses or hostnames.", relatedGuides: ["ip-restrictions"] },
  { id: "level-iii-data", term: "Level III Data", definition: "Enhanced transaction data (line items, tax, shipping) that can qualify B2B/B2G transactions for lower interchange rates.", relatedGuides: ["level-iii-template"] },
  { id: "merchant-defined-fields", term: "Merchant Defined Fields (MDF)", definition: "Up to 20 custom fields created by merchants for capturing additional data with transactions. Available across VT, API, QuickClick, Collect Checkout, and recurring.", relatedGuides: ["merchant-defined-fields"] },
  { id: "merchant-portal", term: "Merchant Portal", definition: "NMI's web-based interface for merchants to manage transactions, settings, reporting, and integrations. Accessed at secure.nmi.com.", relatedGuides: ["portal-access-logins"] },
  { id: "msp", term: "MSP (Merchant Service Provider)", definition: "The partner/reseller that provides payment processing services to a merchant through NMI.", relatedGuides: ["msp-contact-details", "account-information"] },
  { id: "nacha", term: "NACHA", definition: "The National Automated Clearing House Association, which governs ACH payment rules and compliance requirements.", relatedGuides: ["what-is-ach", "sec-code-configuration"] },
  { id: "partner-portal", term: "Partner Portal", definition: "NMI's web-based interface for partners to manage merchant accounts, configurations, and support operations.", relatedGuides: ["portal-access-logins", "password-resets"] },
  { id: "product-manager", term: "Product Manager", definition: "A Merchant Portal feature for creating and managing products, packages, and categories used across VT, Collect Checkout, invoicing, and more.", relatedGuides: ["product-manager"] },
  { id: "quickclick", term: "QuickClick", definition: "NMI's hosted payment button solution for simple embeddable payment acceptance on websites.", relatedGuides: ["quickclick"] },
  { id: "refund", term: "Refund", definition: "The reversal of a settled transaction, returning funds to the original payment method up to the original transaction amount.", relatedGuides: ["vt-credit-card"] },
  { id: "resettle", term: "Resettle", definition: "The process of retrying a failed settlement batch. Done from Transaction Reports by selecting the failed batch.", relatedGuides: ["transaction-reports", "settlement-schedule"] },
  { id: "sec-code", term: "SEC Code (Standard Entry Class)", definition: "A code required by NACHA for ACH transactions that identifies the type of payment: WEB (internet), TEL (telephone), PPD (prearranged).", relatedGuides: ["sec-code-configuration", "what-is-ach"] },
  { id: "settlement", term: "Settlement", definition: "The process of transferring authorized transaction funds from the cardholder's bank to the merchant's bank account.", relatedGuides: ["settlement-schedule", "vt-credit-card"] },
  { id: "terminal-capture", term: "Terminal Capture", definition: "A settlement model where the gateway controls when the batch settles. The merchant can configure the cut-off time.", relatedGuides: ["settlement-schedule"] },
  { id: "test-mode", term: "Test Mode", definition: "An account-wide setting that isolates test transactions from live data. No funding occurs for test mode transactions.", relatedGuides: ["test-mode"] },
  { id: "tokenization", term: "Tokenization", definition: "The process of replacing sensitive payment data with a non-sensitive token. Used by Collect.js for secure client-side payment forms.", relatedGuides: ["collectjs-setup", "security-key-migration"] },
  { id: "transaction-routing", term: "Transaction Routing", definition: "The distribution of transaction volume across multiple processors using amount thresholds as percentage proxies.", relatedGuides: ["transaction-routing"] },
  { id: "transaction-snapshot", term: "Transaction Snapshot", definition: "A grouped overview of transactions in Transaction Reports, organized by settlement batch, payment type, processor, user, source, or time period.", relatedGuides: ["transaction-reports"] },
  { id: "txt2pay", term: "TXT2PAY", definition: "Authvia's SMS-based payment solution integrated with NMI's Virtual Terminal for sending payment links via text message.", relatedGuides: ["txt2pay"] },
  { id: "virtual-terminal", term: "Virtual Terminal (VT)", definition: "The Merchant Portal's interface for manually processing credit card and eCheck transactions without a physical terminal.", relatedGuides: ["vt-credit-card", "vt-echeck", "vt-form-customization"] },
  { id: "void", term: "Void", definition: "The cancellation of a transaction before it has settled. Unlike refunds, voids prevent the transaction from ever settling.", relatedGuides: ["vt-credit-card"] },
];

// ─────────────────────────────────────────────────────
// COMMON TASKS
// ─────────────────────────────────────────────────────

export const commonTasks: CommonTask[] = [
  { title: "Enable Two-Factor Authentication", description: "Set up Google Authenticator-based 2FA to secure your login and avoid 90-day password resets.", guideSlug: "two-factor-authentication", audience: "merchant", complexity: "beginner", permissions: ["Merchant login access"], category: "Authentication & Security" },
  { title: "Reset a Merchant Password", description: "Reset a forgotten or expired password for a merchant portal user.", guideSlug: "password-resets", audience: "both", complexity: "beginner", permissions: ["Partner: Administrative permissions"], category: "Authentication & Security" },
  { title: "Add a New Merchant User", description: "Create a new sub-user account with specific permissions and notifications.", guideSlug: "merchant-user-accounts", audience: "both", complexity: "beginner", permissions: ["Access Administrative Options"], category: "User Management" },
  { title: "Restrict Portal Access by IP", description: "Allowlist specific IP addresses for portal and API access.", guideSlug: "ip-restrictions", audience: "both", complexity: "intermediate", permissions: ["Access Security Options"], category: "Authentication & Security" },
  { title: "Process a Credit Card Sale", description: "Run a credit card sale transaction through the Virtual Terminal.", guideSlug: "vt-credit-card", audience: "merchant", complexity: "beginner", permissions: ["Virtual Terminal access"], category: "Payment Processing" },
  { title: "Process an eCheck/ACH Payment", description: "Run an eCheck transaction through the Virtual Terminal.", guideSlug: "vt-echeck", audience: "merchant", complexity: "beginner", permissions: ["Virtual Terminal access", "eCheck enabled"], category: "Payment Processing" },
  { title: "Enable or Disable Test Mode", description: "Toggle test mode for safe testing without affecting live data.", guideSlug: "test-mode", audience: "both", complexity: "beginner", permissions: ["Access Administrative Options"], category: "Configuration" },
  { title: "Look Up a Transaction", description: "Search for and view transaction details in reporting.", guideSlug: "transaction-reports", audience: "merchant", complexity: "beginner", permissions: ["Access Transaction Reports"], category: "Reporting" },
  { title: "Manage Subscriptions", description: "Search, pause, resume, and download subscription reports.", guideSlug: "subscription-reports", audience: "merchant", complexity: "beginner", permissions: ["Access Recurring Reports"], category: "Reporting" },
  { title: "Create a Security Key / API Key", description: "Generate API keys for integration authentication.", guideSlug: "security-key-migration", audience: "both", complexity: "intermediate", permissions: ["Security Key management"], category: "Integrations" },
  { title: "Set Up Collect Checkout", description: "Create hosted checkout buttons for your website.", guideSlug: "collect-checkout", audience: "merchant", complexity: "intermediate", permissions: ["Collect Checkout access"], category: "Products & Checkout" },
  { title: "Configure AVS Fraud Rules", description: "Set up address verification rejection rules.", guideSlug: "avs-settings", audience: "merchant", complexity: "intermediate", permissions: ["Access Security Options"], category: "Configuration" },
  { title: "Resettle a Failed Batch", description: "Retry a failed settlement batch from Transaction Reports.", guideSlug: "transaction-reports", audience: "merchant", complexity: "intermediate", permissions: ["Access Transaction Reports"], category: "Reporting" },
  { title: "Configure Email SPF/DKIM", description: "Set up DNS records so portal emails aren't flagged as spam.", guideSlug: "email-spf-dkim", audience: "merchant", complexity: "intermediate", permissions: ["DNS administration"], category: "Configuration" },
  { title: "Migrate to API Key Authentication", description: "Switch your integration from username/password to security_key.", guideSlug: "security-key-migration", audience: "both", complexity: "advanced", permissions: ["API access", "Security Key management"], category: "Integrations" },
];

// ─────────────────────────────────────────────────────
// TROUBLESHOOTING THEMES — maps guides to thematic buckets
// ─────────────────────────────────────────────────────

export interface TroubleshootingTheme {
  id: string;
  title: string;
  icon: string;
  guideSlugs: string[];
}

export const troubleshootingThemes: TroubleshootingTheme[] = [
  { id: "login-auth", title: "Login & Authentication", icon: "Shield", guideSlugs: ["two-factor-authentication", "password-rotation", "password-resets", "authentication-errors"] },
  { id: "permissions-access", title: "Permissions & Access", icon: "Users", guideSlugs: ["merchant-user-accounts", "ip-restrictions", "blind-credits"] },
  { id: "reporting", title: "Reporting Issues", icon: "BarChart3", guideSlugs: ["transaction-reports", "subscription-reports"] },
  { id: "transactions", title: "Transaction & Payment Issues", icon: "CreditCard", guideSlugs: ["test-mode", "settlement-schedule", "what-is-ach"] },
  { id: "settings", title: "Settings & Configuration", icon: "Settings", guideSlugs: ["email-spf-dkim", "dkim-spf-validation", "billing-statement"] },
  { id: "integrations", title: "Integration & API Errors", icon: "Puzzle", guideSlugs: ["authentication-errors", "security-key-migration", "collectjs-setup"] },
];

// ─────────────────────────────────────────────────────
// DECISION TREES — grounded in source report
// ─────────────────────────────────────────────────────

export interface DecisionNode {
  id: string;
  question: string;
  options: { label: string; nextId?: string; guideSlug?: string; answer?: string }[];
}

export interface DecisionTree {
  id: string;
  title: string;
  description: string;
  nodes: DecisionNode[];
}

export const decisionTrees: DecisionTree[] = [
  {
    id: "login-issue",
    title: "Can't Log In?",
    description: "Diagnose your login issue based on the source report.",
    nodes: [
      {
        id: "start",
        question: "What happens when you try to log in?",
        options: [
          { label: "Password expired message", nextId: "pw-expired" },
          { label: "2FA code rejected", nextId: "2fa-issue" },
          { label: "Access denied / IP blocked", nextId: "ip-blocked" },
          { label: "Forgot password entirely", guideSlug: "password-resets" },
        ],
      },
      {
        id: "pw-expired",
        question: "Do you have 2FA enabled?",
        options: [
          { label: "No — password expired after 90 days", guideSlug: "password-rotation", answer: "Your password expired. Attempt login to trigger a reset email (valid 24 hours). Enable 2FA to avoid this in the future." },
          { label: "Yes — but password still expired", answer: "If 2FA is enabled, passwords should not expire. Contact your service provider to verify your 2FA status." },
        ],
      },
      {
        id: "2fa-issue",
        question: "Is your device clock synced automatically?",
        options: [
          { label: "No / unsure", answer: "Set your device clock to 'automatic'. 2FA codes rotate every ~30 seconds and require accurate time sync." },
          { label: "Yes, clock is synced", answer: "Try waiting for the next code rotation. If it still fails, contact your service provider to reset 2FA." },
          { label: "Lost my 2FA device", answer: "Contact your service provider to reset 2FA. You cannot self-service this." },
        ],
      },
      {
        id: "ip-blocked",
        question: "Were IP restrictions recently changed?",
        options: [
          { label: "Yes", guideSlug: "ip-restrictions", answer: "Your current IP may not be on the allowlist. Contact your partner or NMI support to update it." },
          { label: "No / unsure", answer: "Check with your partner or administrator whether IP restrictions are enabled on your account." },
        ],
      },
    ],
  },
  {
    id: "missing-data",
    title: "Missing Transactions or Data?",
    description: "Figure out why you can't find transactions or reports.",
    nodes: [
      {
        id: "start",
        question: "What are you looking for?",
        options: [
          { label: "A specific transaction", nextId: "tx-lookup" },
          { label: "Settlement / batch data", nextId: "settlement" },
          { label: "Subscription data", guideSlug: "subscription-reports" },
        ],
      },
      {
        id: "tx-lookup",
        question: "Is your account in Test Mode?",
        options: [
          { label: "Yes / Maybe", guideSlug: "test-mode", answer: "Test and live data are completely isolated. Switch to the correct mode to view corresponding data." },
          { label: "No, I'm in live mode", guideSlug: "transaction-reports", answer: "Try expanding your date range and check Search Transactions with broader criteria." },
        ],
      },
      {
        id: "settlement",
        question: "Did the batch fail or not appear?",
        options: [
          { label: "Batch failed", guideSlug: "settlement-schedule", answer: "Go to Transaction Reports, find the failed batch, and click 'Resettle Batches' to retry." },
          { label: "Batch hasn't appeared yet", answer: "Settlement timing depends on your cut-off time and processor. For terminal-capture, check your Settlement Schedule settings." },
        ],
      },
    ],
  },
  {
    id: "permissions-issue",
    title: "Permission or Access Problem?",
    description: "Determine if this is a permissions issue or a missing feature.",
    nodes: [
      {
        id: "start",
        question: "What's happening?",
        options: [
          { label: "Can't see a menu item or feature", nextId: "missing-feature" },
          { label: "Can't perform an action (greyed out)", nextId: "action-blocked" },
          { label: "New user can't log in", guideSlug: "merchant-user-accounts" },
        ],
      },
      {
        id: "missing-feature",
        question: "Are you a sub-user or the primary user?",
        options: [
          { label: "Sub-user", answer: "Your primary user or partner needs to update your permissions in User Accounts. Each feature requires specific permissions." },
          { label: "Primary user", answer: "The feature may need to be enabled by your partner in Partner Portal, or it may require a specific add-on service." },
        ],
      },
      {
        id: "action-blocked",
        question: "Is this a Credit (Blind Credit) action?",
        options: [
          { label: "Yes", guideSlug: "blind-credits", answer: "Blind Credits must be enabled by your partner in Partner Portal. This is a high-risk capability." },
          { label: "No — something else", answer: "Check your user permissions in Options → Settings → User Accounts. Your primary user or partner can adjust them." },
        ],
      },
    ],
  },
];

// ─────────────────────────────────────────────────────
// AFTER-COMPLETION guidance for key guides
// ─────────────────────────────────────────────────────

export interface AfterCompletion {
  verifySuccess: string;
  whatNext: string[];
  relatedTaskSlugs: string[];
}

export const afterCompletionMap: Record<string, AfterCompletion> = {
  "two-factor-authentication": {
    verifySuccess: "Log out and log back in. You should be prompted for a 6-digit code from Google Authenticator after entering your password.",
    whatNext: ["You are now exempt from the 90-day password rotation.", "Inform your team members to set up 2FA on their own accounts."],
    relatedTaskSlugs: ["password-rotation", "merchant-user-accounts"],
  },
  "password-resets": {
    verifySuccess: "The user should receive a reset email within a few minutes. The link is valid for 24 hours.",
    whatNext: ["Verify the user can log in with the new password.", "Recommend they enable 2FA to avoid future lockouts."],
    relatedTaskSlugs: ["two-factor-authentication", "merchant-user-accounts"],
  },
  "merchant-user-accounts": {
    verifySuccess: "The new user should receive a welcome email with a 'Set a Password' link (valid 24 hours). Confirm they can log in.",
    whatNext: ["Verify the user's permissions are correct by having them check their available menu items.", "If the welcome email wasn't received, use 'Re-send User Welcome Email'."],
    relatedTaskSlugs: ["password-resets", "ip-restrictions"],
  },
  "security-key-migration": {
    verifySuccess: "Send a test API request using the new security_key parameter. Confirm a successful response.",
    whatNext: ["Remove the old username/password from your integration code.", "Update any IP restrictions if your server IP has changed.", "Document the new key in your secure credential store."],
    relatedTaskSlugs: ["authentication-errors", "ip-restrictions"],
  },
  "test-mode": {
    verifySuccess: "Check the test mode indicator in Settings. Process a test transaction and confirm it appears only in test mode reports.",
    whatNext: ["When done testing, disable test mode immediately.", "Verify live transactions resume correctly after disabling."],
    relatedTaskSlugs: ["vt-credit-card", "transaction-reports"],
  },
  "ip-restrictions": {
    verifySuccess: "Try accessing the portal from an allowlisted IP. Then confirm access is blocked from a non-allowlisted IP if possible.",
    whatNext: ["Document your allowlisted IPs for your team.", "Update the allowlist whenever your office IP changes."],
    relatedTaskSlugs: ["merchant-user-accounts", "authentication-errors"],
  },
  "email-spf-dkim": {
    verifySuccess: "Use the DKIM & SPF Validation tool in Merchant Portal to confirm records are propagated and valid.",
    whatNext: ["Send a test email from the portal to verify it arrives in the inbox (not spam).", "Monitor deliverability over the next 24-48 hours as DNS propagates."],
    relatedTaskSlugs: ["dkim-spf-validation", "email-template-changes"],
  },
  "vt-credit-card": {
    verifySuccess: "Check Transaction Reports for the processed transaction. Verify the amount, status, and response code.",
    whatNext: ["For Authorize-only transactions, remember to Capture before the authorization expires.", "Review your AVS/CVV settings if fraud controls are important."],
    relatedTaskSlugs: ["transaction-reports", "avs-settings", "cvv-settings"],
  },
};

// ─────────────────────────────────────────────────────
// FUZZY SEARCH SYNONYMS — common support terms
// ─────────────────────────────────────────────────────

const FUZZY_SYNONYMS: Record<string, string[]> = {
  "login": ["log in", "sign in", "signin", "access", "portal access"],
  "password": ["pw", "pwd", "pass", "passcode", "credentials"],
  "2fa": ["two factor", "two-factor", "mfa", "authenticator", "google auth", "otp"],
  "reset": ["forgot", "change", "expired", "locked out", "lockout"],
  "transaction": ["payment", "charge", "sale", "txn"],
  "refund": ["return", "reversal", "money back"],
  "void": ["cancel", "undo"],
  "settlement": ["batch", "settle", "funding", "deposit"],
  "report": ["reporting", "search", "lookup", "find", "export", "download"],
  "subscription": ["recurring", "subscription", "plan", "rebill"],
  "api": ["integration", "api key", "security key", "developer"],
  "email": ["spam", "spf", "dkim", "deliverability", "receipt"],
  "user": ["sub-user", "team member", "account", "staff"],
  "permission": ["access", "role", "rights", "privilege"],
  "ip": ["ip address", "allowlist", "whitelist", "restrict"],
  "fraud": ["avs", "cvv", "verification", "security"],
  "ach": ["echeck", "e-check", "bank transfer", "routing number"],
};

function expandQuery(query: string): string[] {
  const q = query.toLowerCase();
  const terms = [q];
  for (const [key, synonyms] of Object.entries(FUZZY_SYNONYMS)) {
    if (q.includes(key) || synonyms.some(s => q.includes(s))) {
      terms.push(key, ...synonyms);
    }
  }
  return [...new Set(terms)];
}

function matchesAny(text: string, terms: string[]): boolean {
  const lower = text.toLowerCase();
  return terms.some(t => lower.includes(t));
}

// ─────────────────────────────────────────────────────
// HELPER FUNCTIONS
// ─────────────────────────────────────────────────────

export function getGuidesByCategory(categorySlug: string): Guide[] {
  return guides.filter(g => g.categorySlug === categorySlug);
}

export function getGuideBySlug(slug: string): Guide | undefined {
  return guides.find(g => g.slug === slug);
}

export function getGlossaryTermById(id: string): GlossaryTerm | undefined {
  return glossaryTerms.find(t => t.id === id);
}

export function getCategoryBySlug(slug: string): Category | undefined {
  return categories.find(c => c.slug === slug);
}

export function searchGuides(query: string): Guide[] {
  const terms = expandQuery(query);
  return guides.filter(g =>
    matchesAny(g.title, terms) ||
    matchesAny(g.summary, terms) ||
    matchesAny(g.navigationPath, terms) ||
    g.steps.some(s => matchesAny(s.instruction, terms)) ||
    g.faqs.some(f => matchesAny(f.question, terms) || matchesAny(f.answer, terms)) ||
    g.notes.some(n => matchesAny(n, terms)) ||
    g.warnings.some(w => matchesAny(w, terms)) ||
    matchesAny(g.category, terms) ||
    matchesAny(g.subcategory, terms) ||
    g.requiredPermissions.some(p => matchesAny(p, terms)) ||
    g.troubleshooting.some(t => matchesAny(t.issue, terms) || matchesAny(t.cause, terms) || matchesAny(t.fix, terms))
  );
}

export function searchGlossary(query: string): GlossaryTerm[] {
  const terms = expandQuery(query);
  return glossaryTerms.filter(t =>
    matchesAny(t.term, terms) ||
    matchesAny(t.definition, terms)
  );
}

export function searchCommonTasks(query: string): CommonTask[] {
  const terms = expandQuery(query);
  return commonTasks.filter(t =>
    matchesAny(t.title, terms) ||
    matchesAny(t.description, terms) ||
    t.permissions.some(p => matchesAny(p, terms)) ||
    matchesAny(t.category, terms)
  );
}

export function searchTroubleshooting(query: string): { guide: Guide; items: TroubleshootingItem[] }[] {
  const terms = expandQuery(query);
  const results: { guide: Guide; items: TroubleshootingItem[] }[] = [];
  for (const g of guides) {
    const matchedItems = g.troubleshooting.filter(t =>
      matchesAny(t.issue, terms) || matchesAny(t.cause, terms) || matchesAny(t.fix, terms) || matchesAny(t.verify, terms)
    );
    if (matchedItems.length > 0) results.push({ guide: g, items: matchedItems });
  }
  return results;
}

export function getGuidesForAudience(audience: "partner" | "merchant"): Guide[] {
  return guides.filter(g => g.audience === audience || g.audience === "both");
}

export function getGuidesBySubcategory(categorySlug: string, subcategory: string): Guide[] {
  return guides.filter(g => g.categorySlug === categorySlug && g.subcategory === subcategory);
}
