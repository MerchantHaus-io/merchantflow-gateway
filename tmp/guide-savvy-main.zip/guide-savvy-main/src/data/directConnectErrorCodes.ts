export interface DirectConnectErrorCode {
  code: number;
  message: string;
  description: string;
  category: string;
}

export const directConnectErrorCodes: DirectConnectErrorCode[] = [
  // Card Errors (1xxx)
  { code: 1001, message: "Expired Card", description: "The specified card in the request has expired", category: "Card" },
  { code: 1002, message: "Pre Valid Card", description: "The specified card in the request is not yet effective", category: "Card" },
  { code: 1003, message: "Card Scheme Not Supported", description: "The specified card scheme in the request is not supported", category: "Card" },
  { code: 1004, message: "Card Usage Exceeded", description: "The specified card usage in the request has been exceeded", category: "Card" },
  { code: 1005, message: "Card Banned", description: "The specified card in the request has been banned", category: "Card" },
  { code: 1006, message: "Not Allowed", description: "The specified transaction in the request is not allowed", category: "Card" },

  // Validation Errors (12xx)
  { code: 1200, message: "PAN Missing", description: "The request does not contain a PAN", category: "Validation" },
  { code: 1201, message: "PAN Invalid", description: "The specified PAN in the request is invalid", category: "Validation" },
  { code: 1202, message: "PAN Too Long", description: "The specified PAN in the request is too long", category: "Validation" },
  { code: 1203, message: "PAN Too Short", description: "The specified PAN in the request is too short", category: "Validation" },
  { code: 1204, message: "PAN Fails Luhn Check", description: "The specified PAN in the request fails the Luhn check", category: "Validation" },
  { code: 1210, message: "Expiry Date Missing", description: "The request does not contain an expiry date", category: "Validation" },
  { code: 1211, message: "Expiry Date Invalid", description: "The specified expiry date in the request is invalid", category: "Validation" },
  { code: 1220, message: "Start Date Missing", description: "The request does not contain a start date", category: "Validation" },
  { code: 1221, message: "Start Date Invalid", description: "The specified start date in the request is invalid", category: "Validation" },
  { code: 1230, message: "Issue No Missing", description: "The request does not contain an issue number", category: "Validation" },
  { code: 1231, message: "Issue No Invalid", description: "The specified issue number in the request is invalid", category: "Validation" },
  { code: 1235, message: "Card Reference Invalid", description: "The specified card reference in the request is not valid", category: "Validation" },
  { code: 1236, message: "Card Hash Invalid", description: "The specified card hash in the request is not valid", category: "Validation" },
  { code: 1240, message: "Amount Missing", description: "The request does not contain an amount", category: "Validation" },
  { code: 1241, message: "Amount Invalid", description: "The specified amount in the request is invalid", category: "Validation" },
  { code: 1242, message: "Amount Too Small", description: "The specified amount in the request is too small", category: "Validation" },
  { code: 1243, message: "Amount Too Large", description: "The specified amount in the request is too large", category: "Validation" },
  { code: 1250, message: "Message Type Missing", description: "The request does not contain a message type", category: "Validation" },
  { code: 1251, message: "Message Type Invalid", description: "The specified message type in the request is invalid", category: "Validation" },

  // Terminal & Transaction Errors (2xxx)
  { code: 2002, message: "Terminal ID Unknown", description: "The specified terminal ID is unknown, missing, invalid or disabled", category: "Terminal" },
  { code: 2005, message: "Terminal Usage Exceeded", description: "The specified terminal ID usage in the request has been exceeded", category: "Terminal" },
  { code: 2021, message: "Transaction Key Missing", description: "The specified transaction key in the request is missing", category: "Terminal" },
  { code: 2100, message: "CardEase Reference Missing", description: "The request does not contain a CardEase Reference", category: "Terminal" },
  { code: 2101, message: "CardEase Reference Invalid", description: "The specified CardEase Reference in the request is invalid", category: "Terminal" },
  { code: 2110, message: "Card Details Unavailable", description: "The card details referenced by the Card Reference and Card Hash are unavailable", category: "Terminal" },
  { code: 2111, message: "Card Details Not Found", description: "The card details referenced by the Card Reference and Card Hash could not be found", category: "Terminal" },
  { code: 2200, message: "Transaction Not Found", description: "The specified transaction in the request was not found", category: "Terminal" },
  { code: 2201, message: "Transaction Already Settled", description: "The specified transaction in the request has already been settled", category: "Terminal" },
  { code: 2202, message: "Transaction Already Voided", description: "The specified transaction in the request has already been voided", category: "Terminal" },
  { code: 2203, message: "Transaction Already Refunded", description: "The transaction has already been refunded in full", category: "Terminal" },
  { code: 2204, message: "Transaction Originally Declined", description: "The specified transaction in the request was originally declined", category: "Terminal" },

  // Platform Errors (3xxx)
  { code: 3001, message: "API Key Missing", description: "The API key wasn't sent in the request", category: "Platform" },
  { code: 3002, message: "Invalid API Key", description: "The API key wasn't valid due to invalid characters or not being 32 characters in length", category: "Platform" },
  { code: 3010, message: "Rejected Transaction", description: "The NMI platform declined the transaction", category: "Platform" },
  { code: 3013, message: "General Error", description: "The NMI platform declined the transaction", category: "Platform" },
  { code: 3025, message: "Merchant Configuration Error", description: "There is a configuration issue with the merchant", category: "Platform" },
  { code: 3026, message: "Missing Field", description: "A mandatory field is missing such as the currency code", category: "Platform" },
  { code: 3027, message: "Invalid Field", description: "A submitted field is invalid", category: "Platform" },
  { code: 3028, message: "Invalid HTTP Method", description: "The HTTP method used is invalid", category: "Platform" },
  { code: 3029, message: "Access Denied", description: "The current user doesn't have the correct access permissions", category: "Platform" },
  { code: 3030, message: "Device Configuration Error", description: "The device isn't configured correctly", category: "Platform" },
  { code: 3031, message: "Unexpected Value", description: "An unexpected field was submitted in the request", category: "Platform" },
  { code: 3032, message: "Data Type Invalid", description: "An incorrect data type was used", category: "Platform" },
  { code: 3033, message: "Parse Error", description: "An error occurred parsing the data", category: "Platform" },
  { code: 3034, message: "Server Error", description: "An error occurred with the server", category: "Platform" },
  { code: 3035, message: "General Error", description: "A general error occurred", category: "Platform" },
  { code: 3333, message: "Unknown Error", description: "An unknown error occurred", category: "Platform" },

  // Availability (7xxx)
  { code: 7000, message: "Temporarily Unavailable", description: "The CardEase platform is temporarily unavailable", category: "Availability" },

  // XML Errors (8xxx)
  { code: 8001, message: "Invalid XML Request", description: "The request XML is invalid", category: "XML" },
  { code: 8002, message: "Invalid Message Type", description: "The specified request type is invalid", category: "XML" },
  { code: 8003, message: "XML Element Missing", description: "The request does not contain all of the expected XML elements", category: "XML" },
  { code: 8004, message: "Invalid Data", description: "An invalid piece of information was sent in the request", category: "XML" },
  { code: 8005, message: "XML Decryption Error", description: "It is not possible to decrypt the XML", category: "XML" },
];

export const errorCodeCategories = [...new Set(directConnectErrorCodes.map(e => e.category))];
