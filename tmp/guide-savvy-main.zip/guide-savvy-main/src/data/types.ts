export type Audience = "partner" | "merchant" | "both";
export type Complexity = "beginner" | "intermediate" | "advanced";
export type SourceConfidence = "high" | "medium" | "low";

export interface GuideStep {
  stepNumber: number;
  instruction: string;
  note?: string;
  warning?: string;
  screenshot?: string; // placeholder for future image support
}

export interface FAQ {
  question: string;
  answer: string;
}

export interface TroubleshootingItem {
  issue: string;
  cause: string;
  verify: string;
  fix: string;
  escalation?: string;
  permissions?: string;
}

export interface RelatedTopic {
  slug: string;
  title: string;
  relationship: "related" | "parent" | "child" | "troubleshooting" | "prerequisite";
}

export interface Guide {
  id: string;
  slug: string;
  title: string;
  audience: Audience;
  category: string;
  categorySlug: string;
  subcategory: string;
  summary: string;
  whenToUse: string;
  prerequisites: string[];
  requiredPermissions: string[];
  navigationPath: string;
  steps: GuideStep[];
  screenshots: string[]; // placeholder — future image URLs
  warnings: string[];
  notes: string[];
  faqs: FAQ[];
  troubleshooting: TroubleshootingItem[];
  relatedTopics: RelatedTopic[];
  glossaryTerms: string[]; // term IDs referenced in this guide
  lastUpdated: string;
  sourceReference: string;
  sourceConfidence: SourceConfidence;
  unsupportedOrMissingNotes: string[];
  complexity: Complexity;
}

export interface Category {
  slug: string;
  title: string;
  description: string;
  icon: string;
  audience: Audience;
  featuredTaskSlugs: string[];
  troubleshootingSlugs: string[];
  subcategories: string[];
}

export interface GlossaryTerm {
  id: string;
  term: string;
  definition: string;
  relatedGuides: string[]; // guide slugs
  sourceReference?: string;
}

export interface CommonTask {
  title: string;
  description: string;
  guideSlug: string;
  audience: Audience;
  complexity: Complexity;
  permissions: string[];
  category: string;
}
