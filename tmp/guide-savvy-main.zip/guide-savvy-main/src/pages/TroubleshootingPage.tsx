import { guides, troubleshootingThemes, decisionTrees, getGuideBySlug } from "@/data/guides";
import { Breadcrumbs } from "@/components/guide/Breadcrumbs";
import { Link } from "react-router-dom";
import { AlertTriangle, Search, Shield, Users, BarChart3, CreditCard, Settings, Puzzle, ChevronRight, ArrowRight, HelpCircle, RotateCcw } from "lucide-react";
import { useRole } from "@/contexts/RoleContext";
import { useState } from "react";
import { CollapsibleSection } from "@/components/guide/GuideComponents";

const themeIcons: Record<string, React.ElementType> = { Shield, Users, BarChart3, CreditCard, Settings, Puzzle };

function DecisionTreeUI({ tree }: { tree: typeof decisionTrees[0] }) {
  const [currentNodeId, setCurrentNodeId] = useState("start");
  const [answer, setAnswer] = useState<string | null>(null);
  const [guideLink, setGuideLink] = useState<string | null>(null);
  const [history, setHistory] = useState<string[]>([]);

  const currentNode = tree.nodes.find(n => n.id === currentNodeId);

  const handleOption = (option: typeof tree.nodes[0]["options"][0]) => {
    if (option.answer) {
      setAnswer(option.answer);
      setGuideLink(option.guideSlug || null);
    } else if (option.nextId) {
      setHistory([...history, currentNodeId]);
      setCurrentNodeId(option.nextId);
      setAnswer(null);
      setGuideLink(option.guideSlug || null);
    } else if (option.guideSlug) {
      setAnswer(null);
      setGuideLink(option.guideSlug);
    }
  };

  const reset = () => {
    setCurrentNodeId("start");
    setAnswer(null);
    setGuideLink(null);
    setHistory([]);
  };

  const goBack = () => {
    if (history.length > 0) {
      const prev = history[history.length - 1];
      setHistory(history.slice(0, -1));
      setCurrentNodeId(prev);
      setAnswer(null);
      setGuideLink(null);
    }
  };

  if (!currentNode) return null;

  return (
    <div className="rounded-xl border bg-card p-5 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold text-base">{tree.title}</h3>
        <div className="flex items-center gap-2">
          {history.length > 0 && (
            <button onClick={goBack} className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1 transition-colors" aria-label="Go back">
              ← Back
            </button>
          )}
          {(currentNodeId !== "start" || answer) && (
            <button onClick={reset} className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1 transition-colors" aria-label="Start over">
              <RotateCcw className="h-3 w-3" /> Reset
            </button>
          )}
        </div>
      </div>
      <p className="text-xs text-muted-foreground">{tree.description}</p>

      {!answer && (
        <>
          <p className="text-sm font-medium">{currentNode.question}</p>
          <div className="space-y-2">
            {currentNode.options.map((opt, i) => (
              <button
                key={i}
                onClick={() => handleOption(opt)}
                className="w-full text-left p-3 rounded-lg border hover:bg-muted/50 hover:border-primary/30 transition-all text-sm flex items-center gap-3 group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <span className="flex-1">{opt.label}</span>
                <ChevronRight className="h-3.5 w-3.5 text-muted-foreground group-hover:text-primary transition-colors shrink-0" aria-hidden="true" />
              </button>
            ))}
          </div>
        </>
      )}

      {answer && (
        <div className="space-y-3 animate-fade-in">
          <div className="rounded-lg bg-success/5 border border-success/20 p-4">
            <p className="text-sm">{answer}</p>
          </div>
          {guideLink && (
            <Link to={`/guide/${guideLink}`} className="flex items-center gap-2 text-sm text-primary hover:underline font-medium">
              View full guide <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          )}
          <button onClick={reset} className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1 transition-colors">
            <RotateCcw className="h-3 w-3" /> Ask a different question
          </button>
        </div>
      )}
    </div>
  );
}

export default function TroubleshootingPage() {
  const { role } = useRole();
  const [search, setSearch] = useState("");
  const [activeTheme, setActiveTheme] = useState<string | null>(null);

  const allGuidesWithTs = guides
    .filter(g => g.troubleshooting.length > 0)
    .filter(g => role === "both" || g.audience === role || g.audience === "both");

  const filteredBySearch = allGuidesWithTs.filter(g => {
    if (!search) return true;
    const q = search.toLowerCase();
    return g.title.toLowerCase().includes(q) ||
      g.troubleshooting.some(t => t.issue.toLowerCase().includes(q) || t.cause.toLowerCase().includes(q) || t.fix.toLowerCase().includes(q));
  });

  const filteredByTheme = activeTheme
    ? filteredBySearch.filter(g => {
        const theme = troubleshootingThemes.find(t => t.id === activeTheme);
        return theme?.guideSlugs.includes(g.slug);
      })
    : filteredBySearch;

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
      <Breadcrumbs items={[{ label: "Troubleshooting" }]} />
      <h1 className="text-2xl sm:text-3xl font-bold mb-2">Troubleshooting Hub</h1>
      <p className="text-muted-foreground mb-6">Diagnose and resolve common Merchant Portal issues.</p>

      {/* Decision Trees */}
      <section className="mb-8">
        <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <HelpCircle className="h-4 w-4 text-primary" aria-hidden="true" />
          Quick Diagnosis
        </h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {decisionTrees.map(tree => (
            <DecisionTreeUI key={tree.id} tree={tree} />
          ))}
        </div>
      </section>

      {/* Search */}
      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" aria-hidden="true" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search issues, causes, or fixes..."
          className="w-full rounded-lg border bg-card pl-10 pr-4 py-2.5 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30"
          aria-label="Filter troubleshooting issues"
        />
      </div>

      {/* Theme filters */}
      <div className="flex flex-wrap gap-2 mb-6" role="group" aria-label="Filter by theme">
        <button
          onClick={() => setActiveTheme(null)}
          aria-pressed={!activeTheme}
          className={`flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md transition-all ${!activeTheme ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:text-foreground"}`}
        >All themes</button>
        {troubleshootingThemes.map(theme => {
          const Icon = themeIcons[theme.icon] || HelpCircle;
          return (
            <button
              key={theme.id}
              onClick={() => setActiveTheme(activeTheme === theme.id ? null : theme.id)}
              aria-pressed={activeTheme === theme.id}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md transition-all ${activeTheme === theme.id ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:text-foreground"}`}
            >
              <Icon className="h-3.5 w-3.5" aria-hidden="true" />
              {theme.title}
            </button>
          );
        })}
      </div>

      {/* Issues */}
      <div className="space-y-4">
        {filteredByTheme.map(guide => (
          <div key={guide.slug} className="rounded-xl border overflow-hidden">
            <div className="bg-muted/50 px-4 py-3 border-b flex items-center justify-between gap-3">
              <Link to={`/guide/${guide.slug}`} className="font-semibold text-sm text-foreground hover:text-primary transition-colors">{guide.title}</Link>
              <div className="flex items-center gap-2 shrink-0">
                <span className={`text-[10px] px-2 py-0.5 rounded-full ${guide.audience === "partner" ? "bg-primary/10 text-primary" : guide.audience === "merchant" ? "bg-accent/10 text-accent" : "bg-muted text-muted-foreground"}`}>
                  {guide.audience === "both" ? "All" : guide.audience}
                </span>
              </div>
            </div>
            <div className="p-4 space-y-4">
              {guide.troubleshooting.map((t, i) => (
                <div key={i} className="space-y-3">
                  <p className="font-medium text-sm flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-warning shrink-0" aria-hidden="true" />{t.issue}
                  </p>
                  <div className="grid sm:grid-cols-2 gap-3 text-sm pl-6">
                    <div className="space-y-0.5">
                      <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Likely cause</span>
                      <p>{t.cause}</p>
                    </div>
                    <div className="space-y-0.5">
                      <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">How to verify</span>
                      <p>{t.verify}</p>
                    </div>
                    <div className="space-y-0.5">
                      <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">How to fix</span>
                      <p>{t.fix}</p>
                    </div>
                    <div className="space-y-0.5">
                      <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Escalation</span>
                      <p>{t.escalation || <span className="text-muted-foreground italic text-xs">Not included in source content</span>}</p>
                    </div>
                  </div>
                  {/* Role-specific note */}
                  {role !== "both" && (
                    <div className={`ml-6 text-xs rounded-md p-2.5 ${role === "partner" ? "bg-primary/5 text-primary" : "bg-accent/5 text-accent"}`}>
                      <span className="font-semibold capitalize">{role} note: </span>
                      {role === "partner"
                        ? `When assisting a merchant with this issue, ${t.escalation ? "you may need to escalate if the fix doesn't resolve it" : "walk them through the verification and fix steps"}.`
                        : `Try the fix steps yourself first. ${t.escalation ? "If the issue persists, contact your service provider." : "Contact your service provider if unresolved."}`}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {filteredByTheme.length === 0 && (
        <div className="text-center py-12 space-y-3">
          <p className="text-muted-foreground">No troubleshooting items match your criteria.</p>
          <button onClick={() => { setSearch(""); setActiveTheme(null); }} className="text-sm text-primary hover:underline">Clear all filters</button>
        </div>
      )}
    </div>
  );
}
