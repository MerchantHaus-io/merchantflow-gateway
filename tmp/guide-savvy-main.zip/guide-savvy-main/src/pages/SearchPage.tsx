import { useSearchParams, Link } from "react-router-dom";
import { searchGuides, searchGlossary, searchCommonTasks, searchTroubleshooting, categories, commonTasks } from "@/data/guides";
import { GuideCard } from "@/components/guide/Cards";
import { Breadcrumbs } from "@/components/guide/Breadcrumbs";
import { SearchBar } from "@/components/guide/SearchBar";
import { useRole } from "@/contexts/RoleContext";
import { useState } from "react";
import { AlertTriangle, ArrowRight, BookOpen, HelpCircle, ListChecks, FileText, Users, Filter } from "lucide-react";
import { Audience } from "@/data/types";

type ResultTab = "all" | "guides" | "tasks" | "troubleshooting" | "glossary";

export default function SearchPage() {
  const [params] = useSearchParams();
  const query = params.get("q") || "";
  const { role } = useRole();
  const [activeTab, setActiveTab] = useState<ResultTab>("all");
  const [audienceFilter, setAudienceFilter] = useState<Audience | "all">("all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [showFilters, setShowFilters] = useState(false);

  const filterByAudience = <T extends { audience?: Audience }>(items: T[]) =>
    items.filter(i => {
      const aud = audienceFilter === "all" ? role : audienceFilter;
      return aud === "both" || !i.audience || i.audience === aud || i.audience === "both";
    });

  const guideResults = query
    ? filterByAudience(searchGuides(query)).filter(g => categoryFilter === "all" || g.categorySlug === categoryFilter)
    : [];
  const taskResults = query ? filterByAudience(searchCommonTasks(query)) : [];
  const tsResults = query
    ? searchTroubleshooting(query).filter(r => {
        const aud = audienceFilter === "all" ? role : audienceFilter;
        return aud === "both" || r.guide.audience === aud || r.guide.audience === "both";
      })
    : [];
  const glossaryResults = query ? searchGlossary(query) : [];

  const totalResults = guideResults.length + taskResults.length + tsResults.length + glossaryResults.length;

  const tabs: { id: ResultTab; label: string; count: number; icon: React.ElementType }[] = [
    { id: "all", label: "All", count: totalResults, icon: FileText },
    { id: "guides", label: "Guides", count: guideResults.length, icon: FileText },
    { id: "tasks", label: "Tasks", count: taskResults.length, icon: ListChecks },
    { id: "troubleshooting", label: "Issues", count: tsResults.length, icon: HelpCircle },
    { id: "glossary", label: "Glossary", count: glossaryResults.length, icon: BookOpen },
  ];

  const showGuides = (activeTab === "all" || activeTab === "guides") && guideResults.length > 0;
  const showTasks = (activeTab === "all" || activeTab === "tasks") && taskResults.length > 0;
  const showTs = (activeTab === "all" || activeTab === "troubleshooting") && tsResults.length > 0;
  const showGlossary = (activeTab === "all" || activeTab === "glossary") && glossaryResults.length > 0;

  const uniqueCategories = [...new Set(guideResults.map(g => g.categorySlug))];

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
      <Breadcrumbs items={[{ label: "Search" }]} />
      <h1 className="text-2xl font-bold mb-6">Search</h1>
      <SearchBar size="large" className="mb-6" />

      {query && (
        <>
          {/* Result count + filter toggle */}
          <div className="flex items-center justify-between mb-4">
            <p className="text-sm text-muted-foreground">
              {totalResults} result{totalResults !== 1 ? "s" : ""} for "<span className="font-medium text-foreground">{query}</span>"
            </p>
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
              aria-expanded={showFilters}
            >
              <Filter className="h-3.5 w-3.5" aria-hidden="true" />
              Filters
            </button>
          </div>

          {/* Filters */}
          {showFilters && (
            <div className="rounded-lg border bg-card p-4 mb-6 space-y-3 animate-fade-in">
              <div>
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Audience</p>
                <div className="flex flex-wrap gap-1.5">
                  {(["all", "both", "partner", "merchant"] as const).map(a => (
                    <button
                      key={a}
                      onClick={() => setAudienceFilter(a)}
                      aria-pressed={audienceFilter === a}
                      className={`px-2.5 py-1 text-xs rounded-md transition-all ${audienceFilter === a ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:text-foreground"}`}
                    >
                      {a === "all" ? "Current role" : a === "both" ? "All audiences" : a.charAt(0).toUpperCase() + a.slice(1)}
                    </button>
                  ))}
                </div>
              </div>
              {uniqueCategories.length > 1 && (
                <div>
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Category</p>
                  <div className="flex flex-wrap gap-1.5">
                    <button
                      onClick={() => setCategoryFilter("all")}
                      aria-pressed={categoryFilter === "all"}
                      className={`px-2.5 py-1 text-xs rounded-md transition-all ${categoryFilter === "all" ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:text-foreground"}`}
                    >All</button>
                    {categories.filter(c => uniqueCategories.includes(c.slug)).map(c => (
                      <button
                        key={c.slug}
                        onClick={() => setCategoryFilter(c.slug)}
                        aria-pressed={categoryFilter === c.slug}
                        className={`px-2.5 py-1 text-xs rounded-md transition-all ${categoryFilter === c.slug ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:text-foreground"}`}
                      >{c.title}</button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Tabs */}
          <div className="flex gap-1 mb-6 overflow-x-auto pb-1" role="tablist" aria-label="Result categories">
            {tabs.filter(t => t.id === "all" || t.count > 0).map(tab => (
              <button
                key={tab.id}
                role="tab"
                aria-selected={activeTab === tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md whitespace-nowrap transition-all ${
                  activeTab === tab.id ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:text-foreground"
                }`}
              >
                <tab.icon className="h-3.5 w-3.5" aria-hidden="true" />
                {tab.label}
                <span className="text-[10px] opacity-70">({tab.count})</span>
              </button>
            ))}
          </div>

          {/* Guide Results */}
          {showGuides && (
            <section className="mb-8">
              <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <FileText className="h-4 w-4 text-primary" aria-hidden="true" />
                Guides ({guideResults.length})
              </h2>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {guideResults.slice(0, activeTab === "all" ? 6 : undefined).map(g => <GuideCard key={g.slug} guide={g} />)}
              </div>
              {activeTab === "all" && guideResults.length > 6 && (
                <button onClick={() => setActiveTab("guides")} className="mt-3 text-sm text-primary hover:underline flex items-center gap-1">
                  View all {guideResults.length} guides <ArrowRight className="h-3.5 w-3.5" />
                </button>
              )}
            </section>
          )}

          {/* Task Results */}
          {showTasks && (
            <section className="mb-8">
              <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <ListChecks className="h-4 w-4 text-primary" aria-hidden="true" />
                Common Tasks ({taskResults.length})
              </h2>
              <div className="space-y-2">
                {taskResults.slice(0, activeTab === "all" ? 4 : undefined).map(t => (
                  <Link key={t.guideSlug + t.title} to={`/guide/${t.guideSlug}`} className="flex items-center gap-4 p-3 rounded-lg border hover:bg-muted/50 transition-colors group">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium group-hover:text-primary transition-colors">{t.title}</p>
                      <p className="text-xs text-muted-foreground line-clamp-1">{t.description}</p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className={`text-[10px] font-medium capitalize ${t.complexity === "beginner" ? "text-success" : t.complexity === "intermediate" ? "text-warning" : "text-destructive"}`}>{t.complexity}</span>
                      <span className="text-[10px] text-muted-foreground capitalize">{t.audience === "both" ? "All" : t.audience}</span>
                    </div>
                  </Link>
                ))}
              </div>
            </section>
          )}

          {/* Troubleshooting Results */}
          {showTs && (
            <section className="mb-8">
              <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <HelpCircle className="h-4 w-4 text-warning" aria-hidden="true" />
                Troubleshooting ({tsResults.length})
              </h2>
              <div className="space-y-3">
                {tsResults.slice(0, activeTab === "all" ? 3 : undefined).map(r => (
                  <div key={r.guide.slug} className="rounded-lg border overflow-hidden">
                    <div className="bg-muted/50 px-4 py-2.5 border-b">
                      <Link to={`/guide/${r.guide.slug}`} className="text-sm font-semibold hover:text-primary transition-colors">{r.guide.title}</Link>
                    </div>
                    <div className="p-4 space-y-3">
                      {r.items.map((t, i) => (
                        <div key={i} className="space-y-1.5">
                          <p className="text-sm font-medium flex items-center gap-2">
                            <AlertTriangle className="h-3.5 w-3.5 text-warning shrink-0" aria-hidden="true" />{t.issue}
                          </p>
                          <div className="grid sm:grid-cols-2 gap-2 text-xs pl-6">
                            <div><span className="text-muted-foreground font-medium">Cause:</span> {t.cause}</div>
                            <div><span className="text-muted-foreground font-medium">Fix:</span> {t.fix}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* Glossary Results */}
          {showGlossary && (
            <section className="mb-8">
              <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <BookOpen className="h-4 w-4 text-info" aria-hidden="true" />
                Glossary ({glossaryResults.length})
              </h2>
              <div className="space-y-2">
                {glossaryResults.slice(0, activeTab === "all" ? 5 : undefined).map(t => (
                  <div key={t.id} className="rounded-lg border p-4">
                    <h3 className="font-semibold text-sm">{t.term}</h3>
                    <p className="text-sm text-muted-foreground mt-1">{t.definition}</p>
                    {t.relatedGuides.length > 0 && (
                      <div className="flex flex-wrap gap-2 mt-2">
                        {t.relatedGuides.map(slug => (
                          <Link key={slug} to={`/guide/${slug}`} className="text-xs text-primary hover:underline">{slug.replace(/-/g, " ")} →</Link>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* Empty state */}
          {totalResults === 0 && (
            <div className="text-center py-12 space-y-6">
              <div>
                <p className="text-muted-foreground mb-2">No results found for "{query}"</p>
                <p className="text-sm text-muted-foreground">Try different keywords, check your spelling, or browse by category.</p>
              </div>

              <div>
                <p className="text-sm font-semibold text-muted-foreground mb-3">Try searching for:</p>
                <div className="flex flex-wrap justify-center gap-2">
                  {["password reset", "2FA setup", "transaction lookup", "API key", "test mode", "settlement"].map(suggestion => (
                    <Link
                      key={suggestion}
                      to={`/search?q=${encodeURIComponent(suggestion)}`}
                      className="px-3 py-1.5 text-sm rounded-md bg-muted text-muted-foreground hover:text-foreground hover:bg-muted/80 transition-colors"
                    >
                      {suggestion}
                    </Link>
                  ))}
                </div>
              </div>

              <div>
                <p className="text-sm font-semibold text-muted-foreground mb-3">Popular categories:</p>
                <div className="flex flex-wrap justify-center gap-2">
                  {categories.filter(c => !["troubleshooting", "glossary"].includes(c.slug)).slice(0, 5).map(c => (
                    <Link
                      key={c.slug}
                      to={`/category/${c.slug}`}
                      className="px-3 py-1.5 text-sm rounded-md bg-primary/10 text-primary hover:bg-primary/15 transition-colors"
                    >
                      {c.title}
                    </Link>
                  ))}
                </div>
              </div>

              <div>
                <Link to="/tasks" className="text-sm text-primary hover:underline flex items-center gap-1 justify-center">
                  <ListChecks className="h-3.5 w-3.5" /> Browse common tasks
                </Link>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
