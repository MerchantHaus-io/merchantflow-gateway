import { useParams, Link } from "react-router-dom";
import { categories, getGuidesByCategory, getGuideBySlug } from "@/data/guides";
import { Breadcrumbs } from "@/components/guide/Breadcrumbs";
import { GuideCard } from "@/components/guide/Cards";
import { AudienceBadge } from "@/components/guide/AudienceBadge";
import { useRole } from "@/contexts/RoleContext";
import { AlertTriangle, ArrowRight } from "lucide-react";

export default function CategoryPage() {
  const { slug } = useParams<{ slug: string }>();
  const category = categories.find(c => c.slug === slug);
  const allCatGuides = getGuidesByCategory(slug || "");
  const { role } = useRole();
  const filteredGuides = allCatGuides.filter(g => role === "both" || g.audience === role || g.audience === "both");

  if (!category) {
    return (
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-16 text-center animate-fade-in">
        <p className="text-2xl font-bold text-muted-foreground/30 mb-2">Category not found</p>
        <p className="text-muted-foreground mb-4">This category doesn't exist or may have been renamed.</p>
        <Link to="/" className="text-sm text-primary hover:underline">← Back to homepage</Link>
      </div>
    );
  }

  const subcategoryGroups = category.subcategories
    .map(sub => ({
      name: sub,
      guides: filteredGuides.filter(g => g.subcategory === sub),
    }))
    .filter(g => g.guides.length > 0);

  const featuredGuides = category.featuredTaskSlugs
    .map(s => getGuideBySlug(s))
    .filter(Boolean) as NonNullable<ReturnType<typeof getGuideBySlug>>[];

  const troubleshootingGuides = category.troubleshootingSlugs
    .map(s => getGuideBySlug(s))
    .filter(g => g && g.troubleshooting.length > 0) as NonNullable<ReturnType<typeof getGuideBySlug>>[];

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
      <Breadcrumbs items={[{ label: category.title }]} />

      <header className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <h1 className="text-2xl sm:text-3xl font-bold">{category.title}</h1>
          <AudienceBadge audience={category.audience} />
        </div>
        <p className="text-muted-foreground max-w-2xl">{category.description}</p>
        <p className="text-xs text-muted-foreground mt-2">{filteredGuides.length} guide{filteredGuides.length !== 1 ? "s" : ""} in this category</p>
      </header>

      {/* Featured tasks */}
      {featuredGuides.length > 0 && (
        <section className="mb-8">
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">Key Tasks</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-2">
            {featuredGuides.map(g => (
              <Link key={g.slug} to={`/guide/${g.slug}`} className="flex items-center gap-3 p-3 rounded-lg border hover:bg-muted/50 transition-colors group">
                <span className="text-sm font-medium group-hover:text-primary transition-colors flex-1">{g.title}</span>
                <ArrowRight className="h-3.5 w-3.5 text-muted-foreground shrink-0" aria-hidden="true" />
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* Guides by subcategory */}
      {subcategoryGroups.length > 0 ? (
        <div className="space-y-8">
          {subcategoryGroups.map(group => (
            <section key={group.name}>
              <h2 className="text-base font-semibold mb-3 pb-2 border-b">{group.name}</h2>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {group.guides.map(g => <GuideCard key={g.slug} guide={g} />)}
              </div>
            </section>
          ))}
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {filteredGuides.map(g => <GuideCard key={g.slug} guide={g} />)}
        </div>
      )}

      {filteredGuides.length === 0 && (
        <div className="text-center py-12 space-y-2">
          <p className="text-muted-foreground">No guides match your current role filter.</p>
          <p className="text-sm text-muted-foreground">Try switching to "All" in the role toggle above.</p>
        </div>
      )}

      {/* Troubleshooting */}
      {troubleshootingGuides.length > 0 && (
        <section className="mt-10 pt-6 border-t">
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
            <AlertTriangle className="h-3.5 w-3.5 text-warning" aria-hidden="true" /> Common Troubleshooting
          </h2>
          <div className="space-y-2">
            {troubleshootingGuides.map(g => (
              <div key={g.slug} className="rounded-lg border p-4">
                <Link to={`/guide/${g.slug}`} className="font-medium text-sm hover:text-primary transition-colors">{g.title}</Link>
                <div className="mt-2 space-y-1">
                  {g.troubleshooting.map((t, i) => (
                    <p key={i} className="text-xs text-muted-foreground flex items-start gap-1.5">
                      <span className="text-warning mt-0.5">•</span> {t.issue}
                    </p>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
