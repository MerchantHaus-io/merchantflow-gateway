import { Link } from "react-router-dom";
import { Home, Search, ArrowRight } from "lucide-react";
import { categories } from "@/data/guides";

export default function NotFound() {
  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 py-16 text-center space-y-8 animate-fade-in">
      <div>
        <p className="text-6xl font-bold text-primary/20 mb-4">404</p>
        <h1 className="text-2xl font-bold mb-2">Page not found</h1>
        <p className="text-muted-foreground">
          The page you're looking for doesn't exist or may have been moved.
        </p>
      </div>

      <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
        <Link
          to="/"
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
        >
          <Home className="h-4 w-4" aria-hidden="true" />
          Go to Homepage
        </Link>
        <Link
          to="/search"
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border bg-card text-sm font-medium hover:bg-muted/50 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
        >
          <Search className="h-4 w-4" aria-hidden="true" />
          Search guides
        </Link>
      </div>

      <div>
        <p className="text-sm font-semibold text-muted-foreground mb-3">Or browse a category:</p>
        <div className="flex flex-wrap justify-center gap-2">
          {categories.slice(0, 6).map(c => (
            <Link
              key={c.slug}
              to={`/category/${c.slug}`}
              className="inline-flex items-center gap-1 px-3 py-1.5 text-sm rounded-md bg-muted text-muted-foreground hover:text-foreground hover:bg-muted/80 transition-colors"
            >
              {c.title}
              <ArrowRight className="h-3 w-3" aria-hidden="true" />
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
