import { glossaryTerms, getGuideBySlug } from "@/data/guides";
import { Breadcrumbs } from "@/components/guide/Breadcrumbs";
import { useState } from "react";
import { Link } from "react-router-dom";
import { Search, ArrowRight } from "lucide-react";

export default function GlossaryPage() {
  const [filter, setFilter] = useState("");
  const filtered = glossaryTerms.filter(t =>
    t.term.toLowerCase().includes(filter.toLowerCase()) ||
    t.definition.toLowerCase().includes(filter.toLowerCase())
  );

  // Group by first letter
  const grouped = filtered.reduce<Record<string, typeof filtered>>((acc, t) => {
    const letter = t.term[0].toUpperCase();
    if (!acc[letter]) acc[letter] = [];
    acc[letter].push(t);
    return acc;
  }, {});

  const letters = Object.keys(grouped).sort();

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
      <Breadcrumbs items={[{ label: "Glossary" }]} />
      <h1 className="text-2xl sm:text-3xl font-bold mb-2">Glossary</h1>
      <p className="text-muted-foreground mb-6">
        Key terms and concepts used in the NMI Merchant Portal. {glossaryTerms.length} terms defined.
      </p>

      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" aria-hidden="true" />
        <input
          type="text"
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          placeholder="Filter terms..."
          className="w-full rounded-lg border bg-card pl-10 pr-4 py-2.5 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30"
          aria-label="Filter glossary terms"
        />
      </div>

      {/* Letter jump nav */}
      {!filter && (
        <div className="flex flex-wrap gap-1 mb-6" role="navigation" aria-label="Jump to letter">
          {letters.map(l => (
            <a key={l} href={`#letter-${l}`} className="w-7 h-7 flex items-center justify-center rounded text-xs font-medium text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors">
              {l}
            </a>
          ))}
        </div>
      )}

      <div className="space-y-6">
        {letters.map(letter => (
          <div key={letter} id={`letter-${letter}`}>
            <h2 className="text-sm font-bold text-primary mb-2 sticky top-14 bg-background py-1 z-10">{letter}</h2>
            <div className="space-y-2">
              {grouped[letter].map(t => {
                const guideLinks = t.relatedGuides
                  .map(slug => {
                    const g = getGuideBySlug(slug);
                    return g ? { slug, title: g.title } : null;
                  })
                  .filter(Boolean);

                return (
                  <div key={t.id} className="rounded-lg border p-4">
                    <h3 className="font-semibold text-sm text-foreground">{t.term}</h3>
                    <p className="text-sm text-muted-foreground mt-1">{t.definition}</p>
                    {guideLinks.length > 0 && (
                      <div className="flex flex-wrap gap-2 mt-3">
                        {guideLinks.map(link => link && (
                          <Link
                            key={link.slug}
                            to={`/guide/${link.slug}`}
                            className="inline-flex items-center gap-1 text-xs text-primary hover:underline bg-primary/5 px-2 py-0.5 rounded-md"
                          >
                            {link.title} <ArrowRight className="h-2.5 w-2.5" aria-hidden="true" />
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {filtered.length === 0 && <p className="text-center text-muted-foreground py-12">No terms match your filter.</p>}
    </div>
  );
}
