import { useParams, Link } from "react-router-dom";
import { getGuideBySlug, getGlossaryTermById, guides as allGuides, afterCompletionMap } from "@/data/guides";
import { Breadcrumbs } from "@/components/guide/Breadcrumbs";
import { AudienceBadge } from "@/components/guide/AudienceBadge";
import { StepperUI, NavigationPathDisplay, CalloutBox, CollapsibleSection, RoleContextBanner } from "@/components/guide/GuideComponents";
import { ErrorCodeTable } from "@/components/guide/ErrorCodeTable";
import { useRole } from "@/contexts/RoleContext";
import { Clock, ExternalLink, ArrowRight, AlertTriangle, CheckCircle2, Info, FileText, ShieldAlert, ChevronRight, Sparkles, ImageIcon } from "lucide-react";
import { useState, useEffect } from "react";
import assetsManifest from "../../public/merchant-portal/assets.json";

const RELATIONSHIP_LABELS: Record<string, string> = {
  related: "Related",
  parent: "Overview",
  child: "Sub-topic",
  troubleshooting: "Troubleshooting",
  prerequisite: "Prerequisite",
};

const RELATIONSHIP_ORDER = ["prerequisite", "parent", "child", "related", "troubleshooting"];

const ROLE_CONTEXT: Record<string, { partner: string; merchant: string }> = {
  "two-factor-authentication": {
    partner: "You cannot enable 2FA on behalf of a merchant. Walk the merchant through these steps via screen share or send them this guide directly.",
    merchant: "Follow these steps yourself to secure your login. Once set up, you'll need your phone on every login.",
  },
  "password-resets": {
    partner: "Use this to help merchants who are locked out. Be aware: clicking Reset Password immediately invalidates their current password.",
    merchant: "If you're locked out, use 'Forgot Password' on the login page. Your primary user or partner can also reset it for you.",
  },
  "merchant-user-accounts": {
    partner: "Guide merchants through user setup, or create users on their behalf from Partner Portal. Ensure proper permissions are assigned.",
    merchant: "Add team members with the right permissions so they can access only what they need.",
  },
  "security-key-migration": {
    partner: "Help your merchants transition from username/password to API key auth before the 2026 deadline. This affects all API integrations.",
    merchant: "If you use API integrations, plan your migration to security keys. This is mandatory by end of 2026.",
  },
  "test-mode": {
    partner: "Remind merchants that test mode is account-wide. If a merchant reports 'missing transactions', check if they're in test mode.",
    merchant: "Test mode affects your entire account. Always disable it before processing real transactions.",
  },
  "ip-restrictions": {
    partner: "If a merchant gets locked out due to IP restrictions, you can update the allowlist from Partner Portal.",
    merchant: "Be very careful with IP restrictions. If you lock yourself out, you'll need your partner's help to fix it.",
  },
  "vt-credit-card": {
    partner: "Guide merchants through the Virtual Terminal interface. Remind them about AVS/CVV settings and Blind Credit risks.",
    merchant: "Use the Virtual Terminal for manual card-present or card-not-present transactions. Always verify required fields before submitting.",
  },
  "email-spf-dkim": {
    partner: "Walk merchants through DNS configuration if they report email deliverability issues from the portal.",
    merchant: "You'll need access to your domain's DNS settings. If you don't manage DNS, involve your IT team or domain provider.",
  },
};

function TableOfContents({ guide }: { guide: NonNullable<ReturnType<typeof getGuideBySlug>> }) {
  const [activeSection, setActiveSection] = useState("");

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => { entries.forEach((entry) => { if (entry.isIntersecting) setActiveSection(entry.target.id); }); },
      { rootMargin: "-80px 0px -60% 0px" }
    );
    const sections = document.querySelectorAll("[data-toc]");
    sections.forEach((s) => observer.observe(s));
    return () => observer.disconnect();
  }, []);

  const completion = afterCompletionMap[guide.slug];
  const items: { id: string; label: string }[] = [];
  items.push({ id: "before", label: "Before You Begin" });
  if (guide.steps.length > 0) items.push({ id: "steps", label: "Steps" });
  if (guide.screenshots.length > 0) items.push({ id: "screenshots", label: "Screenshots" });
  if (guide.notes.length > 0) items.push({ id: "notes", label: "Notes" });
  if (guide.faqs.length > 0) items.push({ id: "faqs", label: "FAQs" });
  if (guide.troubleshooting.length > 0) items.push({ id: "troubleshooting", label: "Troubleshooting" });
  if (completion) items.push({ id: "after", label: "After You Finish" });
  if (guide.relatedTopics.length > 0) items.push({ id: "related", label: "Related" });

  if (items.length < 3) return null;

  return (
    <nav className="guide-toc hidden xl:block" aria-label="Table of contents">
      <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider px-3 mb-2">On this page</p>
      {items.map((item) => (
        <a key={item.id} href={`#${item.id}`} className={activeSection === item.id ? "active" : ""}>{item.label}</a>
      ))}
    </nav>
  );
}

function GlossaryTooltip({ termId }: { termId: string }) {
  const term = getGlossaryTermById(termId);
  if (!term) return null;
  return (
    <span className="group/tooltip relative inline-block">
      <span className="border-b border-dotted border-muted-foreground/40 cursor-help text-foreground">{term.term}</span>
      <span className="absolute z-50 bottom-full left-1/2 -translate-x-1/2 mb-2 w-64 p-3 rounded-lg border bg-popover text-popover-foreground shadow-lg text-xs opacity-0 invisible group-hover/tooltip:opacity-100 group-hover/tooltip:visible transition-all pointer-events-none">
        <span className="font-semibold block mb-1">{term.term}</span>
        {term.definition}
      </span>
    </span>
  );
}

export default function GuidePage() {
  const { slug } = useParams<{ slug: string }>();
  const guide = getGuideBySlug(slug || "");
  const { role } = useRole();

  if (!guide) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-16 text-center animate-fade-in">
        <p className="text-2xl font-bold text-muted-foreground/30 mb-2">Guide not found</p>
        <p className="text-muted-foreground mb-4">This guide doesn't exist or may have been moved.</p>
        <Link to="/" className="text-sm text-primary hover:underline">← Back to homepage</Link>
      </div>
    );
  }

  const isExternalNav = guide.navigationPath.startsWith("N/A");
  const hasSteps = guide.steps.length > 0;
  const roleContext = ROLE_CONTEXT[guide.slug];
  const completion = afterCompletionMap[guide.slug];

  const confidenceStyles = {
    high: "bg-success/10 text-success",
    medium: "bg-warning/10 text-warning",
    low: "bg-destructive/10 text-destructive",
  };

  const groupedRelated = RELATIONSHIP_ORDER
    .map(rel => ({ label: RELATIONSHIP_LABELS[rel], topics: guide.relatedTopics.filter(t => t.relationship === rel) }))
    .filter(g => g.topics.length > 0);

  const referencedGlossary = guide.glossaryTerms.map(id => getGlossaryTermById(id)).filter(Boolean);
  const nextGuide = guide.relatedTopics.find(t => t.relationship === "child" || t.relationship === "related");
  const alsoView = guide.relatedTopics
    .map(t => allGuides.find(g => g.slug === t.slug))
    .filter(g => g && (role === "both" || g.audience === role || g.audience === "both"))
    .slice(0, 3);

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
      <div className="flex gap-8">
        <div className="flex-1 min-w-0 max-w-4xl">
          <Breadcrumbs items={[
            { label: guide.category, href: `/category/${guide.categorySlug}` },
            { label: guide.title },
          ]} />

          <header className="mb-8">
            <div className="flex flex-wrap items-center gap-2 mb-3">
              <AudienceBadge audience={guide.audience} />
              <span className="text-[11px] px-2 py-0.5 rounded-full bg-muted text-muted-foreground capitalize">{guide.complexity}</span>
              <span className="text-[11px] px-2 py-0.5 rounded-full bg-muted text-muted-foreground">{guide.subcategory}</span>
              <span className={`text-[11px] px-2 py-0.5 rounded-full ${confidenceStyles[guide.sourceConfidence]}`}>
                Source: {guide.sourceConfidence}
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold mb-2">{guide.title}</h1>
            <p className="text-muted-foreground leading-relaxed">{guide.summary}</p>
            <div className="flex flex-wrap items-center gap-4 mt-3 text-xs text-muted-foreground">
              <span className="flex items-center gap-1"><Clock className="h-3 w-3" aria-hidden="true" /> Updated {guide.lastUpdated}</span>
              <span className="flex items-center gap-1"><FileText className="h-3 w-3" aria-hidden="true" /> {guide.id}</span>
              {hasSteps && <span>{guide.steps.length} steps</span>}
            </div>
          </header>

          {roleContext && role !== "both" && (
            <div className="mb-6">
              <RoleContextBanner role={role} partnerText={roleContext.partner} merchantText={roleContext.merchant} />
            </div>
          )}

          <CalloutBox type="info" title="When to use this">{guide.whenToUse}</CalloutBox>

          {guide.unsupportedOrMissingNotes.length > 0 && (
            <div className="my-4 rounded-lg border border-warning/30 bg-warning/5 p-4">
              <p className="text-sm font-semibold text-warning flex items-center gap-2 mb-2">
                <ShieldAlert className="h-4 w-4" aria-hidden="true" /> Source Content Notes
              </p>
              <ul className="space-y-1">
                {guide.unsupportedOrMissingNotes.map((note, i) => (
                  <li key={i} className="text-xs text-muted-foreground flex items-start gap-2">
                    <Info className="h-3 w-3 shrink-0 mt-0.5 text-warning" aria-hidden="true" />{note}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Before You Begin */}
          <section className="my-6" id="before" data-toc>
            <h2 className="text-base font-semibold mb-3 flex items-center gap-2">
              <span className="inline-flex items-center justify-center h-5 w-5 rounded bg-primary/10 text-primary text-xs font-bold" aria-hidden="true">!</span>
              Before You Begin
            </h2>
            <div className="grid sm:grid-cols-2 gap-3">
              <div className="rounded-lg border p-4">
                <h3 className="text-sm font-semibold mb-2">Prerequisites</h3>
                {guide.prerequisites.length > 0 ? (
                  <ul className="space-y-1.5">
                    {guide.prerequisites.map((p, i) => (
                      <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                        <CheckCircle2 className="h-3.5 w-3.5 text-success shrink-0 mt-0.5" aria-hidden="true" />{p}
                      </li>
                    ))}
                  </ul>
                ) : <p className="text-xs text-muted-foreground italic">Not included in source content</p>}
              </div>
              <div className="rounded-lg border p-4">
                <h3 className="text-sm font-semibold mb-2">Required Permissions</h3>
                {guide.requiredPermissions.length > 0 ? (
                  <ul className="space-y-1.5">
                    {guide.requiredPermissions.map((p, i) => (
                      <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                        <span className="shrink-0 mt-0.5 text-xs" aria-hidden="true">🔑</span>{p}
                      </li>
                    ))}
                  </ul>
                ) : <p className="text-xs text-muted-foreground italic">Not included in source content</p>}
              </div>
            </div>
            {guide.warnings.length > 0 && (
              <div className="mt-3">
                {guide.warnings.map((w, i) => <CalloutBox key={i} type="warning" title="Warning">{w}</CalloutBox>)}
              </div>
            )}
          </section>

          {!isExternalNav && <NavigationPathDisplay path={guide.navigationPath} />}

          {referencedGlossary.length > 0 && (
            <div className="flex flex-wrap items-center gap-2 mb-4 text-xs text-muted-foreground">
              <span className="font-medium">Key terms:</span>
              {referencedGlossary.map(t => t && <GlossaryTooltip key={t.id} termId={t.id} />)}
            </div>
          )}

          {/* Steps */}
          {guide.slug === "direct-connect-error-codes" ? (
            <section className="my-8" id="steps" data-toc>
              <h2 className="text-base font-semibold mb-4">Error Code Reference</h2>
              <ErrorCodeTable />
            </section>
          ) : hasSteps ? (
            <section className="my-8" id="steps" data-toc>
              <StepperUI steps={guide.steps} />
            </section>
          ) : (
            <div className="my-6 rounded-lg border bg-muted/30 p-6 text-center">
              <p className="text-sm text-muted-foreground">This is a reference article — no step-by-step walkthrough applies.</p>
            </div>
          )}

          {/* Screenshots */}
          {guide.screenshots.length > 0 && (
            <section className="mt-8" id="screenshots" data-toc>
              <CollapsibleSection title={`Screenshots (${guide.screenshots.length})`} defaultOpen>
                <div className="grid gap-4">
                  {guide.screenshots.map((src, i) => {
                    const asset = (assetsManifest as Array<{ filename: string; alt_text: string }>).find(
                      a => `/${a.filename}` === src
                    );
                    return (
                      <figure key={i} className="rounded-lg border overflow-hidden bg-muted/30">
                        <a href={src} target="_blank" rel="noopener noreferrer">
                          <img
                            src={src}
                            alt={asset?.alt_text || `Screenshot ${i + 1}`}
                            className="w-full h-auto max-h-[500px] object-contain bg-white"
                            loading="lazy"
                          />
                        </a>
                        {asset?.alt_text && (
                          <figcaption className="px-3 py-2 text-xs text-muted-foreground flex items-center gap-1.5">
                            <ImageIcon className="h-3 w-3 shrink-0" aria-hidden="true" />
                            {asset.alt_text}
                          </figcaption>
                        )}
                      </figure>
                    );
                  })}
                </div>
              </CollapsibleSection>
            </section>
          )}

          {/* Notes */}
          {guide.notes.length > 0 && (
            <section className="mt-6" id="notes" data-toc>
              <CollapsibleSection title={`Notes (${guide.notes.length})`} defaultOpen>
                <div className="rounded-lg border border-primary/20 bg-primary/5 p-4">
                  <ul className="space-y-2.5">
                    {guide.notes.map((n, i) => (
                      <li key={i} className="flex items-start gap-2.5 text-sm">
                        <Info className="h-3.5 w-3.5 text-primary shrink-0 mt-0.5" aria-hidden="true" />
                        <span className="text-foreground/80">{n}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </CollapsibleSection>
            </section>
          )}

          {/* FAQs */}
          {guide.faqs.length > 0 && (
            <section className="mt-8" id="faqs" data-toc>
              <h2 className="text-base font-semibold mb-3">Frequently Asked Questions</h2>
              <div className="space-y-2">
                {guide.faqs.map((faq, i) => (
                  <CollapsibleSection key={i} title={faq.question}>
                    <p className="text-muted-foreground">{faq.answer}</p>
                  </CollapsibleSection>
                ))}
              </div>
            </section>
          )}

          {/* Troubleshooting */}
          {guide.troubleshooting.length > 0 && (
            <section className="mt-8" id="troubleshooting" data-toc>
              <h2 className="text-base font-semibold mb-3">Troubleshooting</h2>
              <div className="space-y-3">
                {guide.troubleshooting.map((t, i) => (
                  <div key={i} className="rounded-lg border p-4 space-y-3">
                    <p className="font-medium text-sm flex items-center gap-2">
                      <AlertTriangle className="h-4 w-4 text-warning" aria-hidden="true" />{t.issue}
                    </p>
                    <div className="grid sm:grid-cols-2 gap-3 text-sm">
                      <div><span className="font-medium text-muted-foreground">Likely cause:</span> {t.cause}</div>
                      <div><span className="font-medium text-muted-foreground">How to verify:</span> {t.verify}</div>
                      <div><span className="font-medium text-muted-foreground">How to fix:</span> {t.fix}</div>
                      <div>
                        <span className="font-medium text-muted-foreground">Escalation:</span>{" "}
                        {t.escalation || <span className="italic text-xs text-muted-foreground">Not included in source content</span>}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* After You Finish */}
          {completion && (
            <section className="mt-8" id="after" data-toc>
              <div className="rounded-xl border-2 border-success/20 bg-success/5 p-5 space-y-4">
                <h2 className="text-base font-semibold flex items-center gap-2 text-success">
                  <Sparkles className="h-4 w-4" aria-hidden="true" /> After You Finish
                </h2>
                <div>
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1">How to verify success</p>
                  <p className="text-sm">{completion.verifySuccess}</p>
                </div>
                {completion.whatNext.length > 0 && (
                  <div>
                    <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1">What to do next</p>
                    <ul className="space-y-1">
                      {completion.whatNext.map((n, i) => (
                        <li key={i} className="text-sm flex items-start gap-2">
                          <CheckCircle2 className="h-3.5 w-3.5 text-success shrink-0 mt-0.5" aria-hidden="true" />{n}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                {completion.relatedTaskSlugs.length > 0 && (
                  <div>
                    <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Related tasks</p>
                    <div className="flex flex-wrap gap-2">
                      {completion.relatedTaskSlugs.map(s => {
                        const g = getGuideBySlug(s);
                        return g ? (
                          <Link key={s} to={`/guide/${s}`} className="text-xs px-2.5 py-1 rounded-md bg-card border hover:border-primary/30 hover:text-primary transition-colors">
                            {g.title}
                          </Link>
                        ) : null;
                      })}
                    </div>
                  </div>
                )}
              </div>
            </section>
          )}

          {/* Next recommended + People also view */}
          {(nextGuide || alsoView.length > 0) && (
            <section className="mt-8 pt-6 border-t space-y-4" id="related" data-toc>
              {nextGuide && (
                <Link to={`/guide/${nextGuide.slug}`} className="flex items-center gap-3 p-4 rounded-xl border-2 border-primary/20 bg-primary/5 hover:bg-primary/10 transition-colors group">
                  <div className="flex-1">
                    <p className="text-xs font-semibold text-primary uppercase tracking-wider mb-1">Next recommended</p>
                    <p className="font-medium text-sm group-hover:text-primary transition-colors">{nextGuide.title}</p>
                  </div>
                  <ChevronRight className="h-5 w-5 text-primary" aria-hidden="true" />
                </Link>
              )}
              {alsoView.length > 0 && (
                <div>
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">People also view</p>
                  <div className="grid sm:grid-cols-3 gap-2">
                    {alsoView.map(g => g && (
                      <Link key={g.slug} to={`/guide/${g.slug}`} className="p-3 rounded-lg border hover:bg-muted/50 transition-colors group">
                        <p className="text-[11px] text-muted-foreground capitalize mb-0.5">{g.audience === "both" ? "All" : g.audience} • {g.complexity}</p>
                        <p className="text-sm font-medium group-hover:text-primary transition-colors line-clamp-2">{g.title}</p>
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </section>
          )}

          {/* Related Topics */}
          {groupedRelated.length > 0 && (
            <section className="mt-6">
              <h2 className="text-base font-semibold mb-3">Related Topics</h2>
              <div className="space-y-3">
                {groupedRelated.map(group => (
                  <div key={group.label}>
                    <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">{group.label}</p>
                    <div className="grid sm:grid-cols-2 gap-2">
                      {group.topics.map(t => (
                        <Link key={t.slug} to={`/guide/${t.slug}`} className="flex items-center gap-2 p-3 rounded-lg border hover:bg-muted/50 transition-colors group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
                          <span className="text-sm font-medium group-hover:text-primary transition-colors flex-1">{t.title}</span>
                          <ArrowRight className="h-3.5 w-3.5 text-muted-foreground" aria-hidden="true" />
                        </Link>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* Source */}
          <footer className="mt-8 pt-4 border-t space-y-1.5">
            <div className="text-xs text-muted-foreground flex flex-wrap items-center gap-2">
              <span className="font-medium">Source:</span>
              <a href={guide.sourceReference} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline flex items-center gap-1 break-all">
                {guide.sourceReference} <ExternalLink className="h-3 w-3 shrink-0" aria-hidden="true" />
              </a>
            </div>
            <div className="text-xs text-muted-foreground flex flex-wrap items-center gap-4">
              <span>Updated: {guide.lastUpdated}</span>
              <span>Confidence: <span className={`font-medium ${guide.sourceConfidence === "high" ? "text-success" : guide.sourceConfidence === "medium" ? "text-warning" : "text-destructive"}`}>{guide.sourceConfidence}</span></span>
            </div>
          </footer>
        </div>

        <aside className="w-44 shrink-0 hidden xl:block">
          <TableOfContents guide={guide} />
        </aside>
      </div>
    </div>
  );
}
