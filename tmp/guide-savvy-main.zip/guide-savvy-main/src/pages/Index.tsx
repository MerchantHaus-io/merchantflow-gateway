import { Link } from "react-router-dom";
import { SearchBar } from "@/components/guide/SearchBar";
import { CategoryCard, TaskCard } from "@/components/guide/Cards";
import { categories, commonTasks, guides } from "@/data/guides";
import { useRole } from "@/contexts/RoleContext";
import { Shield, ArrowRight, Users, Building2, Zap, BookOpen, HelpCircle, ChevronRight } from "lucide-react";

const priorityGuideSlugs = [
  "two-factor-authentication",
  "security-key-migration",
  "password-rotation",
  "vt-credit-card",
  "merchant-user-accounts",
  "test-mode",
];

const Index = () => {
  const { role, setRole, isPartner, isMerchant } = useRole();

  const featuredTasks = commonTasks
    .filter(t => role === "both" || t.audience === role || t.audience === "both")
    .slice(0, 6);

  const displayCategories = categories.filter(c => c.slug !== "troubleshooting" && c.slug !== "glossary");

  const priorityGuides = priorityGuideSlugs
    .map(s => guides.find(g => g.slug === s))
    .filter(g => g && (role === "both" || g.audience === role || g.audience === "both"))
    .slice(0, 4);

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 sm:py-10 space-y-10 sm:space-y-12">
      {/* Hero */}
      <section className="relative text-center space-y-5 py-8 sm:py-12">
        <div className="absolute inset-0 -z-10 rounded-2xl bg-gradient-to-br from-primary/5 via-transparent to-accent/5" />
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium">
          <Zap className="h-3 w-3" aria-hidden="true" />
          Interactive product companion
        </div>
        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-foreground">
          NMI Merchant Portal Guide
        </h1>
        <p className="text-base sm:text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
          {isPartner && !isMerchant
            ? "Everything you need to support merchants: account setup, permissions, security, and escalation workflows."
            : isMerchant && !isPartner
            ? "Your step-by-step companion for daily portal tasks: transactions, settings, reporting, and self-service operations."
            : "Step-by-step walkthroughs, troubleshooting, and best practices for partners and merchants."}
        </p>
        <SearchBar size="large" className="max-w-xl mx-auto" />
      </section>

      {/* Role Entry */}
      <section className="grid sm:grid-cols-2 gap-4 max-w-2xl mx-auto">
        <button
          onClick={() => setRole("partner")}
          aria-pressed={role === "partner"}
          className={`guide-card text-left group ${role === "partner" ? "ring-2 ring-primary" : ""}`}
        >
          <div className="flex items-center gap-3 mb-3">
            <div className="p-2.5 rounded-xl bg-primary/10 group-hover:bg-primary/15 transition-colors">
              <Building2 className="h-5 w-5 text-primary" aria-hidden="true" />
            </div>
            {role === "partner" && <span className="text-[10px] font-semibold uppercase tracking-widest text-primary">Active</span>}
          </div>
          <h3 className="font-semibold">I'm a Partner</h3>
          <p className="text-sm text-muted-foreground mt-1">Manage merchant accounts, permissions, and support operations.</p>
        </button>
        <button
          onClick={() => setRole("merchant")}
          aria-pressed={role === "merchant"}
          className={`guide-card text-left group ${role === "merchant" ? "ring-2 ring-accent" : ""}`}
        >
          <div className="flex items-center gap-3 mb-3">
            <div className="p-2.5 rounded-xl bg-accent/10 group-hover:bg-accent/15 transition-colors">
              <Users className="h-5 w-5 text-accent" aria-hidden="true" />
            </div>
            {role === "merchant" && <span className="text-[10px] font-semibold uppercase tracking-widest text-accent">Active</span>}
          </div>
          <h3 className="font-semibold">I'm a Merchant</h3>
          <p className="text-sm text-muted-foreground mt-1">Self-service portal navigation, daily operations, and setup guides.</p>
        </button>
      </section>

      {/* Priority Topics */}
      {priorityGuides.length > 0 && (
        <section>
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-lg font-semibold">Priority Topics</h2>
              <p className="text-sm text-muted-foreground mt-0.5">High-impact items from the latest portal updates</p>
            </div>
          </div>
          <div className="grid sm:grid-cols-2 gap-3">
            {priorityGuides.map(g => g && (
              <Link key={g.slug} to={`/guide/${g.slug}`} className="flex items-center gap-3 p-4 rounded-xl border bg-card hover:shadow-md transition-all group">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className={`text-[10px] font-semibold uppercase tracking-wider ${g.audience === "partner" ? "text-primary" : g.audience === "merchant" ? "text-accent" : "text-muted-foreground"}`}>
                      {g.audience === "both" ? "All" : g.audience}
                    </span>
                    <span className="text-[10px] text-muted-foreground capitalize">• {g.complexity}</span>
                  </div>
                  <h3 className="font-medium text-sm group-hover:text-primary transition-colors truncate">{g.title}</h3>
                  <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{g.summary}</p>
                </div>
                <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0 group-hover:text-primary transition-colors" aria-hidden="true" />
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* Common Tasks */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-semibold">Common Tasks</h2>
            <p className="text-sm text-muted-foreground mt-0.5">
              {isPartner && !isMerchant ? "Tasks for supporting merchants" : isMerchant && !isPartner ? "Your most-used daily workflows" : "Quick access to frequent portal actions"}
            </p>
          </div>
          <Link to="/tasks" className="text-sm text-primary hover:underline flex items-center gap-1 shrink-0">
            View all <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
          </Link>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {featuredTasks.map((task) => <TaskCard key={task.guideSlug + task.title} task={task} />)}
        </div>
      </section>

      {/* Categories */}
      <section>
        <div className="mb-4">
          <h2 className="text-lg font-semibold">Browse by Category</h2>
          <p className="text-sm text-muted-foreground mt-0.5">All portal documentation organized by topic</p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {displayCategories.map((cat) => <CategoryCard key={cat.slug} category={cat} />)}
        </div>
      </section>

      {/* Quick Links */}
      <section className="grid sm:grid-cols-2 gap-3">
        <Link to="/troubleshooting" className="flex items-center gap-4 p-4 rounded-xl border bg-card hover:shadow-md transition-all group">
          <div className="p-2.5 rounded-xl bg-warning/10">
            <HelpCircle className="h-5 w-5 text-warning" aria-hidden="true" />
          </div>
          <div className="flex-1">
            <h3 className="font-semibold text-sm group-hover:text-primary transition-colors">Troubleshooting Hub</h3>
            <p className="text-xs text-muted-foreground">Common issues, causes, and resolution steps</p>
          </div>
          <ArrowRight className="h-4 w-4 text-muted-foreground shrink-0" aria-hidden="true" />
        </Link>
        <Link to="/glossary" className="flex items-center gap-4 p-4 rounded-xl border bg-card hover:shadow-md transition-all group">
          <div className="p-2.5 rounded-xl bg-info/10">
            <BookOpen className="h-5 w-5 text-info" aria-hidden="true" />
          </div>
          <div className="flex-1">
            <h3 className="font-semibold text-sm group-hover:text-primary transition-colors">Glossary</h3>
            <p className="text-xs text-muted-foreground">Key terms and NMI-specific portal concepts</p>
          </div>
          <ArrowRight className="h-4 w-4 text-muted-foreground shrink-0" aria-hidden="true" />
        </Link>
      </section>

      {/* Security Banner */}
      <section className="rounded-xl bg-primary/5 border border-primary/10 p-5 flex flex-col sm:flex-row items-start gap-4">
        <Shield className="h-7 w-7 text-primary shrink-0 mt-0.5" aria-hidden="true" />
        <div>
          <h3 className="font-semibold text-sm text-foreground mb-1">Important Security Update</h3>
          <p className="text-sm text-muted-foreground leading-relaxed">
            {isPartner && !isMerchant
              ? "Remind your merchants: NMI enforces 90-day password expiry unless 2FA is enabled. Guide merchants to enable 2FA or plan their API key migration before end of 2026."
              : "NMI enforces a 90-day portal password expiry unless 2FA is enabled. By end of 2026, API key authentication will be required."}
            <Link to="/guide/security-key-migration" className="text-primary ml-1 hover:underline font-medium">Learn about the migration →</Link>
          </p>
        </div>
      </section>
    </div>
  );
};

export default Index;
