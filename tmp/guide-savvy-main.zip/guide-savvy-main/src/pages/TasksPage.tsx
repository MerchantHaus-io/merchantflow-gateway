import { commonTasks, guides } from "@/data/guides";
import { Breadcrumbs } from "@/components/guide/Breadcrumbs";
import { TaskCard } from "@/components/guide/Cards";
import { useRole } from "@/contexts/RoleContext";
import { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, Search, Zap } from "lucide-react";
import { Audience, Complexity } from "@/data/types";

export default function TasksPage() {
  const { role, isPartner, isMerchant } = useRole();
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [complexityFilter, setComplexityFilter] = useState<Complexity | "all">("all");
  const [searchQuery, setSearchQuery] = useState("");

  const filtered = commonTasks.filter(t => {
    const roleMatch = role === "both" || t.audience === role || t.audience === "both";
    const catMatch = categoryFilter === "all" || t.category === categoryFilter;
    const complexMatch = complexityFilter === "all" || t.complexity === complexityFilter;
    const searchMatch = !searchQuery ||
      t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.permissions.some(p => p.toLowerCase().includes(searchQuery.toLowerCase()));
    return roleMatch && catMatch && complexMatch && searchMatch;
  });

  const taskCategories = [...new Set(commonTasks.map(t => t.category))];

  // Group filtered tasks by category
  const groupedTasks = filtered.reduce<Record<string, typeof filtered>>((acc, t) => {
    const cat = t.category;
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(t);
    return acc;
  }, {});

  // Featured — most common beginner tasks
  const featured = commonTasks
    .filter(t => t.complexity === "beginner" && (role === "both" || t.audience === role || t.audience === "both"))
    .slice(0, 3);

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
      <Breadcrumbs items={[{ label: "Common Tasks" }]} />
      <h1 className="text-2xl sm:text-3xl font-bold mb-2">Common Tasks</h1>
      <p className="text-muted-foreground mb-1">
        {isPartner && !isMerchant
          ? "Tasks for supporting and managing merchant accounts."
          : isMerchant && !isPartner
          ? "Your most-used daily portal workflows."
          : "Quick access to the most frequent Merchant Portal tasks."}
      </p>
      <p className="text-sm text-muted-foreground mb-6">{filtered.length} of {commonTasks.length} tasks shown</p>

      {/* Featured quick-start */}
      {categoryFilter === "all" && complexityFilter === "all" && !searchQuery && featured.length > 0 && (
        <section className="mb-8">
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-1.5">
            <Zap className="h-3.5 w-3.5 text-primary" aria-hidden="true" />
            Quick Start — Most Common
          </h2>
          <div className="grid sm:grid-cols-3 gap-3">
            {featured.map(t => (
              <Link key={t.guideSlug + t.title} to={`/guide/${t.guideSlug}`} className="flex items-center gap-3 p-3 rounded-lg border bg-primary/5 border-primary/15 hover:bg-primary/10 transition-colors group">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium group-hover:text-primary transition-colors">{t.title}</p>
                  <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{t.description}</p>
                </div>
                <ArrowRight className="h-3.5 w-3.5 text-primary shrink-0" aria-hidden="true" />
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* Search */}
      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" aria-hidden="true" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search tasks, permissions..."
          className="w-full rounded-lg border bg-card pl-10 pr-4 py-2.5 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30"
          aria-label="Search common tasks"
        />
      </div>

      {/* Filters */}
      <div className="space-y-3 mb-8">
        <div className="flex flex-wrap gap-2" role="group" aria-label="Filter by category">
          <button
            onClick={() => setCategoryFilter("all")}
            aria-pressed={categoryFilter === "all"}
            className={`px-3 py-1.5 text-sm rounded-md transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${categoryFilter === "all" ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:text-foreground"}`}
          >All Categories</button>
          {taskCategories.map(cat => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              aria-pressed={categoryFilter === cat}
              className={`px-3 py-1.5 text-sm rounded-md transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${categoryFilter === cat ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:text-foreground"}`}
            >{cat}</button>
          ))}
        </div>
        <div className="flex flex-wrap gap-2" role="group" aria-label="Filter by complexity">
          {(["all", "beginner", "intermediate", "advanced"] as const).map(c => (
            <button
              key={c}
              onClick={() => setComplexityFilter(c)}
              aria-pressed={complexityFilter === c}
              className={`px-3 py-1.5 text-sm rounded-md transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${
                complexityFilter === c ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:text-foreground"
              }`}
            >{c === "all" ? "All Levels" : c === "beginner" ? "Quick" : c === "intermediate" ? "Moderate" : "Complex"}</button>
          ))}
        </div>
      </div>

      {/* Grouped display when "all" category */}
      {categoryFilter === "all" ? (
        <div className="space-y-8">
          {Object.entries(groupedTasks).map(([cat, tasks]) => (
            <section key={cat}>
              <h2 className="text-base font-semibold mb-3 pb-2 border-b text-muted-foreground">{cat} <span className="text-xs font-normal">({tasks.length})</span></h2>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {tasks.map(t => <TaskCard key={t.guideSlug + t.title} task={t} />)}
              </div>
            </section>
          ))}
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map(t => <TaskCard key={t.guideSlug + t.title} task={t} />)}
        </div>
      )}

      {filtered.length === 0 && (
        <div className="text-center py-12 space-y-3">
          <p className="text-muted-foreground">No tasks match your filters.</p>
          <button onClick={() => { setCategoryFilter("all"); setComplexityFilter("all"); setSearchQuery(""); }} className="text-sm text-primary hover:underline">Clear all filters</button>
        </div>
      )}
    </div>
  );
}
