import React, { createContext, useContext, useState, ReactNode } from "react";
import { Audience } from "@/data/types";

interface RoleContextType {
  role: Audience;
  setRole: (role: Audience) => void;
  isPartner: boolean;
  isMerchant: boolean;
}

const RoleContext = createContext<RoleContextType>({
  role: "both",
  setRole: () => {},
  isPartner: true,
  isMerchant: true,
});

export function RoleProvider({ children }: { children: ReactNode }) {
  const [role, setRole] = useState<Audience>("both");

  return (
    <RoleContext.Provider value={{
      role,
      setRole,
      isPartner: role === "partner" || role === "both",
      isMerchant: role === "merchant" || role === "both",
    }}>
      {children}
    </RoleContext.Provider>
  );
}

export function useRole() {
  return useContext(RoleContext);
}
