import { Link } from "react-router-dom";
import { Shield, Settings, CreditCard, ShoppingCart, BarChart3, Puzzle, ArrowRight, Clock, Users, Rocket, RefreshCw, HelpCircle, BookOpen } from "lucide-react";
import { Category, Guide, CommonTask } from "@/data/types";
import { AudienceBadge } from "./AudienceBadge";
import { getGuidesByCategory } from "@/data/guides";

const iconMap: Record<string, React.ElementType> = {
  Shield, Settings, CreditCard, ShoppingCart, BarChart3, Puzzle, Rocket, RefreshCw, HelpCircle, BookOpen, Users,
};

export function CategoryCard({ category }: { category: Category }) {
  const Icon = iconMap[category.icon] || Settings;
  const guideCount = getGuidesByCategory(category.slug).length;
  return (
    <Link to={`/category/${category.slug}`} className="guide-card group flex flex-col" aria-label={`${category.title} — ${guideCount} guides`}>
      <div className="flex items-center gap-3 mb-3">
        <div className="p-2 rounded-lg bg-primary/10 text-primary">
          <Icon className="h-4 w-4" aria-hidden="true" />
        </div>
        <span className="text-xs text-muted-foreground">{guideCount} guide{guideCount !== 1 ? "s" : ""}</span>
      </div>
      <h3 className="font-semibold text-sm text-foreground mb-1.5">{category.title}</h3>
      <p className="text-xs text-muted-foreground flex-1 line-clamp-2">{category.description}</p>
      <div className="mt-3 flex items-center gap-2">
        <AudienceBadge audience={category.audience} />
        <span className="flex-1" />
        <span className="text-xs font-medium text-primary opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1">
          Browse <ArrowRight className="h-3 w-3" aria-hidden="true" />
        </span>
      </div>
    </Link>
  );
}

export function GuideCard({ guide }: { guide: Guide }) {
  return (
    <Link to={`/guide/${guide.slug}`} className="guide-card group flex flex-col">
      <div className="flex items-center gap-2 mb-2">
        <AudienceBadge audience={guide.audience} />
        <span className="text-[11px] text-muted-foreground capitalize">{guide.complexity}</span>
      </div>
      <h3 className="font-semibold text-sm text-foreground mb-1.5 group-hover:text-primary transition-colors">{guide.title}</h3>
      <p className="text-xs text-muted-foreground flex-1 line-clamp-2">{guide.summary}</p>
      <div className="mt-3 flex items-center justify-between text-[11px] text-muted-foreground">
        <span className="flex items-center gap-1"><Clock className="h-3 w-3" aria-hidden="true" /> {guide.lastUpdated}</span>
        <span>{guide.steps.length > 0 ? `${guide.steps.length} steps` : "Reference"}</span>
      </div>
    </Link>
  );
}

export function TaskCard({ task }: { task: CommonTask }) {
  const complexityColor = {
    beginner: "text-success",
    intermediate: "text-warning",
    advanced: "text-destructive",
  };

  const complexityLabel = {
    beginner: "Quick",
    intermediate: "Moderate",
    advanced: "Complex",
  };

  return (
    <Link to={`/guide/${task.guideSlug}`} className="guide-card group flex flex-col">
      <div className="flex items-center justify-between mb-2">
        <AudienceBadge audience={task.audience} />
        <span className={`text-[11px] font-medium capitalize ${complexityColor[task.complexity]}`}>
          {complexityLabel[task.complexity]}
        </span>
      </div>
      <h3 className="font-semibold text-sm text-foreground mb-1 group-hover:text-primary transition-colors">{task.title}</h3>
      <p className="text-xs text-muted-foreground mb-3 flex-1 line-clamp-2">{task.description}</p>
      {task.permissions.length > 0 && (
        <div className="flex items-center gap-1 text-[11px] text-muted-foreground">
          <Users className="h-3 w-3 shrink-0" aria-hidden="true" />
          <span className="truncate">{task.permissions[0]}</span>
        </div>
      )}
    </Link>
  );
}
