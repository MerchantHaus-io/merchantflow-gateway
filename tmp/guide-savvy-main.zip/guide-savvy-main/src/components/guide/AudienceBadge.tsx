import { useRole } from "@/contexts/RoleContext";
import { Audience } from "@/data/types";

export function AudienceBadge({ audience }: { audience: Audience }) {
  if (audience === "partner") {
    return <span className="badge-partner">Partner</span>;
  }
  if (audience === "merchant") {
    return <span className="badge-merchant">Merchant</span>;
  }
  return <span className="badge-both">All</span>;
}

export function RoleToggle() {
  const { role, setRole } = useRole();

  return (
    <div className="inline-flex items-center rounded-lg border bg-card p-0.5 gap-0.5" role="radiogroup" aria-label="Select your role">
      {(["both", "partner", "merchant"] as Audience[]).map((r) => (
        <button
          key={r}
          onClick={() => setRole(r)}
          role="radio"
          aria-checked={role === r}
          className={`px-2.5 py-1.5 text-xs font-medium rounded-md transition-all capitalize focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${
            role === r
              ? "bg-primary text-primary-foreground shadow-sm"
              : "text-muted-foreground hover:text-foreground"
          }`}
        >
          {r === "both" ? "All" : r}
        </button>
      ))}
    </div>
  );
}
