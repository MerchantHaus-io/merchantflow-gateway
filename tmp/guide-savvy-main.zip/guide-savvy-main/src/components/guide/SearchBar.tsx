import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Search } from "lucide-react";

export function SearchBar({ size = "default", className = "" }: { size?: "default" | "large"; className?: string }) {
  const [query, setQuery] = useState("");
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      navigate(`/search?q=${encodeURIComponent(query.trim())}`);
    }
  };

  return (
    <form onSubmit={handleSubmit} className={className} role="search">
      <div className="relative">
        <Search className={`absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground ${size === "large" ? "h-5 w-5" : "h-4 w-4"}`} aria-hidden="true" />
        <input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search guides, glossary, tasks..."
          aria-label="Search guides, glossary, and tasks"
          className={`w-full rounded-xl border bg-card text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 transition-shadow ${
            size === "large" ? "pl-12 pr-4 py-3.5 text-base" : "pl-10 pr-4 py-2.5 text-sm"
          }`}
        />
      </div>
    </form>
  );
}
