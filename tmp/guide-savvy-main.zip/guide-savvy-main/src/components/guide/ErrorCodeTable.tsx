import { useState, useMemo } from "react";
import { directConnectErrorCodes, errorCodeCategories } from "@/data/directConnectErrorCodes";
import { Search, Filter } from "lucide-react";

export function ErrorCodeTable() {
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  const filtered = useMemo(() => {
    return directConnectErrorCodes.filter(e => {
      const matchesCategory = !activeCategory || e.category === activeCategory;
      if (!search) return matchesCategory;
      const q = search.toLowerCase();
      return matchesCategory && (
        String(e.code).includes(q) ||
        e.message.toLowerCase().includes(q) ||
        e.description.toLowerCase().includes(q)
      );
    });
  }, [search, activeCategory]);

  const categoryColors: Record<string, string> = {
    Card: "bg-destructive/10 text-destructive",
    Validation: "bg-warning/10 text-warning",
    Terminal: "bg-primary/10 text-primary",
    Platform: "bg-accent text-accent-foreground",
    Availability: "bg-muted text-muted-foreground",
    XML: "bg-secondary text-secondary-foreground",
  };

  return (
    <div className="space-y-4">
      {/* Search + Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search by code, message, or description…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border bg-background focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>
        <div className="flex items-center gap-1.5 flex-wrap">
          <Filter className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
          <button
            onClick={() => setActiveCategory(null)}
            className={`text-xs px-2.5 py-1 rounded-full border transition-colors ${!activeCategory ? "bg-primary text-primary-foreground border-primary" : "hover:bg-muted"}`}
          >
            All
          </button>
          {errorCodeCategories.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(activeCategory === cat ? null : cat)}
              className={`text-xs px-2.5 py-1 rounded-full border transition-colors ${activeCategory === cat ? "bg-primary text-primary-foreground border-primary" : "hover:bg-muted"}`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Results count */}
      <p className="text-xs text-muted-foreground">
        Showing {filtered.length} of {directConnectErrorCodes.length} error codes
      </p>

      {/* Table */}
      <div className="rounded-lg border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-muted/50 border-b">
                <th className="text-left py-2.5 px-3 font-semibold text-xs uppercase tracking-wider w-20">Code</th>
                <th className="text-left py-2.5 px-3 font-semibold text-xs uppercase tracking-wider w-24">Category</th>
                <th className="text-left py-2.5 px-3 font-semibold text-xs uppercase tracking-wider w-48">Message</th>
                <th className="text-left py-2.5 px-3 font-semibold text-xs uppercase tracking-wider">Description</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((e) => (
                <tr key={e.code} className="border-b last:border-b-0 hover:bg-muted/30 transition-colors">
                  <td className="py-2 px-3 font-mono text-xs font-semibold">{e.code}</td>
                  <td className="py-2 px-3">
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${categoryColors[e.category] || "bg-muted text-muted-foreground"}`}>
                      {e.category}
                    </span>
                  </td>
                  <td className="py-2 px-3 font-medium text-xs">{e.message}</td>
                  <td className="py-2 px-3 text-xs text-muted-foreground">{e.description}</td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={4} className="py-8 text-center text-sm text-muted-foreground">
                    No error codes match your search.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
