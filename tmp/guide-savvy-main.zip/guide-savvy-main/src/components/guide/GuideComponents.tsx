import { useState, useCallback, useEffect } from "react";
import { Check, Copy, ChevronDown, ChevronUp, AlertTriangle, Info, CheckCircle2, X, ZoomIn } from "lucide-react";
import { GuideStep as GuideStepType } from "@/data/types";

export function StepperUI({ steps }: { steps: GuideStepType[] }) {
  const [completedSteps, setCompletedSteps] = useState<Set<number>>(new Set());
  const [checklistMode, setChecklistMode] = useState(false);

  const toggleStep = (stepNumber: number) => {
    if (!checklistMode) return;
    const next = new Set(completedSteps);
    if (next.has(stepNumber)) next.delete(stepNumber);
    else next.add(stepNumber);
    setCompletedSteps(next);
  };

  const allComplete = checklistMode && completedSteps.size === steps.length;
  const progress = checklistMode ? Math.round((completedSteps.size / steps.length) * 100) : 0;

  return (
    <div className="space-y-4" role="region" aria-label="Step-by-step instructions">
      <div className="flex items-center justify-between gap-4">
        <h3 className="text-lg font-semibold" id="steps-heading">Step-by-Step Instructions</h3>
        <button
          onClick={() => { setChecklistMode(!checklistMode); setCompletedSteps(new Set()); }}
          aria-pressed={checklistMode}
          className={`text-xs px-3 py-1.5 rounded-md transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${
            checklistMode ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:text-foreground"
          }`}
        >
          {checklistMode ? "Exit Checklist" : "☑ Checklist Mode"}
        </button>
      </div>

      {checklistMode && (
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>{completedSteps.size} of {steps.length} completed</span>
            <span>{progress}%</span>
          </div>
          <div className="h-1.5 rounded-full bg-muted overflow-hidden">
            <div
              className="h-full rounded-full bg-primary transition-all duration-300"
              style={{ width: `${progress}%` }}
              role="progressbar"
              aria-valuenow={progress}
              aria-valuemin={0}
              aria-valuemax={100}
            />
          </div>
        </div>
      )}

      <div className="space-y-2" aria-labelledby="steps-heading">
        {steps.map((step) => {
          const done = completedSteps.has(step.stepNumber);
          return (
            <div
              key={step.stepNumber}
              onClick={() => toggleStep(step.stepNumber)}
              onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); toggleStep(step.stepNumber); }}}
              tabIndex={checklistMode ? 0 : undefined}
              role={checklistMode ? "checkbox" : undefined}
              aria-checked={checklistMode ? done : undefined}
              className={`flex gap-3 p-4 rounded-lg border transition-all ${
                checklistMode ? "cursor-pointer hover:bg-muted/50 focus-visible:ring-2 focus-visible:ring-ring" : ""
              } ${done ? "bg-success/5 border-success/20" : "bg-card"}`}
            >
              <div className={`step-indicator ${done ? "!bg-success" : ""}`}>
                {done ? <Check className="h-4 w-4" aria-hidden="true" /> : step.stepNumber}
              </div>
              <div className="flex-1 space-y-2 min-w-0">
                <p className={`text-sm leading-relaxed ${done ? "line-through text-muted-foreground" : ""}`}>
                  {step.instruction}
                </p>
                {step.note && (
                  <div className="flex items-start gap-2 text-xs text-info bg-info/5 rounded-md p-2.5">
                    <Info className="h-3.5 w-3.5 shrink-0 mt-0.5" aria-hidden="true" />
                    <span>{step.note}</span>
                  </div>
                )}
                {step.warning && (
                  <div className="flex items-start gap-2 text-xs text-warning bg-warning/5 rounded-md p-2.5">
                    <AlertTriangle className="h-3.5 w-3.5 shrink-0 mt-0.5" aria-hidden="true" />
                    <span>{step.warning}</span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {allComplete && (
        <div className="callout-success flex items-center gap-3 animate-fade-in" role="status">
          <CheckCircle2 className="h-5 w-5 text-success" aria-hidden="true" />
          <div>
            <p className="font-semibold text-success">All steps completed!</p>
            <p className="text-sm text-muted-foreground">You've successfully completed this walkthrough.</p>
          </div>
        </div>
      )}
    </div>
  );
}

export function NavigationPathDisplay({ path }: { path: string }) {
  const [copied, setCopied] = useState(false);

  const copy = () => {
    navigator.clipboard.writeText(path);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex items-center gap-2 mb-4 p-3 rounded-lg bg-muted/50 border">
      <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider shrink-0">Navigation:</span>
      <code className="nav-path flex-1 text-xs overflow-x-auto">{path}</code>
      <button
        onClick={copy}
        className="p-1.5 rounded-md hover:bg-muted transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring shrink-0"
        title="Copy navigation path"
        aria-label={copied ? "Copied" : "Copy navigation path"}
      >
        {copied ? <Check className="h-3.5 w-3.5 text-success" aria-hidden="true" /> : <Copy className="h-3.5 w-3.5 text-muted-foreground" aria-hidden="true" />}
      </button>
    </div>
  );
}

export function CalloutBox({ type, title, children }: { type: "warning" | "info" | "success" | "destructive" | "permission"; title?: string; children: React.ReactNode }) {
  const resolvedType = type === "permission" ? "info" : type;
  const icons = {
    warning: <AlertTriangle className="h-4 w-4 text-warning shrink-0" aria-hidden="true" />,
    info: <Info className="h-4 w-4 text-info shrink-0" aria-hidden="true" />,
    success: <CheckCircle2 className="h-4 w-4 text-success shrink-0" aria-hidden="true" />,
    destructive: <AlertTriangle className="h-4 w-4 text-destructive shrink-0" aria-hidden="true" />,
  };

  return (
    <div className={`callout-${resolvedType} flex items-start gap-3`} role="note">
      {icons[resolvedType]}
      <div className="text-sm min-w-0">
        {title && <p className="font-semibold mb-0.5">{title}</p>}
        {!title && type === "permission" && <p className="font-semibold mb-0.5 text-info">🔑 Permissions Required</p>}
        {children}
      </div>
    </div>
  );
}

export function CollapsibleSection({ title, children, defaultOpen = false }: { title: string; children: React.ReactNode; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(defaultOpen);

  return (
    <div className="border rounded-lg overflow-hidden">
      <button
        onClick={() => setOpen(!open)}
        aria-expanded={open}
        className="w-full flex items-center justify-between p-3.5 bg-card hover:bg-muted/50 transition-colors text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-inset"
      >
        <span className="font-medium text-sm">{title}</span>
        {open ? <ChevronUp className="h-4 w-4 text-muted-foreground" aria-hidden="true" /> : <ChevronDown className="h-4 w-4 text-muted-foreground" aria-hidden="true" />}
      </button>
      {open && <div className="p-3.5 border-t text-sm">{children}</div>}
    </div>
  );
}

export function ImageLightbox({ src, alt, caption }: { src: string; alt: string; caption?: string }) {
  const [open, setOpen] = useState(false);

  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if (e.key === "Escape") setOpen(false);
  }, []);

  useEffect(() => {
    if (open) {
      document.addEventListener("keydown", handleKeyDown);
      document.body.style.overflow = "hidden";
    }
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = "";
    };
  }, [open, handleKeyDown]);

  return (
    <>
      <figure className="my-4">
        <button
          onClick={() => setOpen(true)}
          className="relative group rounded-lg overflow-hidden border bg-muted/30 cursor-zoom-in focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring w-full"
          aria-label={`Enlarge image: ${alt}`}
        >
          <img src={src} alt={alt} className="w-full h-auto" loading="lazy" />
          <div className="absolute inset-0 bg-foreground/0 group-hover:bg-foreground/5 transition-colors flex items-center justify-center">
            <ZoomIn className="h-6 w-6 text-foreground/0 group-hover:text-foreground/60 transition-colors" aria-hidden="true" />
          </div>
        </button>
        {caption && <figcaption className="text-xs text-muted-foreground mt-2 text-center">{caption}</figcaption>}
      </figure>

      {open && (
        <div
          className="lightbox-overlay"
          onClick={() => setOpen(false)}
          role="dialog"
          aria-modal="true"
          aria-label={`Enlarged view: ${alt}`}
        >
          <button
            onClick={() => setOpen(false)}
            className="absolute top-4 right-4 p-2 rounded-full bg-card/80 hover:bg-card text-foreground transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            aria-label="Close lightbox"
          >
            <X className="h-5 w-5" />
          </button>
          <img
            src={src}
            alt={alt}
            className="max-w-[90vw] max-h-[85vh] rounded-lg shadow-lg object-contain"
            onClick={(e) => e.stopPropagation()}
          />
          {caption && <p className="absolute bottom-6 left-1/2 -translate-x-1/2 text-sm text-primary-foreground bg-foreground/60 px-4 py-1.5 rounded-full">{caption}</p>}
        </div>
      )}
    </>
  );
}

export function RoleContextBanner({ role, partnerText, merchantText }: { role: "partner" | "merchant" | "both"; partnerText: string; merchantText: string }) {
  if (role === "both") return null;
  return (
    <div className={role === "partner" ? "role-context-partner" : "role-context-merchant"}>
      <p className="text-sm">
        <span className="font-semibold capitalize">{role} context: </span>
        {role === "partner" ? partnerText : merchantText}
      </p>
    </div>
  );
}
