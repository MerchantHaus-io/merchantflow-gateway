import { Link, useLocation } from "react-router-dom";
import { Shield, Settings, CreditCard, Puzzle, Home, BookOpen, Search, HelpCircle, ListChecks, X, Menu, Rocket, Users, BarChart3, RefreshCw } from "lucide-react";
import { useState, useEffect } from "react";
import { RoleToggle } from "./AudienceBadge";
import { AiAssistant } from "./AiAssistant";
import nmiLogo from "@/assets/nmi-logo-purple.png";

const navItems = [
  { label: "Home", href: "/", icon: Home },
  { label: "Getting Started", href: "/category/getting-started", icon: Rocket },
  { label: "Security & Access", href: "/category/security-access", icon: Shield },
  { label: "User Management", href: "/category/user-management", icon: Users },
  { label: "Settings", href: "/category/settings-configuration", icon: Settings },
  { label: "Payments", href: "/category/transactions-payments", icon: CreditCard },
  { label: "Reporting", href: "/category/reporting", icon: BarChart3 },
  { label: "Subscriptions", href: "/category/subscriptions-recurring", icon: RefreshCw },
  { label: "Integrations", href: "/category/integrations-api", icon: Puzzle },
  { label: "Common Tasks", href: "/tasks", icon: ListChecks },
  { label: "Troubleshooting", href: "/troubleshooting", icon: HelpCircle },
  { label: "Glossary", href: "/glossary", icon: BookOpen },
];

export function AppLayout({ children }: { children: React.ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setSidebarOpen(false);
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-50 border-b bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/80">
        <div className="flex items-center justify-between px-4 h-14">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="lg:hidden p-2 rounded-md hover:bg-muted transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              aria-label={sidebarOpen ? "Close navigation" : "Open navigation"}
              aria-expanded={sidebarOpen}
            >
              {sidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
            <Link to="/" className="flex items-center gap-2.5">
              <img src={nmiLogo} alt="NMI" className="h-7 w-auto" />
              <div className="hidden sm:block">
                <span className="font-semibold text-foreground text-sm">Portal Guide</span>
              </div>
            </Link>
          </div>
          <div className="flex items-center gap-2 sm:gap-3">
            <RoleToggle />
            <Link
              to="/search"
              className="p-2 rounded-md hover:bg-muted text-muted-foreground hover:text-foreground transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              aria-label="Search guides"
            >
              <Search className="h-5 w-5" />
            </Link>
          </div>
        </div>
      </header>

      <div className="flex flex-1">
        <aside
          className={`fixed lg:sticky top-14 left-0 z-40 h-[calc(100vh-3.5rem)] w-60 border-r bg-card overflow-y-auto transition-transform duration-200 lg:translate-x-0 ${
            sidebarOpen ? "translate-x-0" : "-translate-x-full"
          }`}
          role="navigation"
          aria-label="Main navigation"
        >
          <nav className="p-2 space-y-0.5">
            {navItems.map((item) => {
              const active = location.pathname === item.href || (item.href !== "/" && location.pathname.startsWith(item.href));
              return (
                <Link
                  key={item.href}
                  to={item.href}
                  aria-current={active ? "page" : undefined}
                  className={`flex items-center gap-2.5 px-3 py-2 rounded-lg text-[13px] transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${
                    active
                      ? "bg-primary/10 text-primary font-medium"
                      : "text-muted-foreground hover:bg-muted hover:text-foreground"
                  }`}
                >
                  <item.icon className="h-4 w-4 shrink-0" aria-hidden="true" />
                  {item.label}
                </Link>
              );
            })}
          </nav>
        </aside>

        {sidebarOpen && (
          <div
            className="fixed inset-0 z-30 bg-foreground/20 backdrop-blur-[2px] lg:hidden transition-opacity"
            onClick={() => setSidebarOpen(false)}
            aria-hidden="true"
          />
        )}

        <main className="flex-1 min-w-0 page-enter" key={location.pathname}>
          {children}
        </main>
      </div>
      <AiAssistant />
    </div>
  );
}
